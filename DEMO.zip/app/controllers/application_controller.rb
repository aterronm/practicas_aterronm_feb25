class ApplicationController < ActionController::Base
  include Authentication
  allow_browser versions: :modern

  # Sólo aliasamos si ya está definido authenticate_google_account!
  if instance_methods.include?(:authenticate_google_account!)
    alias_method :authenticate_user!,   :authenticate_google_account!
    alias_method :current_user,         :current_google_account
    alias_method :user_signed_in?,      :google_account_signed_in?
  end

  before_action :configure_permitted_parameters, if: :devise_controller?

  protected

  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:sign_in, keys: [:some_extra_field])
  end
end
