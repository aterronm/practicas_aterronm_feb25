class ClientsController < ApplicationController

  skip_before_action :authenticate_user!, only: [:index]

  before_action :set_client, only: %i[show edit update destroy]
  before_action :load_collections, only: %i[index new edit create update]
  before_action :sanitize_client_associations, only: %i[index create update]

  # GET /core/clients
  # GET /core/clients.json
  def index
    @clients = Core::Client.includes(:person, :company, :country)
                     .ordered_newest
                     .with_email
    @clients = @clients.search_by_name(params[:search])     if params[:search].present?
    @clients = @clients.by_type(params[:client_type])       if params[:client_type].present?
    @clients = @clients.by_country(params[:country_id])     if params[:country_id].present?
    @clients = @clients.where(status: Core::Client.statuses[params[:status]]) if params[:status].present?

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @clients }
    end
  end

  # GET /core/clients/1
  # GET /core/clients/1.json
  def show
    respond_to do |format|
      format.html
      format.json { render json: @client }
    end
  end

  # GET /core/clients/new
  def new
    @client = Core::Client.new
  end

  # GET /core/clients/1/edit
  def edit; end

  # POST /core/clients
  # POST /core/clients.json
  def create
    @client = Core::Client.new(client_params)
    if @client.save
      respond_to do |format|
        format.html { redirect_to client_path(@client), notice: 'Cliente creado correctamente.' }
        format.json { render json: @client, status: :created }
      end
    else
      respond_to do |format|
        format.html { render :new }
        format.json { render json: @client.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /core/clients/1
  # PATCH/PUT /core/clients/1.json
  def update
    if @client.update(client_params)
      respond_to do |format|
        format.html { redirect_to client_path(@client), notice: 'Cliente actualizado correctamente.' }
        format.json { render json: @client, status: :ok }
      end
    else
      respond_to do |format|
        format.html { render :edit }
        format.json { render json: @client.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /core/clients/1
  # DELETE /core/clients/1.json
  def destroy
    @client.destroy
    respond_to do |format|
      format.html { redirect_to clients_path, notice: 'Cliente eliminado.' }
      format.json { head :no_content }
    end
  end

  private

  def set_client
    @client = Core::Client.find(params[:id])
  end

  def client_params
    params.require(:client).permit(
      :client_type, :status, :email, :phone,
      :street, :city, :state, :postal_code,
      :country_id, :person_id, :company_id
    )
  end

  def load_collections
    @countries = Core::Country.order(:name)
    @people    = Hr::Person.order(:last_name, :first_name)
    @companies = Core::Company.order(:company_name)
  end

  # Limpiar person_id o company_id según client_type
  def sanitize_client_associations
    return unless params[:client]
    case params[:client][:client_type]
    when 'individual'
      params[:client][:company_id] = nil
    when 'company'
      params[:client][:person_id] = nil
    end
  end
end