module Authentication
  extend ActiveSupport::Concern

  included do
    before_action :authenticate_user!
    helper_method :authenticated?
  end

  class_methods do
    def allow_unauthenticated_access(**options)
      skip_before_action :authenticate_user!, **options
    end
  end

  private

  def authenticated?
    user_signed_in?
  end

  def after_authentication_url
    stored_location_for(current_user) || root_path
  end
end
