class DepartmentsController < ApplicationController
  before_action :set_department, only: %i[show edit update destroy]
  before_action :load_roots,      only: %i[index]
  before_action :load_all,        only: %i[new edit create update]

  # GET /core/departments
  def index
    # Muestra todos los departamentos ordenados por jerarquía
    @departments = Core::Department.ordered_by_name.includes(:parent)
  end

  # GET /core/departments/:id
  def show
    # @department ya está seteado por set_department
  end

  # GET /core/departments/new
  def new
    @department = Core::Department.new
  end

  # POST /core/departments
  def create
    @department = Core::Department.new(department_params)

    if @department.save
      redirect_to core_department_path(@department),
                  notice: "Departamento “#{@department.name}” creado correctamente."
    else
      # Si falla la validación, recargamos las listas y volvemos a mostrar el formulario
      load_all
      render :new, status: :unprocessable_entity
    end
  end

  # GET /core/departments/:id/edit
  def edit
    # @department ya está seteado por set_department
  end

  # PATCH/PUT /core/departments/:id
  def update
    if @department.update(department_params)
      redirect_to core_department_path(@department),
                  notice: "Departamento “#{@department.name}” actualizado correctamente."
    else
      load_all
      render :edit, status: :unprocessable_entity
    end
  end

  # DELETE /core/departments/:id
  def destroy
    nombre = @department.name
    @department.destroy
    redirect_to core_departments_path,
                notice: "Departamento “#{nombre}” eliminado correctamente."
  end

  private

  # Busca el departamento por su ID y lo asigna a @department
  def set_department
    @department = Core::Department.find(params[:id])
  end

  # Carga únicamente los departamentos raíz (opcional, para listar en el index)
  def load_roots
    @root_departments = Core::Department.roots.ordered_by_name
  end

  # Carga la lista completa de departamentos para usar como posibles padres
  # (no excluye ciclos; la validación del modelo se encarga de impedir jerarquías inválidas)
  def load_all
    @all_departments = Core::Department.ordered_by_name
  end

  # Solo permite los parámetros seguros para crear/actualizar un departamento
  def department_params
    params.require(:core_department).permit(
      :name,
      :code,
      :parent_id
    )
  end
end