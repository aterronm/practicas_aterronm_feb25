class EmployeeContractsController < ApplicationController
  before_action :set_employee_contract, only: %i[ show edit update destroy ]

  # GET /employee_contracts or /employee_contracts.json
  def index
    @employee_contracts = EmployeeContract.all
  end

  # GET /employee_contracts/1 or /employee_contracts/1.json
  def show
  end

  # GET /employee_contracts/new
  def new
    @employee_contract = EmployeeContract.new
  end

  # GET /employee_contracts/1/edit
  def edit
  end

  # POST /employee_contracts or /employee_contracts.json
  def create
    @employee_contract = EmployeeContract.new(employee_contract_params)

    respond_to do |format|
      if @employee_contract.save
        format.html { redirect_to @employee_contract, notice: "Employee contract was successfully created." }
        format.json { render :show, status: :created, location: @employee_contract }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @employee_contract.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /employee_contracts/1 or /employee_contracts/1.json
  def update
    respond_to do |format|
      if @employee_contract.update(employee_contract_params)
        format.html { redirect_to @employee_contract, notice: "Employee contract was successfully updated." }
        format.json { render :show, status: :ok, location: @employee_contract }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @employee_contract.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /employee_contracts/1 or /employee_contracts/1.json
  def destroy
    @employee_contract.destroy!

    respond_to do |format|
      format.html { redirect_to employee_contracts_path, status: :see_other, notice: "Employee contract was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_employee_contract
      @employee_contract = EmployeeContract.find(params.expect(:id))
    end

    # Only allow a list of trusted parameters through.
    def employee_contract_params
      params.fetch(:employee_contract, {})
    end
end
