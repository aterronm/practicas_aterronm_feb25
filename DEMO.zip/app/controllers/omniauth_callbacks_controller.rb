class GoogleAccounts::OmniauthCallbacksController < Devise::OmniauthCallbacksController
  def google_oauth2
    # Construye o actualiza la cuenta desde los datos de OmniAuth
    @account = GoogleAccount.from_omniauth(request.env['omniauth.auth'])

    if @account.persisted?
      # Actualiza la fecha del último login
      @account.touch_login!

      # Asegúrate de que exista una Person asociada
      unless @account.person
        @account.create_person!(
          name:  @account.name,
          email: @account.email
        )
      end

      # Inicia sesión y redirige
      sign_in_and_redirect @account, event: :authentication
      set_flash_message(:notice, :success, kind: 'Google') if is_navigational_format?
    else
      # En caso de error, guarda datos y redirige al registro
      session['devise.google_data'] = request.env['omniauth.auth'].except('extra')
      redirect_to new_google_account_registration_url,
                  alert: @account.errors.full_messages.join("\n")
    end
  end

  # Si añades más proveedores, repite el patrón:
  # def github
  #   ...
  # end
end
