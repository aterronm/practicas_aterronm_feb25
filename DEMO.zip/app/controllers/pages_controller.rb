# app/controllers/pages_controller.rb
class PagesController < ApplicationController
  # sustituye :authenticate_user! o el before_action que tú uses
  skip_before_action :authenticate_user!, only: :login
  layout false, only: [:login]


  def login
    # Rails renderizará automáticamente app/views/pages/home.html.erb
  end
end
