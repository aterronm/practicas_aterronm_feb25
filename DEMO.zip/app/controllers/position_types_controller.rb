class PositionTypesController < ApplicationController
  before_action :set_position_type, only: %i[ show edit update destroy ]

  # GET /position_types or /position_types.json
  def index
    @position_types = PositionType.all
  end

  # GET /position_types/1 or /position_types/1.json
  def show
  end

  # GET /position_types/new
  def new
    @position_type = PositionType.new
  end

  # GET /position_types/1/edit
  def edit
  end

  # POST /position_types or /position_types.json
  def create
    @position_type = PositionType.new(position_type_params)

    respond_to do |format|
      if @position_type.save
        format.html { redirect_to @position_type, notice: "Position type was successfully created." }
        format.json { render :show, status: :created, location: @position_type }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @position_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /position_types/1 or /position_types/1.json
  def update
    respond_to do |format|
      if @position_type.update(position_type_params)
        format.html { redirect_to @position_type, notice: "Position type was successfully updated." }
        format.json { render :show, status: :ok, location: @position_type }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @position_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /position_types/1 or /position_types/1.json
  def destroy
    @position_type.destroy!

    respond_to do |format|
      format.html { redirect_to position_types_path, status: :see_other, notice: "Position type was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_position_type
      @position_type = PositionType.find(params.expect(:id))
    end

    # Only allow a list of trusted parameters through.
    def position_type_params
      params.fetch(:position_type, {})
    end
end
