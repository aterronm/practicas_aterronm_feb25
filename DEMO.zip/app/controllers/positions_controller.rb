class PositionsController < ApplicationController

  skip_before_action :authenticate_user!, only: [:index]

  before_action :set_position, only: %i[ show edit update destroy ]
  before_action :load_form_collections, only: [:index, :new, :edit]


  # GET /positions or /positions.json
  def index

    # 2) Cargamos las opciones de contract_type y job_level a partir de los enums
    @contract_types = Hr::Position.contract_types.keys  # e.g. ["permanent","temporary","contractor"]
    @job_levels    = Hr::Position.job_levels.keys       # e.g. ["junior","mid","senior","lead"]

    # 3) Iniciamos la colección de posiciones
    positions = Hr::Position.includes(:person, :department).order(id: :asc)

    # 4) Filtro “Search” sobre nombre/email de la persona, si viene params[:q]
    if params[:q].present?
      keyword = "%#{params[:q]}%"
      positions = positions.left_joins(:person)
                           .where("people.first_name ILIKE :kw OR people.last_name ILIKE :kw OR people.email ILIKE :kw", kw: keyword)
    end

    # 5) Filtro por departamento usando el scope existente
    if params[:department_id].present?
      positions = positions.by_department(params[:department_id])
    end

    # 6) Filtro por tipo de contrato usando el scope
    if params[:contract_type].present?
      # El scope espera la clave del enum, p. ej. "permanent"
      positions = positions.by_contract(params[:contract_type])
    end

    # 7) Filtro por nivel de trabajo usando el scope
    if params[:job_level].present?
      # El scope espera la clave del enum, p. ej. "senior"
      positions = positions.by_job_level(params[:job_level])
    end

    # 8) (Opcional) Filtro por estado “active” o “vacant” si lo quieres exponer
    if params[:status].present? && Hr::Position.statuses.key?(params[:status])
      positions = positions.public_send(params[:status])  # equivale a .active o .vacant
    end

    # 9) Paginación con Kaminari
    @positions = positions.page(params[:page]).per(10)

    @position    = Hr::Position.new

  end

  def load_form_collections
    @people      = Hr::Person.all.order(:first_name, :last_name)
    @departments = Core::Department.ordered_by_name
    @supervisors = Hr::Position.includes(:person).order(:job_code)
  end

  # GET /positions/1 or /positions/1.json
  def show
  end

  # GET /positions/new
  def new
    @position = Hr::Position.new
  end

  # GET /positions/1/edit
  def edit
  end

  # POST /positions or /positions.json
  def create
    @position = Hr::Position.new(position_params)

    respond_to do |format|
      if @position.save
        format.html { redirect_to @position, notice: "Position was successfully created." }
        format.json { render :show, status: :created, location: @position }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @position.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /positions/1 or /positions/1.json
  def update
    respond_to do |format|
      if @position.update(position_params)
        format.html { redirect_to @position, notice: "Position was successfully updated." }
        format.json { render :show, status: :ok, location: @position }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @position.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /positions/1 or /positions/1.json
  def destroy
    @position.destroy!

    respond_to do |format|
      format.html { redirect_to positions_path, status: :see_other, notice: "Position was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_position
      @position = Hr::Position.find(params[:id])
    end

  def position_params
    params.require(:position)
          .permit(
            :person_id, :department_id, :supervisor_id,
            :contract_type, :status, :shift_type, :job_level,
            :job_code, :title, :description,
            :salary_min, :salary_max, :probation_period_days,
            :hours_per_week,
            :start_date, :end_date,
            :notice_period_days, :termination_reason,
            :termination_date, :cost_center_code,
            :project_code, :manager,
            benefits: [],
          )
  end

end
