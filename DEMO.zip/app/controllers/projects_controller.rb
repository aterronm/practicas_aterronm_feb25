# app/controllers/projects_controller.rb
class ProjectsController < ApplicationController
  skip_before_action :authenticate_user!, only: %i[index show new create update]

  before_action :set_project,   only: %i[show edit update destroy]
  before_action :set_clients,   only: %i[index new create edit update show]
  before_action :load_people,    only: %i[show new edit update]

  # GET /projects
  def index
    @projects = Pm::Project
      .includes(:client, :project_memberships)
      .order(created_at: :desc)

    # Nuevo proyecto para el modal de creación rápida
    @project = Pm::Project.new
    @tasks = @project.tasks

    @clients  = Core::Client.includes(:person, :company).map do |c|
      name = if c.individual? && c.person
        "#{c.person.first_name} #{c.person.last_name}"
      elsif c.company
        c.company.company_name
      else
        "—"
      end
      [name, c.id]
    end

    # Conteo de tareas por estado (para las métricas)
    counts    = @project.tasks.group(:status).count
    @task_counts = Pm::Task.statuses.keys.index_with { |st| counts[st] || 0 }

    # Búsqueda global de proyectos
    if params[:q].present?
      kw = "%#{params[:q].strip}%"
      @projects = @projects.where("name ILIKE ?", kw)
    end
  end

  # GET /projects/:id
  def show
    # Para el modal de nueva tarea
    @task   = @project.tasks.build

    # filtrado por status y búsqueda
    @tasks = @project.tasks.order(status: :asc)
    if params[:status].present?
      @tasks = @tasks.where(status: Pm::Task.statuses[params[:status]])
    end
    if params[:q].present?
      @tasks = @tasks.where("title ILIKE ?", "%#{params[:q].strip}%")
    end

    # Conteo de tareas por estado (cards)
    counts       = @project.tasks.group(:status).count
    @task_counts = Pm::Task.statuses.keys.index_with { |st| counts[st] || 0 }
  end

  # GET /projects/new
  def new
    @project = Pm::Project.new
  end

  # POST /projects
  def create
    @project = Pm::Project.new(project_params)
    if @project.save
      redirect_to project_path(@project), notice: "Proyecto creado con éxito."
    else
      flash.now[:alert] = "No se pudo crear el proyecto."
      render :new, status: :unprocessable_entity
    end
  end

  # GET /projects/:id/edit
  def edit
  end

  # PATCH/PUT /projects/:id
  def update
    if @project.update(project_params)
      redirect_to project_path(@project), notice: "Proyecto actualizado con éxito."
    else
      flash.now[:alert] = "No se pudo actualizar el proyecto."
      render :edit, status: :unprocessable_entity
    end
  end

  # DELETE /projects/:id
  def destroy
    @project.destroy
    redirect_to projects_path, notice: "Proyecto eliminado.", status: :see_other
  end

  private

  def set_project
    @project = Pm::Project.find(params[:id])
  rescue ActiveRecord::RecordNotFound
    redirect_to projects_path, alert: "Proyecto no encontrado."
  end

  def set_clients
    @clients = Core::Client
      .includes(:person, :company)
      .map do |c|
      name = if c.person.present?
        "#{c.person.first_name} #{c.person.last_name}"
      elsif c.company.present?
        c.company.company_name
      else
        "—"
      end
      [name, c.id]
    end
  end

  def load_people
    @people = Hr::Person.all.map { |p| ["#{p.first_name} #{p.last_name}", p.id] }
  end

  def project_params
    params
      .require(Pm::Project.model_name.param_key)
      .permit(
        :client_id, :code, :name, :description,
        :start_date, :end_date_estimated, :end_date_actual,
        :status, :project_type, :priority,
        :budget, :currency,
        :photo,
        project_memberships_attributes: [
          :id, :person_id, :role, :start_date, :end_date,
          :allocated_hours, :actual_hours, :hourly_rate,
          :responsibilities, :notes, :_destroy
        ]
      )
  end
end
