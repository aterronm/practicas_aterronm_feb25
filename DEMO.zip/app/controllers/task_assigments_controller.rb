class TaskAssigmentsController < ApplicationController
  before_action :set_task_assigment, only: %i[ show edit update destroy ]

  # GET /task_assigments or /task_assigments.json
  def index
    @task_assigments = TaskAssigment.all
  end

  # GET /task_assigments/1 or /task_assigments/1.json
  def show
  end

  # GET /task_assigments/new
  def new
    @task_assigment = TaskAssigment.new
  end

  # GET /task_assigments/1/edit
  def edit
  end

  # POST /task_assigments or /task_assigments.json
  def create
    @task_assigment = TaskAssigment.new(task_assigment_params)

    respond_to do |format|
      if @task_assigment.save
        format.html { redirect_to @task_assigment, notice: "Task assigment was successfully created." }
        format.json { render :show, status: :created, location: @task_assigment }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @task_assigment.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /task_assigments/1 or /task_assigments/1.json
  def update
    respond_to do |format|
      if @task_assigment.update(task_assigment_params)
        format.html { redirect_to @task_assigment, notice: "Task assigment was successfully updated." }
        format.json { render :show, status: :ok, location: @task_assigment }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @task_assigment.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /task_assigments/1 or /task_assigments/1.json
  def destroy
    @task_assigment.destroy!

    respond_to do |format|
      format.html { redirect_to task_assigments_path, status: :see_other, notice: "Task assigment was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_task_assigment
      @task_assigment = TaskAssigment.find(params.expect(:id))
    end

    # Only allow a list of trusted parameters through.
    def task_assigment_params
      params.fetch(:task_assigment, {})
    end
end
