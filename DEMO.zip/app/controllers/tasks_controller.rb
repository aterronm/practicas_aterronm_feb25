# app/controllers/projects/tasks_controller.rb
module Projects
  class TasksController < ApplicationController
    before_action :set_project
    before_action :set_task, only: %i[show edit update destroy show]
    before_action :load_people, only: %i[index new create edit update show]

    def new
      @task = @project.tasks.build
    end

    def edit
    end

    def create
      @task = @project.tasks.new(task_params)
      if @task.save
        redirect_to project_path(@project), notice: "Tarea creada."
      else
        flash.now[:alert] = "No se pudo crear la tarea."
        render :show, status: :unprocessable_entity
      end
    end

    def update
      if @task.update(task_params)
        redirect_to project_path(@project), notice: "Tarea actualizada con éxito."
      else
        render :edit, status: :unprocessable_entity
      end
    end

    def destroy
      @task.destroy
      redirect_to project_path(@project), notice: "Tarea eliminada."
    end

    private

    def set_project
      @project = Pm::Project.find(params[:project_id])
    end

    def set_task
      @task = @project.tasks.find(params[:id])
    end

    def load_people
      @people = Hr::Person.all.map { |p| ["#{p.first_name} #{p.last_name}", p.id] }
    end

    def task_params
      params.require(:task).permit(
        :assignee_id,
        :title, :description, :status, :work_type,
        :estimated_hours, :started_at, :completed_at, :notes,
        attachments: []
      )
    end
  end
end
