module ApplicationHelper
  def nav_link_to(name, path, mobile: false)
    active = current_page?(path)
    base_classes = mobile ?
      "block pl-3 pr-4 py-2 border-l-4 text-base font-medium" :
      "inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"

    active_classes = mobile ?
      "bg-indigo-50 border-indigo-500 text-indigo-700" :
      "border-indigo-500 text-gray-900"

    inactive_classes = mobile ?
      "border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800" :
      "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"

    classes = [base_classes, (active ? active_classes : inactive_classes)].join(' ')
    link_to name, path, class: classes
  end

  def sidebar_link_classes(active: current_page?(request.path))
    base = "flex items-center px-6 py-2 rounded-lg transition-colors duration-200"
    active ? "#{base} bg-gray-700 text-white" : "#{base} hover:bg-gray-700 hover:text-white text-gray-300"
  end
end

