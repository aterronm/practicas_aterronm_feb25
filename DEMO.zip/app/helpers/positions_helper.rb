module PositionsHelper
end
