// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import 'flowbite';
import 'flowbite-datepicker';

import { Application } from "@hotwired/stimulus"
import SidebarController from "./controllers/sidebar_controller"

const application = Application.start()
application.register("sidebar", SidebarController)

