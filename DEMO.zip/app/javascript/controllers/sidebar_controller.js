// app/javascript/controllers/sidebar_controller.js
import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
    static targets = []

    connect() {
        // cerrar si clicas fuera
        document.addEventListener("click", this.closeOnClickOutside.bind(this))
    }

    disconnect() {
        document.removeEventListener("click", this.closeOnClickOutside.bind(this))
    }

    toggle(event) {
        event.stopPropagation()
        this.element.classList.toggle("-translate-x-full")
    }

    closeOnClickOutside(event) {
        if (!this.element.contains(event.target) && window.innerWidth < 768) {
            this.element.classList.add("-translate-x-full")
        }
    }
}
