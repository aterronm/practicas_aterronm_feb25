class ApplicationMailer < ActionMailer::Base
  default from: "aterronm03@hotmail.com"
  layout "mailer"
end
