# app/models/concerns/normalizable.rb
module Normalizable
  extend ActiveSupport::Concern

  included do
    # Ejecuta la normalización de campos antes de las validaciones
    before_validation :normalize_fields
  end

  private

  # Normaliza formatos y espacios en blanco de distintos atributos
  def normalize_fields
    # Nombres y apellidos: strip + titleize
    self.first_name              = first_name.to_s.strip.titleize
    self.last_name               = last_name.to_s.strip.titleize

    # Identificación y datos fiscales: eliminar caracteres no alfanuméricos y upcase
    self.identification_type     = identification_type.to_s.strip
    self.identification_number   = identification_number.to_s.gsub(/\W/, "").upcase
    self.social_security_number  = social_security_number.to_s.gsub(/\W/, "").upcase
    self.tax_identification_number = tax_identification_number.to_s.gsub(/\W/, "").upcase



    # Contacto: normalize email y teléfonos
    self.email                   = email.to_s.strip.downcase
    self.phone                   = phone.to_s.gsub(/[^0-9+]/, "")
    self.mobile_phone            = mobile_phone.to_s.gsub(/[^0-9+]/, "") if mobile_phone
    self.secondary_phone         = secondary_phone.to_s.gsub(/[^0-9+]/, "") if secondary_phone

    # Dirección principal: strip + titleize/uppercase
    self.street                  = street.to_s.strip.titleize
    self.city                    = city.to_s.strip.titleize
    self.state                   = state.to_s.strip.upcase
    self.postal_code             = postal_code.to_s.strip.upcase

    # Datos bancarios: strip + uppercase
    self.bank_iban               = bank_iban.to_s.strip.upcase if bank_iban
    self.bank_bic                = bank_bic.to_s.strip.upcase if bank_bic
    self.bank_name               = bank_name.to_s.strip.titleize if bank_name

  end
end
