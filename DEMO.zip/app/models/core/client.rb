# app/models/client.rb
module Core
  class Client < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES
  # ------------------------------------------------------------
  enum :client_type, { individual: 0, company: 1 }
  enum :status,      { active: 0, inactive: 1, suspended: 2 }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  # Cada cliente “individual” debe apuntar a un registro en hr_persons
  belongs_to :person,  class_name: 'Hr::Person',   optional: true

  # Cada cliente “company” debe apuntar a un registro en companies
  belongs_to :company, class_name: 'Core::Company',      optional: true

  # Asociación al país vía country_id
  belongs_to :country, class_name: 'Core::Country'

  # ------------------------------------------------------------
  # VALIDACIONES COMUNES PARA TODOS LOS CLIENTES
  # ------------------------------------------------------------
  validates :client_type, presence: true
  validates :status,      presence: true

  validates :email,
            presence:   true,
            uniqueness: { case_sensitive: false },
            length:     { maximum: 255 },
            format:     { with: URI::MailTo::EMAIL_REGEXP }

  validates :phone,
            presence: true,
            format:   { with: /\A\+?[0-9]{7,15}\z/, message: "debe ser un número válido (7–15 dígitos)" }

  validates :street,       :city, :state, :postal_code, :country, presence: true
  validates :postal_code,  length: { maximum: 20 }

  # ------------------------------------------------------------
  # VALIDACIONES CONDICIONALES SEGÚN client_type
  # ------------------------------------------------------------
  # 1) Si es persona física (individual), exige person_id y no company_id
  with_options if: :individual? do
    validates :person,  presence: true
    validates :company, absence:  true
  end

  # 2) Si es empresa (company), exige company_id y no person_id
  with_options if: :company? do
    validates :company, presence: true
    validates :person,  absence:  true
  end

  # ------------------------------------------------------------
  # NORMALIZACIÓN BÁSICA (solo sobre los campos que quedan en Client)
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.email       = email.to_s.strip.downcase
    self.street      = street.to_s.strip.titleize
    self.city        = city.to_s.strip.titleize
    self.state       = state.to_s.strip.upcase
    self.postal_code = postal_code.to_s.strip.upcase
    self.phone       = phone.to_s.gsub(/\D/, "")
  end

  # ------------------------------------------------------------
  # SCOPES (FILTROS) PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :active,         -> { where(status: statuses[:active]) }
  scope :inactive,       -> { where(status: statuses[:inactive]) }
  scope :by_type,        ->(type)    { where(client_type: client_types[type]) }
  scope :by_country,     ->(country_id) { where(country_id: country_id) }
  scope :recent,         ->(days=7)  { where('created_at >= ?', days.days.ago) }
  scope :ordered_newest, ->          { order(created_at: :desc) }
  scope :with_email,     -> { where.not(email: [nil, ""])   }

  # Búsqueda por nombre:
  #   - Si es individual, busca en hr_persons (first_name, last_name).
  #   - Si es company, busca en companies (company_name).
  # Ejemplo combinado:


  scope :search_by_name, ->(term) {
    t = "%#{term.strip.downcase}%"
    left_joins(:person, :company)
      .where(
        "LOWER(people.first_name) LIKE :t OR " \
          "LOWER(people.last_name)  LIKE :t OR " \
          "LOWER(companies.company_name) LIKE :t",
        t: t
      )
  }
end

end
