# app/models/company.rb
module Core
class Company < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES
  # ------------------------------------------------------------
  # Estado legal de la empresa
  enum :status, {
    active:       0,  # Activa
    inactive:     1,  # Inactiva (no opera actualmente)
    dissolved:    2,  # Disuelta
    bankrupt:     3   # En concurso / quiebra
  }

  # Forma jurídica más común en España/Europa
  enum :legal_form, {
    sl:        0,  # Sociedad Limitada (S.L.)
    sa:        1,  # Sociedad Anónima (S.A.)
    cooperative: 2,# Cooperativa
    snc:       3,  # Sociedad en Nombre Colectivo
    sc:        4,  # Sociedad Civil
    other:     5   # Otra forma jurídica
  }


  # ------------------------------------------------------------
  # VALIDACIONES GENERALES
  # ------------------------------------------------------------
  validates :company_name,
            presence:   true,
            uniqueness: { case_sensitive: false },
            length:     { maximum: 255 }

  validates :status, :legal_form,
            presence: true

  # CIF/NIF: obligatorio, único, formato alfanumérico (letra + 8 dígitos + letra opcional)
  validates :tax_id,
            presence:   true,
            uniqueness: true,
            format:     {
              with: /\A[A-ZÑ&]{1}[0-9]{7}[A-Z0-9]{1}\z/,
              message: "debe tener formato CIF/NIF válido"
            }

  # Número de registro mercantil: e.g. tomo, folio, sección…
  validates :registration_number,
            presence:   true,
            uniqueness: true,
            length:     { maximum: 100 }

  # Número VAT intracomunitario: opcional, pero si está presente, formato UE
  validates :vat_number,
            allow_blank: true,
            format: {
              with: /\AE[A-Z0-9]{8,12}\z/,
              message: "debe tener formato VAT UE válido (E + 8–12 caracteres)"
            }

  # ------------------------------------------------------------
  # DATOS DE CONTACTO
  # ------------------------------------------------------------
  validates :email,
            presence:   true,
            uniqueness: { case_sensitive: false },
            length:     { maximum: 255 },
            format:     { with: URI::MailTo::EMAIL_REGEXP }

  validates :phone,
            allow_blank: true,
            format:     { with: /\A\+?[0-9 ]{7,20}\z/, message: "número inválido" }

  validates :website,
            allow_blank: true,
            format:     { with: /\Ahttps?:\/\/[\S]+\z/, message: "debe ser una URL válida" }

  # ------------------------------------------------------------
  # DIRECCIÓN FISCAL
  # ------------------------------------------------------------
  validates :street, :city, :state, :postal_code, :country,
            presence: true

  validates :postal_code,
            length: { maximum: 20 }

  validates :country,
            length: { is: 2 }, # ISO2
            format: { with: /\A[A-Z]{2}\z/, message: "código ISO2" }

  # ------------------------------------------------------------
  # DATOS ECONÓMICOS / FINANCIEROS
  # ------------------------------------------------------------
  # Código CNAE (Clasificación Nacional de Actividades Económicas)
  validates :cnae_code,
            presence:   true,
            format:     { with: /\A[0-9]{4}\z/, message: "debe tener 4 dígitos" }

  # Fecha de constitución / fundación
  validates :founded_on,
            presence: true,
            timeliness: { on_or_before: -> { Date.current }, type: :date }

  # Capital social (en euros)
  validates :share_capital,
            presence:   true,
            numericality: { greater_than_or_equal_to: 0 }

  # Número de empleados
  validates :employees_count,
            presence:   true,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 }

  # Año fiscal: inicio y fin de ejercicio contable
  validates :fiscal_year_start, :fiscal_year_end,
            presence: true
  validate  :fiscal_year_consistency

  # ------------------------------------------------------------
  # DATOS BANCARIOS
  # ------------------------------------------------------------
  # IBAN
  validates :bank_iban,
            presence: true,
            uniqueness: true,
            format:     { with: /\A[A-Z]{2}[0-9]{22}\z/, message: "formato IBAN inválido" }

  # SWIFT / BIC
  validates :bank_bic,
            allow_blank: true,
            format:     { with: /\A[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?\z/, message: "formato BIC inválido" }

  # Nombre del banco
  validates :bank_name,
            presence: true,
            length:   { maximum: 100 }

  # ------------------------------------------------------------
  # CALLBACKS PARA NORMALIZAR CAMPOS
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    # Limpiar y formatear cadenas
    self.company_name       = company_name.to_s.strip.titleize
    self.tax_id             = tax_id.to_s.strip.upcase
    self.registration_number= registration_number.to_s.strip.upcase
    self.vat_number         = vat_number.to_s.strip.upcase
    self.email              = email.to_s.strip.downcase
    self.phone              = phone.to_s.gsub(/[^0-9+]/, "")
    self.website            = website.to_s.strip
    self.street             = street.to_s.strip.titleize
    self.city               = city.to_s.strip.titleize
    self.state              = state.to_s.strip.upcase
    self.postal_code        = postal_code.to_s.strip.upcase
    self.country            = country.to_s.strip.upcase
    self.cnae_code          = cnae_code.to_s.strip
    self.bank_iban          = bank_iban.to_s.strip.upcase
    self.bank_bic           = bank_bic.to_s.strip.upcase
    self.bank_name          = bank_name.to_s.strip.titleize
  end

  # ------------------------------------------------------------
  # MÉTODO DE VALIDACIÓN PERSONALIZADO
  # ------------------------------------------------------------
  def fiscal_year_consistency
    return if fiscal_year_start.blank? || fiscal_year_end.blank?
    if fiscal_year_end <= fiscal_year_start
      errors.add(:fiscal_year_end, "debe ser posterior al inicio del ejercicio")
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS COMUNES
  # ------------------------------------------------------------
  # Empresas activas
  scope :active,       -> { where(status: statuses[:active]) }
  # Por forma jurídica
  scope :by_legal_form,->(form) { where(legal_form: legal_forms[form]) }
  # Por país
  scope :by_country,   ->(c)    { where(country: c.to_s.upcase) }
  # Por código CNAE
  scope :by_cnae,      ->(code) { where(cnae_code: code.to_s) }
  # Grandes empresas (empleados > 250)
  scope :large,        -> { where("employees_count > ?", 250) }
  # Pymes (empleados <= 250)
  scope :sme,          -> { where("employees_count <= ?", 250) }
  # Ordenar por fecha de fundación descendente
  scope :newest,       -> { order(founded_on: :desc) }

  # ------------------------------------------------------------
  # ASOCIACIONES (ajustar según necesidades)
  # ------------------------------------------------------------
  # has_many :clients
  # has_many :invoices
  # has_many :bank_accounts

  # ------------------------------------------------------------
  # MÉTODOS ADICIONALES
  # ------------------------------------------------------------
  # Devuelve la edad de la empresa en años
  def age
    return unless founded_on
    ((Date.current - founded_on) / 365).floor
  end
end
end
