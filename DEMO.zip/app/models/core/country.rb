# app/models/country.rb
module Core
  class Country < ApplicationRecord
  # ------------------------------------------------------------
  # CONSTANTS
  # ------------------------------------------------------------
  ISO2_REGEX = /\A[A-Z]{2}\z/
  ISO3_REGEX = /\A[A-Z]{3}\z/
  VALID_ISO2 = ->(value) { value.to_s.match?(ISO2_REGEX) }
  VALID_ISO3 = ->(value) { value.to_s.match?(ISO3_REGEX) }

  # ------------------------------------------------------------
  # ASSOCIATIONS
  # ------------------------------------------------------------
  has_one_attached :flag

  # ------------------------------------------------------------
  # VALIDATIONS
  # ------------------------------------------------------------
  validates :iso,
            presence: true,
            uniqueness: { case_sensitive: true },
            format: { with: ISO2_REGEX, message: 'debe ser código ISO2 (2 letras mayúsculas)' }

  validates :iso3,
            allow_blank: true,
            format: { with: ISO3_REGEX, message: 'debe ser código ISO3 (3 letras mayúsculas)' }

  validates :name,
            presence: true,
            length: { maximum: 80 }

  validates :nicename,
            presence: true,
            length: { maximum: 80 }

  validates :numcode,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 },
            allow_blank: true

  validates :phonecode,
            presence: true,
            numericality: { only_integer: true, greater_than: 0 }

  validate :flag_format

  # ------------------------------------------------------------
  # NORMALIZATION
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.iso       = iso.to_s.strip.upcase
    self.iso3      = iso3.to_s.strip.upcase if iso3
    self.name      = name.to_s.strip.titleize
    self.nicename  = nicename.to_s.strip.titleize
    self.phonecode = phonecode.to_i if phonecode
    self.numcode   = numcode.to_i if numcode
  end

  # ------------------------------------------------------------
  # FLAG VALIDATION
  # ------------------------------------------------------------
  def flag_format
    return unless flag.attached?
    acceptable_types = ['image/png', 'image/jpeg']
    unless acceptable_types.include?(flag.content_type)
      errors.add(:flag, 'debe ser PNG o JPG')
    end

    if flag.blob.byte_size > 5.megabytes
      errors.add(:flag, 'tamaño máximo 5 MB')
    end
  end

  # ------------------------------------------------------------
  # SCOPES
  # ------------------------------------------------------------
  scope :ordered,      -> { order(nicename: :asc) }
  scope :by_iso,       ->(code) { where(iso: code.to_s.upcase) }
  scope :by_name,      ->(term) { where('LOWER(name) = ?', term.to_s.downcase) }
  scope :for_phonecode,->(pc)   { where(phonecode: pc.to_i) }

  # ------------------------------------------------------------
  # CUSTOM METHODS
  # ------------------------------------------------------------
  # Devuelve el nombre completo con código ISO
  def display_name
    "#{nicename} (#{iso})"
  end

  # Time zone asociado (si existe en base de datos adicional)
  def default_timezone
    tz_info || 'UTC'
  end
  end

  end