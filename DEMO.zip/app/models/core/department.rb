module Core

class Department < ApplicationRecord
  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  # Jerarquía
  belongs_to :parent, class_name: 'Core::Department', optional: true
  has_many   :subdepartments,
             class_name: 'Core::Department',
             foreign_key: 'parent_id',
             dependent: :nullify,
             inverse_of: :parent

  # Ahora tiene muchos puestos
  has_many :positions, dependent: :destroy

  # El “manager” es la Position con manager: true
  has_one  :manager_position, -> { where(manager: true) }, class_name: 'Hr::Position'
  has_one  :manager, through: :manager_position, source: :person

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :name,
            presence:   true,
            length:     { maximum: 100 },
            uniqueness: { case_sensitive: false }

  validates :code,
            presence:   true,
            length:     { maximum: 10 },
            format:     { with: /\A[A-Z0-9]+\z/, message: 'solo mayúsculas y dígitos' },
            uniqueness: { case_sensitive: false }

  validate :parent_must_not_be_self_or_descendant

  # ------------------------------------------------------------
  # CALLBACKS
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.name = name.to_s.strip.titleize if name_changed?
    self.code = code.to_s.strip.upcase    if code_changed?
  end

  # ------------------------------------------------------------
  # VALIDACIÓN DE JERARQUÍA
  # ------------------------------------------------------------
  def parent_must_not_be_self_or_descendant
    return if parent_id.blank?

    if parent_id == id
      errors.add(:parent, 'no puede ser el mismo departamento')
    elsif subdepartments.exists?(id: parent_id)
      errors.add(:parent, 'no puede ser un subdepartamento directo')
    elsif ancestor_ids.include?(id)
      errors.add(:parent, 'crea un bucle en la jerarquía')
    end
  end

  # ------------------------------------------------------------
  # MÉTODOS DE JERARQUÍA
  # ------------------------------------------------------------
  def ancestor_ids
    return [] unless parent
    [parent_id] + parent.ancestor_ids
  end

  def ancestors
    parent ? [parent] + parent.ancestors : []
  end

  # ------------------------------------------------------------
  # SCOPES
  # ------------------------------------------------------------
  scope :ordered_by_name, -> { order(name: :asc) }
  scope :roots,          -> { where(parent_id: nil) }

  # ------------------------------------------------------------
  # MÉTODOS ADICIONALES
  # ------------------------------------------------------------
  def subdepartments_count
    subdepartments.size
  end

  def root?
    parent_id.nil?
  end

  def full_hierarchy_name
    ancestors.reverse.map(&:name).push(name).join(' > ')
  end
end

end

