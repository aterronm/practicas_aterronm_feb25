module Core

class Role < ApplicationRecord
  # ------------------------------------------------------------
  # ASOCIACIÓN A USUARIOS
  # (Se asume que habrá un modelo User con columna role_id)
  # ------------------------------------------------------------
  has_many :users, dependent: :nullify

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :code,
            presence:   true,
            uniqueness: { case_sensitive: false },
            length:     { maximum: 50 },
            format:     { with: /\A[a-z0-9_]+\z/, message: 'only lowercase letters, digits and underscores' }

  validates :name,
            presence:   true,
            uniqueness: { case_sensitive: false },
            length:     { maximum: 100 }

  validates :description,
            length:     { maximum: 1000 },
            allow_blank: true

  # ------------------------------------------------------------
  # NORMALIZACIÓN PREVIA A VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.code = code.to_s.strip.downcase if code_changed?
    self.name = name.to_s.strip.titleize  if name_changed?
    self.description = description.to_s.strip if description_changed?
  end

  # ------------------------------------------------------------
  # SCOPES
  # ------------------------------------------------------------
  # Buscar roles por término en el nombre
  scope :search_by_name, ->(term) {
    where('LOWER(name) LIKE ?', "%#{term.to_s.strip.downcase}%")
  }

  # ------------------------------------------------------------
  # MÉTODOS ÚTILES
  # ------------------------------------------------------------
  def to_s
    name
  end
end

end

