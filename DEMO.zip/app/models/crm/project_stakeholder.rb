# app/models/project_stakeholder.rb
class ProjectStakeholder < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA ROLES DE STAKEHOLDER EN EL PROYECTO
  # ------------------------------------------------------------
  enum role: {
    sponsor:     0,  # Patrocinador del proyecto
    end_user:    1,  # Usuario final / cliente interno
    partner:     2,  # Socio / colaborador externo
    regulator:   3,  # Organismo regulador
    other:       4   # Otro rol
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :project         # Proyecto al que contribuye
  belongs_to :stakeholder     # Persona u organización interesada

  # ------------------------------------------------------------
  # CAMPOS (migración sugerida)
  # ------------------------------------------------------------
  # t.references :project,      null: false, foreign_key: true
  # t.references :stakeholder,  null: false, foreign_key: true
  # t.integer    :role,         null: false, default: 0
  # t.text       :notes                     # Observaciones sobre la implicación

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :project, :stakeholder, :role, presence: true
  validates :stakeholder_id,
            uniqueness: { scope: :project_id,
                          message: "ya está registrado en este proyecto" }
  validates :notes,
            length: { maximum: 1000 },
            allow_blank: true

  # ------------------------------------------------------------
  # NORMALIZACIÓN
  # ------------------------------------------------------------
  before_validation do
    self.notes = notes.to_s.strip if notes
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_project,     ->(proj) { where(project: proj) }
  scope :for_stakeholder, ->(s)    { where(stakeholder: s) }
  scope :by_role,         ->(r)    { where(role: roles[r]) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Obtiene el nombre legible del stakeholder
  def stakeholder_name
    stakeholder.respond_to?(:display_name) ? stakeholder.display_name : stakeholder.to_s
  end
end
