# app/models/provider.rb
class Provider < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA VALORES FIJOS
  # ------------------------------------------------------------
  # Tipo de proveedor: persona individual o empresa
  enum provider_type:   { individual: 0, company: 1 }
  # Estado de la relación con el proveedor
  enum status:          { active: 0, inactive: 1, suspended: 2, blocked: 3 }
  # Nivel de relación: de potencial a estratégico
  enum relationship_level: {
    potential: 0,    # Potencial
    approved: 1,     # Aprobado
    preferred: 2,    # Preferido
    strategic: 3,    # Estratégico
    blocked: 4       # Bloqueado
  }
  # Clasificación de riesgo (A = muy bajo, E = muy alto)
  enum risk_classification: { a: 0, b: 1, c: 2, d: 3, e: 4 }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  # País de sede principal
  belongs_to :country
  # País de residencia fiscal (opcional)
  belongs_to :tax_residency_country, class_name: 'Country', optional: true

  # Relación con órdenes de compra e facturas
  has_many :purchase_orders, dependent: :nullify
  has_many :invoices, through: :purchase_orders

  # Productos o servicios que ofrece el proveedor
  has_many :products, through: :purchase_orders

  # Documentación contractual y certificados
  has_one_attached  :contract_document
  has_many_attached :certificates

  # ------------------------------------------------------------
  # VALIDACIONES COMUNES
  # ------------------------------------------------------------
  validates :provider_type, :status, :relationship_level, :risk_classification, presence: true

  # Contacto principal
  validates :contact_name,
            presence:   true,
            length:     { maximum: 200 }
  validates :contact_email,
            presence:   true,
            length:     { maximum: 255 },
            format:     { with: URI::MailTo::EMAIL_REGEXP }
  validates :contact_phone,
            allow_blank: true,
            format:      { with: /\A\+?[0-9]{7,15}\z/, message: "debe tener entre 7 y 15 dígitos" }
  validates :website,
            allow_blank: true,
            format:      { with: /\Ahttps?:\/\/[\S]+\z/, message: "debe ser una URL válida" }

  # Términos económicos
  validates :payment_terms_days,
            presence:   true,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 }
  validates :lead_time_days,
            presence:   true,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 }
  validates :credit_limit,
            presence:   true,
            numericality: { greater_than_or_equal_to: 0 }

  # ------------------------------------------------------------
  # CAMPOS ESPECÍFICOS PARA PERSONA INDIVIDUAL
  # ------------------------------------------------------------
  with_options if: :individual? do
    validates :first_name, :last_name,
              presence: true, length: { maximum: 100 }
    validates :identification_number,
              presence:   true,
              uniqueness: true,
              length:     { in: 6..20 },
              format:     { with: /\A[A-Z0-9\-]+\z/, message: "formato inválido" }
  end

  # ------------------------------------------------------------
  # CAMPOS ESPECÍFICOS PARA EMPRESA
  # ------------------------------------------------------------
  with_options if: :company? do
    validates :company_name,
              presence:   true,
              uniqueness: { case_sensitive: false },
              length:     { maximum: 255 }
    validates :tax_id,
              presence:   true,
              uniqueness: true,
              format:     { with: /\A[A-ZÑ&]{1}[0-9]{7}[A-Z0-9]{1}\z/, message: "formato CIF/NIF inválido" }
    validates :registration_number,
              presence:   true,
              uniqueness: true,
              length:     { maximum: 50 }
    validates :vat_number,
              allow_blank: true,
              format:     { with: /\AE[A-Z0-9]{8,12}\z/, message: "debe ser VAT UE (E + 8–12 caracteres)" }
  end

  # ------------------------------------------------------------
  # DIRECCIÓN FISCAL
  # ------------------------------------------------------------
  validates :street, :city, :state, :postal_code, presence: true
  validates :street, :city,
            length: { maximum: 255 }
  validates :state,
            length: { maximum: 100 }
  validates :postal_code,
            length: { maximum: 20 }

  # ------------------------------------------------------------
  # VALIDACIONES DE ARCHIVOS ADJUNTOS (ActiveStorage)
  # ------------------------------------------------------------
  validate :acceptable_contract
  validate :acceptable_certificates

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields
  def normalize_fields
    # Contacto
    self.contact_name  = contact_name.to_s.strip.titleize
    self.contact_email = contact_email.to_s.strip.downcase
    self.contact_phone = contact_phone.to_s.gsub(/\D/, "")
    self.website       = website.to_s.strip

    # Dirección
    self.street      = street.to_s.strip.titleize
    self.city        = city.to_s.strip.titleize
    self.state       = state.to_s.strip.upcase
    self.postal_code = postal_code.to_s.strip.upcase

    # Individual vs Empresa
    if individual?
      self.first_name            = first_name.to_s.strip.titleize
      self.last_name             = last_name.to_s.strip.titleize
      self.identification_number = identification_number.to_s.gsub(/\W/, "").upcase
    elsif company?
      self.company_name        = company_name.to_s.strip.titleize
      self.tax_id              = tax_id.to_s.strip.upcase
      self.registration_number = registration_number.to_s.strip.upcase
      self.vat_number          = vat_number.to_s.strip.upcase if vat_number
    end
  end

  # Comprobación de tamaño y formato del contrato
  def acceptable_contract
    return unless contract_document.attached?
    if contract_document.byte_size > 10.megabytes
      errors.add(:contract_document, "es demasiado grande (máx. 10MB)")
    end
    unless ["application/pdf", "image/png", "image/jpeg"].include?(contract_document.content_type)
      errors.add(:contract_document, "debe ser PDF, PNG o JPG")
    end
  end

  # Comprobación de tamaño y formato de los certificados
  def acceptable_certificates
    certificates.each do |cert|
      if cert.byte_size > 5.megabytes
        errors.add(:certificates, "cada certificado debe pesar menos de 5MB")
      end
      unless ["application/pdf", "image/png", "image/jpeg"].include?(cert.content_type)
        errors.add(:certificates, "deben ser PDF, PNG o JPG")
      end
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :active,                   -> { where(status: statuses[:active]) }
  scope :by_type,                 ->(t) { where(provider_type: provider_types[t]) }
  scope :by_relationship_level,   ->(lvl) { where(relationship_level: relationship_levels[lvl]) }
  scope :by_country,              ->(iso) { joins(:country).where(countries: { iso: iso.upcase }) }
  scope :preferred,               -> { where(relationship_level: relationship_levels[:preferred]) }
  scope :strategic,               -> { where(relationship_level: relationship_levels[:strategic]) }
  scope :high_risk,               -> { where(risk_classification: [risk_classifications[:d], risk_classifications[:e]]) }
  scope :with_credit,             -> { where("credit_limit > 0") }

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------
  # Facturas vencidas
  def overdue_invoices
    invoices.where("due_date < ? AND paid = ?", Date.current, false)
  end

  # Número de facturas vencidas
  def overdue_invoices_count
    overdue_invoices.count
  end

  # Importe total pendiente de pago
  def total_unpaid_amount
    invoices.where(paid: false).sum(:amount)
  end

  # Crédito disponible
  def available_credit
    credit_limit - total_unpaid_amount
  end
end
