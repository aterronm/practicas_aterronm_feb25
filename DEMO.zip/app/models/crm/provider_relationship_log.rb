# app/models/provider_relationship_log.rb
class ProviderRelationshipLog < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA TIPOS DE EVENTO
  # ------------------------------------------------------------
  enum event_type: {
    created:                     0,  # Se añadió el proveedor al sistema
    level_changed:              1,  # Cambió el nivel de relación
    risk_classification_changed:2,  # Cambió la clasificación de riesgo
    order_placed:               3,  # Se creó una nueva orden de compra
    invoice_received:           4,  # Se recibió una factura
    payment_made:               5,  # Se realizó un pago
    rating_added:               6,  # Se añadió una nueva evaluación
    note:                       7   # Nota libre
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :provider                 # Proveedor relacionado
  belongs_to :company                  # Nuestra empresa
  belongs_to :user, optional: true     # Usuario que registró el evento

  # ------------------------------------------------------------
  # CAMPOS
  # ------------------------------------------------------------
  # event_type      :integer, not null
  # occurred_at     :datetime, not null
  # previous_value :string           # Valor anterior (p.ej. nivel antiguo)
  # new_value      :string           # Valor nuevo (p.ej. nivel actualizado)
  # notes          :text             # Detalles adicionales

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :event_type,
            presence: true
  validates :occurred_at,
            presence: true
  validates :notes,
            length: { maximum: 1000 },
            allow_blank: true

  # Si se documenta un cambio de nivel o riesgo, deben venir ambos valores
  validate :value_change_consistency

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.previous_value = previous_value.to_s.strip if previous_value
    self.new_value      = new_value.to_s.strip if new_value
    self.notes          = notes.to_s.strip if notes
  end

  def value_change_consistency
    if event_type.in?(%w[level_changed risk_classification_changed])
      if previous_value.blank? || new_value.blank?
        errors.add(:base, "Debe incluir previous_value y new_value para cambios de nivel o riesgo")
      end
    end
  end

  # ------------------------------------------------------------
  # SCOPES
  # ------------------------------------------------------------
  scope :for_provider, ->(prov) { where(provider: prov) }
  scope :for_company,  ->(comp) { where(company: comp) }
  scope :of_type,      ->(et)   { where(event_type: event_types[et]) }
  scope :since,        ->(time) { where("occurred_at >= ?", time) }
  scope :recent,       ->(limit = 10) { order(occurred_at: :desc).limit(limit) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  def description
    case event_type
    when "created"
      "Proveedor añadido al sistema"
    when "level_changed"
      "Nivel cambiado de #{previous_value} a #{new_value}"
    when "risk_classification_changed"
      "Riesgo clasificado de #{previous_value} a #{new_value}"
    when "order_placed"
      "Orden de compra registrada"
    when "invoice_received"
      "Factura recibida"
    when "payment_made"
      "Pago realizado"
    when "rating_added"
      "Evaluación registrada"
    else
      notes.presence || "Evento registrado"
    end
  end
end
