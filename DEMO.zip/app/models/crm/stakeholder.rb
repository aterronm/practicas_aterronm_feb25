# app/models/stakeholder.rb
class Stakeholder < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA EL TIPO DE STAKEHOLDER
  # ------------------------------------------------------------
  # Individual (persona) u organización (empresa u otra entidad)
  enum stakeholder_type: {
    individual:   0,
    organization: 1
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  # Polimórfico: puede ser una Person o una Company u otro modelo
  belongs_to :stakeholderable, polymorphic: true

  # Feedback recibido de este stakeholder
  has_many :stakeholder_feedbacks,
           foreign_key: :stakeholder_id,
           dependent: :nullify

  # Relación con proyectos (a través de un join model que definiremos)
  has_many :project_stakeholders,
           dependent: :destroy
  has_many :projects,
           through: :project_stakeholders

  # ------------------------------------------------------------
  # CAMPOS (migración sugerida)
  # ------------------------------------------------------------
  # t.string  :stakeholderable_type, null: false
  # t.bigint  :stakeholderable_id,   null: false
  # t.integer :stakeholder_type,     null: false, default: 0
  # t.text    :notes                            # Observaciones especiales

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :stakeholderable_type,
            presence: true,
            inclusion: { in: %w[Person Company] }
  validates :stakeholderable_id,
            presence: true
  validates :stakeholder_type,
            presence: true
  validates :notes,
            length: { maximum: 1000 },
            allow_blank: true

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields
  def normalize_fields
    self.notes = notes.to_s.strip if notes
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :individuals,   -> { where(stakeholder_type: stakeholder_types[:individual]) }
  scope :organizations, -> { where(stakeholder_type: stakeholder_types[:organization]) }
  scope :for_project,   ->(proj) { joins(:project_stakeholders).where(project_stakeholders: { project_id: proj.id }) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Nombre legible del stakeholder (delegado a Person o Company)
  def display_name
    if stakeholderable.respond_to?(:full_name)
      stakeholderable.full_name
    else
      stakeholderable.respond_to?(:company_name) ?
        stakeholderable.company_name :
        stakeholderable.to_s
    end
  end

  # Información de contacto si existe en el objeto asociado
  def contact_email
    stakeholderable.respond_to?(:email) ? stakeholderable.email : nil
  end

  def contact_phone
    stakeholderable.respond_to?(:phone) ? stakeholderable.phone : nil
  end
end

