# app/models/stakeholder_feedback.rb
class StakeholderFeedback < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA EL ESTADO DE LA ACCIÓN
  # ------------------------------------------------------------
  enum status: {
    new:          0,  # Feedback recibido, sin gestionar
    in_progress:  1,  # En proceso de acción
    resolved:     2,  # Acción completada
    closed:       3   # Cierre definitivo
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :project                         # Proyecto objeto del feedback
  belongs_to :release,  optional: true        # Release opcional asociada
  belongs_to :stakeholder                     # Stakeholder (Person o Company)
  belongs_to :responsible,
             class_name: 'Person',
             optional: true                  # Persona encargada de gestionar

  # Adjuntos opcionales (documentos, capturas, etc.)
  has_many_attached :documents

  # ------------------------------------------------------------
  # CAMPOS (migración sugerida)
  # ------------------------------------------------------------
  # t.references :project,       null: false, foreign_key: true
  # t.references :release,                     foreign_key: true
  # t.references :stakeholder,   null: false, foreign_key: true
  # t.references :responsible,                 foreign_key: { to_table: :people }
  # t.date       :received_on,    null: false
  # t.text       :feedback,       null: false
  # t.integer    :status,         null: false, default: 0
  # t.text       :action_plan                    # Plan de acción
  # t.date       :resolved_on                    # Fecha de resolución
  # t.text       :notes                          # Observaciones adicionales

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :project, :stakeholder, :received_on, :feedback, :status, presence: true
  validates :feedback, :action_plan, :notes,
            length: { maximum: 2000 },
            allow_blank: true
  validates :resolved_on,
            timeliness: { on_or_after: :received_on, type: :date },
            allow_blank: true

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields
  def normalize_fields
    self.feedback    = feedback.to_s.strip           if feedback
    self.action_plan = action_plan.to_s.strip        if action_plan
    self.notes       = notes.to_s.strip              if notes
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_project,      ->(proj) { where(project: proj) }
  scope :for_release,      ->(rel)  { where(release: rel) }
  scope :by_stakeholder,   ->(s)    { where(stakeholder: s) }
  scope :by_responsible,   ->(p)    { where(responsible: p) }
  scope :received_between, ->(from,to) { where(received_on: from..to) }
  scope :new,              ->       { where(status: statuses[:new]) }
  scope :in_progress,      ->       { where(status: statuses[:in_progress]) }
  scope :resolved,         ->       { where(status: statuses[:resolved]) }

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------
  # Marca como en proceso
  def start!
    update!(status: :in_progress) if new?
  end

  # Marca como resuelto y establece fecha
  def resolve!(date = Date.current)
    update!(status: :resolved, resolved_on: date)
  end

  # Cierra el feedback sin seguir acciones
  def close!
    update!(status: :closed)
  end
end
