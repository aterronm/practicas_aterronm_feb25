# app/models/supplier_rating.rb
class SupplierRating < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA CATEGORÍAS DE EVALUACIÓN
  # ------------------------------------------------------------
  enum category: {
    quality:      0, # Calidad de producto/servicio
    delivery:     1, # Cumplimiento de plazos
    price:        2, # Precio / competitividad
    compliance:   3, # Cumplimiento normativo
    relationship: 4, # Nivel de colaboración
    other:        5  # Otro
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :provider                # Proveedor evaluado
  belongs_to :company                 # Empresa que realiza la evaluación
  # Usuario que registró la evaluación (opcional)
  belongs_to :evaluated_by,
             class_name: 'User',
             optional: true

  # Documento de soporte (informe, scorecard, etc.)
  has_one_attached :document

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  # Fecha de la evaluación: obligatoria y no futura
  validates :rating_date,
            presence:   true,
            timeliness: { on_or_before: -> { Date.current }, type: :date }

  # Categoría de la evaluación: obligatoria
  validates :category, presence: true

  # Puntuación entre 0.0 y 5.0 (puede adaptarse a escala 1–10)
  validates :score,
            presence:     true,
            numericality: { greater_than_or_equal_to: 0.0,
                            less_than_or_equal_to:    5.0 }

  # Comentarios opcionales, largo máximo 1000 caracteres
  validates :comments,
            length: { maximum: 1000 },
            allow_blank: true

  # Validación del documento (PDF, JPG, PNG y tamaño ≤ 5 MB)
  validate :acceptable_document

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields
  def normalize_fields
    self.comments = comments.to_s.strip if comments
  end

  # ------------------------------------------------------------
  # MÉTODO DE VALIDACIÓN DE ADJUNTO
  # ------------------------------------------------------------
  def acceptable_document
    return unless document.attached?
    if document.byte_size > 5.megabytes
      errors.add(:document, "debe pesar menos de 5 MB")
    end
    acceptable = ["application/pdf", "image/png", "image/jpeg"]
    unless acceptable.include?(document.content_type)
      errors.add(:document, "debe ser PDF, PNG o JPG")
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  # Evaluaciones de un proveedor
  scope :for_provider, ->(prov)      { where(provider: prov) }
  # Evaluaciones realizadas por una empresa
  scope :for_company,  ->(comp)      { where(company: comp) }
  # Por categoría de evaluación
  scope :by_category,  ->(cat)       { where(category: categories[cat]) }
  # Puntuaciones altas (>= umbral)
  scope :high_scores,  ->(min=4.0)   { where("score >= ?", min) }
  # Puntuaciones bajas (<= umbral)
  scope :low_scores,   ->(max=2.0)   { where("score <= ?", max) }
  # Más recientes primero
  scope :recent,       ->(days=30)  { where('rating_date >= ?', days.days.ago) }
  # Ordenar por fecha descendente
  scope :ordered,      ->           { order(rating_date: :desc) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Edad de la evaluación en días
  def age_in_days
    return unless rating_date
    (Date.current - rating_date).to_i
  end

  # Estado textual de la puntuación
  def rating_label
    case score
    when 4.5..5.0 then "Excelente"
    when 3.5...4.5 then "Bueno"
    when 2.5...3.5 then "Aceptable"
    when 1.5...2.5 then "Deficiente"
    else                  "Muy Deficiente"
    end
  end
end
