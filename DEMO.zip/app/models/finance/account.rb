# app/models/account.rb

# Modelo: Account
# Representa una cuenta contable en el sistema de ERP, ya sea de balance (Activo, Pasivo, Patrimonio) o P&L (Ingresos, Gastos).
# ------------------------------------------------------------
# Propósito:
#   - Definir la jerarquía de cuentas (padre/subcuentas) para estructurar el plan contable.
#   - Clasificar cuentas por tipo (asset, liability, equity, revenue, expense).
#   - Asociar movimientos contables (ledger_entries) y calcular saldos.
#   - Facilitar informes financieros y consolidaciones.
#
# Mejoras implementadas:
#   1. Soporte de jerarquía con parent_account/sub_accounts.
#   2. Validaciones de unicidad y formato de código y nombre.
#   3. Callback de normalización de campos antes de validación.
#   4. Scopes para filtros comunes (por tipo, búsqueda por código/nombre, cuentas raíz o hijos).
#   5. Método auxiliar para calcular saldo actual.
#   6. Sugerencia de implementación de nested set (o gemas como `ancestry`) para consultas jerárquicas óptimas.
#
class Account < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES / TIPOS DE CUENTA
  # ------------------------------------------------------------
  # Define si la cuenta pertenece a Balance Sheet o P&L
  enum account_type: {
    asset:      0,  # Activo
    liability:  1,  # Pasivo
    equity:     2,  # Patrimonio Neto
    revenue:    3,  # Ingresos
    expense:    4   # Gastos
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  # Cuenta padre para estructurar jerarquía (opcional)
  belongs_to :parent_account,
             class_name: 'Account',
             optional: true

  # Subcuentas dependientes (si parent_account_id = esta cuenta)
  has_many :sub_accounts,
           class_name: 'Account',
           foreign_key: 'parent_account_id',
           dependent: :nullify

  # Movimientos contables que afectan esta cuenta
  has_many :ledger_entries,
           dependent: :restrict_with_error

  # ------------------------------------------------------------
  # MIGRACIÓN SUGERIDA
  # ------------------------------------------------------------
  # create_table :accounts do |t|
  #   t.string  :code,              null: false, unique: true  # Código interno (ej. 1000, 4000-ventas)
  #   t.string  :name,              null: false               # Nombre descriptivo
  #   t.integer :account_type,      null: false, default: 0    # Tipo de cuenta enum
  #   t.bigint  :parent_account_id                                # FK a esta misma tabla
  #   t.timestamps
  #
  #   # Índices para búsquedas y unicidad
  #   add_index :accounts, :code, unique: true
  #   add_index :accounts, :parent_account_id
  # end
  #
  # Opcional: migración para nested set (ancestry)
  # add_column :accounts, :ancestry, :string, index: true

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :code,
            presence:   true,
            uniqueness: { case_sensitive: false },
            length:     { maximum: 20 }

  validates :name,
            presence:   true,
            length:     { maximum: 255 }

  validates :account_type,
            presence: true,
            inclusion: { in: account_types.keys }

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    # Código mayúsculas y sin espacios extra
    self.code = code.to_s.strip.upcase
    # Nombre con formato título
    self.name = name.to_s.strip.titleize
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  # Filtrar por tipo de cuenta
  scope :by_type,       ->(t) { where(account_type: account_types[t]) }
  # Sólo cuentas raíz (sin padre)
  scope :roots,         ->     { where(parent_account_id: nil) }
  # Subcuentas de una cuenta dada
  scope :children_of,   ->(acct) { where(parent_account: acct) }
  # Búsqueda por código parcial (insensible a mayúsculas)
  scope :search_code,   ->(term) { where("code LIKE ?", "%#{term.to_s.upcase}%") }
  # Búsqueda por nombre parcial (insensible a mayúsculas)
  scope :search_name,   ->(term) { where("LOWER(name) LIKE ?", "%#{term.to_s.downcase}%") }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Calcula el saldo actual: sum(debit) - sum(credit)
  # Para grupos de cuentas, podríamos sumar recursivamente los saldos de sub_accounts
  def balance
    ledger_entries.sum('debit_amount - credit_amount')
  end

  # Devuelve el código completo con niveles (si se implementa ancestry o nested_set)
  def full_code
    if respond_to?(:ancestry) && ancestry.present?
      ancestors.pluck(:code).push(code).join('.')
    else
      code
    end
  end

  # Comprueba si la cuenta es una hoja (sin subcuentas)
  def leaf?
    sub_accounts.empty?
  end
end
