# app/models/bank_account.rb
class BankAccount < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES
  # ------------------------------------------------------------
  # Estado de la cuenta bancaria
  enum status: {
    active:   0,  # Activa
    inactive: 1,  # Inactiva
    closed:   2   # Cerrada
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :company                # Empresa propietaria de la cuenta
  belongs_to :currency               # Moneda de la cuenta

  # Pagos emitidos desde esta cuenta
  has_many   :payments,
             dependent: :nullify

  # Documentos adjuntos (ej. contrato de cuenta)
  has_many_attached :documents

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  # Nombre descriptivo interno (ej. "Cuenta Nómina", "Cuenta Proveedores")
  validates :name,
            presence:   true,
            length:     { maximum: 100 }

  # IBAN: obligatorio, único, formato ISO
  validates :iban,
            presence:   true,
            uniqueness: true,
            format:     {
              with: /\A[A-Z]{2}[0-9]{2}[A-Z0-9]{1,30}\z/,
              message: "formato IBAN inválido"
            }

  # BIC/SWIFT: opcional, pero si está, debe ser válido
  validates :bic,
            format:     { with: /\A[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?\z/, message: "formato BIC inválido" },
            allow_blank: true

  # Nombre del banco
  validates :bank_name,
            presence:   true,
            length:     { maximum: 150 }

  # Código de sucursal: opcional, largo máximo 20
  validates :branch_code,
            length:     { maximum: 20 },
            allow_blank: true

  # Dirección de la sucursal
  validates :branch_address,
            length:     { maximum: 255 },
            allow_blank: true

  validates :status,
            presence: true

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields
  def normalize_fields
    self.name            = name.to_s.strip.titleize
    self.iban            = iban.to_s.strip.delete(' ').upcase
    self.bic             = bic.to_s.strip.upcase if bic
    self.bank_name       = bank_name.to_s.strip.titleize
    self.branch_code     = branch_code.to_s.strip.upcase if branch_code
    self.branch_address  = branch_address.to_s.strip.titleize if branch_address
  end

  # ------------------------------------------------------------
  # VALIDACIONES DE DOCUMENTOS ADJUNTOS
  # ------------------------------------------------------------
  validate :acceptable_documents
  def acceptable_documents
    documents.each do |doc|
      if doc.byte_size > 5.megabytes
        errors.add(:documents, "cada documento debe pesar menos de 5MB")
      end
      acceptable_types = ["application/pdf", "image/png", "image/jpeg"]
      unless acceptable_types.include?(doc.content_type)
        errors.add(:documents, "debe ser PDF, PNG o JPG")
      end
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :active,       -> { where(status: statuses[:active]) }
  scope :by_currency,  ->(code) { joins(:currency).where(currencies: { code: code.to_s.upcase }) }
  scope :by_company,   ->(comp) { where(company: comp) }
  scope :search_name,  ->(term) { where("LOWER(name) LIKE ?", "%#{term.to_s.downcase.strip}%") }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Formatea el IBAN en grupos de 4 caracteres
  def formatted_iban
    iban.scan(/.{1,4}/).join(" ")
  end
end
