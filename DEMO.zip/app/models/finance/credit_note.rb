# app/models/credit_note.rb
class CreditNote < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA EL ESTADO DE LA NOTA DE CRÉDITO
  # ------------------------------------------------------------
  enum status: {
    draft:      0,  # Borrador, no emitida
    issued:     1,  # Emitida
    applied:    2,  # Aplicada a la factura
    cancelled:  3   # Cancelada
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :invoice                           # Factura a la que corrige/devolución
  belongs_to :company                           # Nuestra empresa
  belongs_to :provider,         optional: true  # Proveedor emisor (si procede)
  # Relación con líneas de nota de crédito (similares a InvoiceItem)
  has_many   :credit_note_items, dependent: :destroy
  accepts_nested_attributes_for :credit_note_items, allow_destroy: true
  # Relación opcional con la moneda estandarizada
  belongs_to :currency,
             primary_key:   'code',
             foreign_key:   'currency',
             optional:      true

  # ------------------------------------------------------------
  # CAMPOS PRINCIPALES (en migración):
  #   t.string   :credit_note_number, null: false
  #   t.date     :issued_at,          null: false
  #   t.date     :applied_at
  #   t.string   :currency,           null: false, limit: 3
  #   t.decimal  :net_amount,         null: false, precision: 15, scale: 2
  #   t.decimal  :tax_amount,         null: false, precision: 15, scale: 2
  #   t.decimal  :total_amount,       null: false, precision: 15, scale: 2
  #   t.text     :reason
  #   t.integer  :status,             null: false, default: 0

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :credit_note_number,
            presence:   true,
            uniqueness: { scope: :company_id, case_sensitive: false },
            length:     { maximum: 50 }
  validates :issued_at,
            presence:   true,
            timeliness: { on_or_before: -> { Date.current }, type: :date }
  validates :applied_at,
            timeliness: { on_or_after: :issued_at, type: :date },
            allow_blank: true

  validates :currency,
            presence:   true,
            length:     { is: 3 },
            format:     { with: /\A[A-Z]{3}\z/, message: "debe ser código ISO4217" }

  validates :net_amount,
            presence:     true,
            numericality: { greater_than_or_equal_to: 0 }
  validates :tax_amount,
            presence:     true,
            numericality: { greater_than_or_equal_to: 0 }
  validates :total_amount,
            presence:     true,
            numericality: { greater_than_or_equal_to: 0 }

  validates :status, presence: true

  validate :amounts_consistency

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.credit_note_number = credit_note_number.to_s.strip.upcase
    self.currency           = currency.to_s.strip.upcase if currency
    self.reason             = reason.to_s.strip if reason
  end

  # ------------------------------------------------------------
  # MÉTODO DE VALIDACIÓN PERSONALIZADA
  # ------------------------------------------------------------
  def amounts_consistency
    return unless net_amount && tax_amount && total_amount
    if (net_amount + tax_amount - total_amount).abs > 0.01
      errors.add(:total_amount, "debe ser la suma de neto y impuestos")
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :drafts,         -> { where(status: statuses[:draft]) }
  scope :issued,         -> { where(status: statuses[:issued]) }
  scope :applied,        -> { where(status: statuses[:applied]) }
  scope :cancelled,      -> { where(status: statuses[:cancelled]) }
  scope :by_company,     ->(comp) { where(company: comp) }
  scope :by_invoice,     ->(inv)  { where(invoice: inv) }
  scope :issued_between, ->(from, to) { where(issued_at: from..to) }

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------
  # Devuelve el importe pendiente de aplicar a la factura
  def outstanding_amount
    total_amount - (invoice.credit_notes.applied.where.not(id: id).sum(:total_amount))
  end

  # Aplica esta nota de crédito a la factura y marca status
  def apply_to_invoice!
    return unless issued? && invoice.present?
    transaction do
      update!(status: :applied, applied_at: Date.current)
      invoice.with_lock do
        new_total = invoice.total_amount - total_amount
        invoice.update!(total_amount: new_total, status: :issued) if new_total > 0
        invoice.update!(status: :paid) if new_total <= 0
      end
    end
  end
end
