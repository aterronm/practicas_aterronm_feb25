class Expense < ApplicationRecord
end
