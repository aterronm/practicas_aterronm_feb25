# app/models/invoice.rb
class Invoice < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA EL ESTADO DE LA FACTURA
  # ------------------------------------------------------------
  # draft: borrador, issued: emitida, paid: pagada, overdue: vencida, cancelled: cancelada
  enum status: { draft: 0, issued: 1, paid: 2, overdue: 3, cancelled: 4 }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  # Proveedor que emite la factura
  belongs_to :provider
  # Orden de compra asociada (opcional)
  belongs_to :purchase_order, optional: true
  # Empresa receptora (nuestra compañía)
  belongs_to :company
  # País de la factura (opcional, para facturación internacional)
  belongs_to :country, optional: true

  # Líneas de detalle (artículos o servicios facturados)
  has_many :invoice_items, dependent: :destroy
  accepts_nested_attributes_for :invoice_items, allow_destroy: true

  # Pagos aplicados a esta factura
  has_many :payments, dependent: :nullify

  # Documentos adjuntos (PDF, escaneos, etc.)
  has_many_attached :attachments

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  # Número de factura: obligatorio, único por empresa
  validates :invoice_number,
            presence:   true,
            uniqueness: { scope: :company_id, case_sensitive: false },
            length:     { maximum: 50 }

  # Fechas
  validates :issued_at,
            presence:   true,
            timeliness: { on_or_before: -> { Date.current }, type: :date }
  validates :due_at,
            presence:   true,
            timeliness: { after: -> { issued_at }, type: :date }

  # Moneda (código ISO4217)
  validates :currency,
            presence:   true,
            length:     { is: 3 },
            format:     { with: /\A[A-Z]{3}\z/, message: "debe ser código ISO4217" }
  validates :exchange_rate,
            numericality: { greater_than: 0 }, allow_blank: true

  # Importes
  validates :net_amount,
            presence:   true,
            numericality: { greater_than_or_equal_to: 0 }
  validates :tax_amount,
            presence:   true,
            numericality: { greater_than_or_equal_to: 0 }
  validates :total_amount,
            presence:   true,
            numericality: { greater_than_or_equal_to: 0 }

  validates :status, presence: true

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.invoice_number = invoice_number.to_s.strip.upcase
    self.currency       = currency.to_s.strip.upcase if currency
    self.notes          = notes.to_s.strip if respond_to?(:notes)
  end

  # ------------------------------------------------------------
  # VALIDACIÓN DE COHERENCIA DE TOTALES
  # ------------------------------------------------------------
  validate :amounts_consistency

  def amounts_consistency
    return unless net_amount && tax_amount && total_amount
    if (net_amount + tax_amount - total_amount).abs > 0.01
      errors.add(:total_amount, "debe ser la suma de neto y impuestos")
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :drafts,         -> { where(status: statuses[:draft]) }
  scope :issued,         -> { where(status: statuses[:issued]) }
  scope :paid,           -> { where(status: statuses[:paid]) }
  scope :overdue,        -> { where(status: statuses[:overdue]) }
  scope :cancelled,      -> { where(status: statuses[:cancelled]) }
  scope :by_provider,    ->(prov) { where(provider: prov) }
  scope :by_company,     ->(comp) { where(company: comp) }
  scope :by_currency,    ->(cur)  { where(currency: cur.upcase) }
  scope :issued_between, ->(from, to) { where(issued_at: from..to) }

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------
  # Importe pendiente de pago
  def outstanding_amount
    total_amount - payments.sum(:amount)
  end

  # ¿Factura completamente pagada?
  def paid?
    status == "paid" && outstanding_amount <= 0
  end

  # ¿Factura vencida?
  def overdue?
    status == "overdue" || (due_at < Date.current && !paid?)
  end

  # Días de retraso
  def days_overdue
    return 0 unless due_at && Date.current > due_at
    (Date.current - due_at).to_i
  end
end
