# app/models/invoice_item.rb
class InvoiceItem < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA VALORES FIJOS
  # ------------------------------------------------------------
  # Unidad de medida de la cantidad
  enum unit_type: {
    unit:    0,  # Unidad
    hour:    1,  # Hora
    kg:      2,  # Kilogramo
    liter:   3,  # Litro
    meter:   4,  # Metro
    custom:  5   # Otra
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :invoice                               # Factura a la que pertenece
  belongs_to :product,            optional: true     # Producto o servicio referenciado
  belongs_to :purchase_order_item, optional: true    # Línea de pedido de compra origen
  belongs_to :tax_rate,           optional: true     # Tipo impositivo aplicado

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :description,
            presence: true,
            length:   { maximum: 500 }
  validates :quantity,
            presence:     true,
            numericality: { greater_than: 0 }
  validates :unit_price,
            presence:     true,
            numericality: { greater_than_or_equal_to: 0 }
  validates :unit_type,
            presence: true

  validates :discount_amount,
            numericality: { greater_than_or_equal_to: 0 },
            allow_blank:  true
  validate  :discount_not_exceed_subtotal
  validate  :amounts_consistency

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields
  def normalize_fields
    self.description     = description.to_s.strip.capitalize
    self.discount_amount = discount_amount.to_d if discount_amount
  end

  # ------------------------------------------------------------
  # CÁLCULO DE IMPORTES
  # ------------------------------------------------------------
  # Base imponible: quantity * unit_price – discount
  def calculate_net_amount
    (quantity * unit_price) - (discount_amount || 0)
  end

  # Importe de impuestos usando tax_rate.percentage si existe
  def calculate_tax_amount
    return 0 unless tax_rate && calculate_net_amount > 0
    (calculate_net_amount * (tax_rate.percentage.to_d / 100)).round(2)
  end

  # Total: net_amount + tax_amount
  def calculate_total_amount
    calculate_net_amount + calculate_tax_amount
  end

  # Antes de guardar, asignar campos de importe
  before_save :assign_calculated_amounts
  def assign_calculated_amounts
    self.net_amount   = calculate_net_amount
    self.tax_amount   = calculate_tax_amount
    self.total_amount = calculate_total_amount
  end

  # ------------------------------------------------------------
  # MÉTODOS DE VALIDACIÓN PERSONALIZADA
  # ------------------------------------------------------------
  def discount_not_exceed_subtotal
    return unless discount_amount && unit_price && quantity
    max_disc = unit_price * quantity
    if discount_amount > max_disc
      errors.add(:discount_amount, "no puede exceder #{max_disc}")
    end
  end

  def amounts_consistency
    return unless net_amount && tax_amount && total_amount
    if (net_amount + tax_amount - total_amount).abs > 0.01
      errors.add(:total_amount, "debe ser igual a neto más impuestos")
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_invoice,      ->(inv)      { where(invoice: inv) }
  scope :with_product,     ->           { where.not(product_id: nil) }
  scope :by_tax_rate,      ->(tr)       { where(tax_rate: tr) }
  scope :exempt,           ->           { joins(:tax_rate).where(tax_rates: { percentage: 0 }) }
  scope :with_discount,    ->           { where("discount_amount > 0") }
  scope :total_between,    ->(min, max) { where(total_amount: min..max) }
  scope :search_description, ->(term)   {
    where("LOWER(description) LIKE ?", "%#{term.to_s.downcase.strip}%")
  }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Indica si es un cargo (cantidad positiva)
  def charge?
    quantity > 0
  end

  # Indica si es un ajuste de crédito (cantidad negativa)
  def credit_note_item?
    quantity < 0
  end
end
