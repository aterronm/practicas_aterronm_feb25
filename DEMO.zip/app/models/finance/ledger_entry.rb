# app/models/ledger_entry.rb
class LedgerEntry < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA EL TIPO DE ASIENTO
  # ------------------------------------------------------------
  # Define si el asiento es un cargo (debit) o un abono (credit)
  enum entry_type: { debit: 0, credit: 1 }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :account                              # Cuenta contable afectada
  belongs_to :company                              # Empresa propietaria del asiento
  # Vinculación opcional a documento origen:
  # puede ser Invoice, PurchaseOrder, Payment, CreditNote, etc.
  belongs_to :documentable,
             polymorphic: true,
             optional: true

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :entry_date,
            presence: true                       # Fecha del asiento
  validates :entry_type,
            presence: true                       # Debit o credit
  validates :amount,
            presence:     true,
            numericality: { greater_than: 0 }     # Importe positivo
  validates :description,
            presence:   true,
            length:     { maximum: 500 }         # Descripción del asiento

  # Coherencia: para debit debe usarse entry_type: :debit, etc.
  validate :amount_matches_entry_type

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.description = description.to_s.strip.capitalize
  end

  # ------------------------------------------------------------
  # MÉTODO DE VALIDACIÓN PERSONALIZADA
  # ------------------------------------------------------------
  def amount_matches_entry_type
    return unless amount && entry_type
    # No reglas adicionales aquí, pero se podrían validar cargos/abonos
    # p.ej. asegurarse de que los importes cuadren con saldos de cuenta
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  # Asientos de una cuenta concreta
  scope :for_account,    ->(acct)       { where(account: acct) }
  # Asientos de una empresa concreta
  scope :for_company,    ->(comp)       { where(company: comp) }
  # Rango de fechas
  scope :between_dates,  ->(from, to)   { where(entry_date: from..to) }
  # Por tipo de asiento
  scope :debits,         ->             { where(entry_type: entry_types[:debit]) }
  scope :credits,        ->             { where(entry_type: entry_types[:credit]) }
  # Por documento origen
  scope :for_document,   ->(doc)        { where(documentable: doc) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Indica si es un cargo
  def debit?
    entry_type == "debit"
  end

  # Indica si es un abono
  def credit?
    entry_type == "credit"
  end

  # Devuelve importe positivo o negativo según tipo
  def signed_amount
    debit? ?  amount : -amount
  end
end
