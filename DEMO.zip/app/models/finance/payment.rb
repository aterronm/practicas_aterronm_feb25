# app/models/payment.rb
class Payment < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA VALORES FIJOS
  # ------------------------------------------------------------
  # Estado del pago
  enum status: {
    pending:    0,  # Pendiente de procesar
    completed:  1,  # Completado
    failed:     2,  # Fallido
    refunded:   3,  # Reembolsado
    cancelled:  4   # Cancelado
  }

  # Método de pago
  enum payment_method: {
    cash:            0,  # Efectivo
    bank_transfer:   1,  # Transferencia bancaria
    credit_card:     2,  # Tarjeta de crédito
    direct_debit:    3,  # Domiciliación bancaria
    cheque:          4,  # Cheque
    paypal:          5,  # PayPal
    other:           6   # Otro
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :invoice                             # Factura a la que aplica
  belongs_to :provider, optional: true            # Proveedor (en caso de pago a proveedor)
  belongs_to :company                             # Empresa emisora/recibidora
  belongs_to :bank_account, optional: true        # Cuenta bancaria usada

  has_one_attached :receipt                        # Comprobante de pago

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  # Número interno de pago: opcional, único por empresa
  validates :payment_number,
            uniqueness: { scope: :company_id, case_sensitive: false },
            length:     { maximum: 50 },
            allow_blank: true

  # Fecha de pago: obligatoria y no futura
  validates :paid_at,
            presence: true,
            timeliness: { on_or_before: -> { Date.current }, type: :date }

  # Importe: obligatorio y positivo
  validates :amount,
            presence:     true,
            numericality: { greater_than: 0 }

  # Moneda (ISO4217)
  validates :currency,
            presence:   true,
            length:     { is: 3 },
            format:     { with: /\A[A-Z]{3}\z/, message: "debe ser un código ISO4217" }

  # Método de pago y estado obligatorios
  validates :payment_method, :status, presence: true

  # Referencia/transacción opcional
  validates :reference_number,
            length:     { maximum: 100 },
            allow_blank: true

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.payment_number   = payment_number.to_s.strip.upcase if payment_number
    self.currency         = currency.to_s.strip.upcase if currency
    self.reference_number = reference_number.to_s.strip if reference_number
    self.notes            = notes.to_s.strip if respond_to?(:notes)
  end

  # ------------------------------------------------------------
  # VALIDACIÓN DE ADJUNTO
  # ------------------------------------------------------------
  validate :receipt_format_and_size

  def receipt_format_and_size
    return unless receipt.attached?
    if receipt.byte_size > 5.megabytes
      errors.add(:receipt, "debe pesar menos de 5 MB")
    end
    acceptable = ["application/pdf", "image/png", "image/jpeg"]
    unless acceptable.include?(receipt.content_type)
      errors.add(:receipt, "debe ser PDF, PNG o JPEG")
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :recent,         ->(days = 7) { where('paid_at >= ?', days.days.ago) }
  scope :by_status,      ->(s)        { where(status: statuses[s]) }
  scope :by_method,      ->(m)        { where(payment_method: payment_methods[m]) }
  scope :by_currency,    ->(c)        { where(currency: c.to_s.upcase) }
  scope :for_invoice,    ->(inv)      { where(invoice: inv) }
  scope :for_provider,   ->(prov)     { where(provider: prov) }
  scope :for_company,    ->(comp)     { where(company: comp) }
  scope :between_dates,  ->(from, to) { where(paid_at: from..to) }

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------
  # Pagos completados
  def completed?
    status == "completed"
  end

  # Pagos reembolsados
  def refunded?
    status == "refunded"
  end

  # Devuelve el importe pendiente de pago de la factura tras este abono
  def outstanding_after_payment
    invoice.total_amount - invoice.payments.sum(:amount)
  end

  # Aplica este pago a la factura y actualiza su estado si procede
  def apply_to_invoice!
    return unless completed? && invoice.present?
    invoice.with_lock do
      invoice.payments << self
      invoice.update(status: :paid) if invoice.outstanding_amount <= 0
    end
  end
end
