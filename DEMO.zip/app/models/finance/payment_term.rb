# app/models/payment_term.rb
class PaymentTerm < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA EL ÁMBITO DE APLICACIÓN
  # ------------------------------------------------------------
  # Define si el término aplica a órdenes de compra, facturas o ambos
  enum apply_to: {
    purchase_orders: 0,  # Solo para PurchaseOrder
    invoices:        1,  # Solo para Invoice
    both:            2   # Para ambos
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  # Pertenece a la empresa que define las condiciones
  belongs_to :company
  # Opcional: puede ser específico de un proveedor
  belongs_to :provider, optional: true

  # Se asigna a múltiples órdenes de compra y facturas
  has_many :purchase_orders, dependent: :nullify
  has_many :invoices,         dependent: :nullify

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  # Nombre descriptivo (e.g. "30 días neto", "2% 10 días")
  validates :name,
            presence:   true,
            uniqueness: { scope: [:company_id, :provider_id], case_sensitive: false },
            length:     { maximum: 100 }

  # Plazo neto en días (pago total dentro de X días)
  validates :net_days,
            presence:     true,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 }

  # Descuento (%) por pronto pago (opcional)
  validates :discount_rate,
            numericality: { greater_than: 0, less_than_or_equal_to: 100 },
            allow_blank:  true

  # Días para aprovechar el descuento (opcional)
  validates :discount_days,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 },
            allow_blank:  true

  # Coherencia: si se define uno de descuento, debe definirse el otro
  validate :discount_consistency

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    # Título limpio y con mayúsculas iniciales
    self.name = name.to_s.strip.titleize
  end

  def discount_consistency
    if discount_rate.present? ^ discount_days.present?
      errors.add(:base, "discount_rate y discount_days deben definirse juntos")
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_company,      ->(comp) { where(company: comp) }
  scope :for_provider,     ->(prov) { where(provider: prov) }
  scope :with_discount,    ->       { where.not(discount_rate: nil) }
  scope :without_discount, ->       { where(discount_rate: nil) }
  scope :net_in_days,      ->(d)    { where(net_days: d) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # True si aplica tanto a órdenes como a facturas
  def applies_to_both?
    apply_to == "both"
  end

  # Resumen legible de las condiciones, e.g. "2% 10 días / neto 30 días"
  def summary
    parts = []
    parts << "#{discount_rate}% #{discount_days} días" if discount_rate.present?
    parts << "neto #{net_days} días"
    parts.join(" / ")
  end
end
