# app/models/purchase_order.rb
class PurchaseOrder < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA VALORES FIJOS
  # ------------------------------------------------------------
  # Estado de la orden de compra
  enum status: {
    draft:               0,  # Borrador
    issued:              1,  # Emitida
    partially_received:  2,  # Parcialmente recibida
    received:            3,  # Completamente recibida
    cancelled:           4   # Cancelada
  }

  # Tipo de entrega
  enum delivery_type: {
    pickup:   0,  # Recogida en almacén
    delivery: 1   # Envío a dirección
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :provider                             # Proveedor que emite la orden
  belongs_to :company                              # Empresa receptora (nuestra compañía)
  belongs_to :country, optional: true              # País de facturación (opcional)
  belongs_to :shipping_country,
             class_name: 'Country',
             optional: true                        # País de entrega (opcional)
  belongs_to :payment_term, optional: true         # Condiciones de pago

  has_many   :purchase_order_items,
             dependent: :destroy                   # Líneas de la orden
  accepts_nested_attributes_for :purchase_order_items,
                                allow_destroy: true

  has_many   :invoices,
             dependent: :nullify                   # Facturas asociadas

  has_many_attached :attachments                    # Documentos adjuntos (PDF, etc.)

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  # Número interno de orden: único por empresa
  validates :order_number,
            presence:   true,
            uniqueness: { scope: :company_id, case_sensitive: false },
            length:     { maximum: 50 }

  # Fechas de emisión y entrega esperada
  validates :issued_at,
            presence:   true,
            timeliness: { on_or_before: -> { Date.current }, type: :date }
  validates :expected_delivery_at,
            presence:   true,
            timeliness: { on_or_after: -> { issued_at }, type: :date }

  # Plazos y moneda
  validates :payment_terms_days,
            presence:     true,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 }
  validates :lead_time_days,
            presence:     true,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 }
  validates :currency,
            presence:   true,
            length:     { is: 3 },
            format:     { with: /\A[A-Z]{3}\z/, message: "debe ser código ISO4217" }
  validates :delivery_type, presence: true

  # Totales: neto, impuestos y total
  validates :net_amount,
            presence:     true,
            numericality: { greater_than_or_equal_to: 0 }
  validates :tax_amount,
            presence:     true,
            numericality: { greater_than_or_equal_to: 0 }
  validates :total_amount,
            presence:     true,
            numericality: { greater_than_or_equal_to: 0 }

  # Coherencia de importes
  validate :amounts_consistency

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    # Código de orden en mayúsculas y sin espacios extras
    self.order_number         = order_number.to_s.strip.upcase
    # Moneda en mayúsculas
    self.currency             = currency.to_s.strip.upcase if currency
    # Direcciones de envío
    self.shipping_street      = shipping_street.to_s.strip.titleize if respond_to?(:shipping_street)
    self.shipping_city        = shipping_city.to_s.strip.titleize if respond_to?(:shipping_city)
    self.shipping_state       = shipping_state.to_s.strip.upcase if respond_to?(:shipping_state)
    self.shipping_postal_code = shipping_postal_code.to_s.strip.upcase if respond_to?(:shipping_postal_code)
    # Notas
    self.notes                = notes.to_s.strip if respond_to?(:notes)
  end

  # ------------------------------------------------------------
  # VALIDACIÓN DE COHERENCIA DE TOTALES
  # ------------------------------------------------------------
  def amounts_consistency
    return unless net_amount && tax_amount && total_amount
    if (net_amount + tax_amount - total_amount).abs > 0.01
      errors.add(:total_amount, "debe ser la suma de neto y impuestos")
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :drafts,               -> { where(status: statuses[:draft]) }
  scope :issued,               -> { where(status: statuses[:issued]) }
  scope :received,             -> { where(status: statuses[:received]) }
  scope :by_provider,          ->(prov) { where(provider: prov) }
  scope :by_company,           ->(comp) { where(company: comp) }
  scope :by_currency,          ->(cur)  { where(currency: cur.to_s.upcase) }
  scope :issued_between,       ->(from, to) { where(issued_at: from..to) }
  scope :overdue_delivery,     -> { where("expected_delivery_at < ? AND status != ?", Date.current, statuses[:received]) }
  scope :with_outstanding_invoice, -> {
    joins("LEFT JOIN invoices ON invoices.purchase_order_id = purchase_orders.id")
      .group("purchase_orders.id")
      .having("SUM(invoices.total_amount) < MAX(purchase_orders.total_amount)")
  }

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------
  # Importe pendiente de facturar
  def outstanding_to_invoice
    total_amount - invoices.sum(:total_amount)
  end

  # ¿Pedido completamente facturado?
  def fully_invoiced?
    outstanding_to_invoice <= 0
  end

  # ¿Pedido recibido?
  def received?
    status == "received"
  end

  # Días de retraso en la entrega
  def days_overdue_delivery
    return 0 unless expected_delivery_at && Date.current > expected_delivery_at
    (Date.current - expected_delivery_at).to_i
  end
end
