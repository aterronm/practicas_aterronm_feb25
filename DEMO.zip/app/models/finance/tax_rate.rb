# app/models/tax_rate.rb
class TaxRate < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA CATEGORÍAS FIJAS
  # ------------------------------------------------------------
  # Clasifica si es IVA, retención u otro tipo de impuesto
  enum category: {
    vat:         0,  # Impuesto sobre el Valor Añadido
    withholding: 1,  # Retención (IRPF, retenedores)
    other:       2   # Otros impuestos
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  # País o jurisdicción a la que aplica (opcional)
  belongs_to :country, optional: true

  # Facturas/líneas que usan este tipo impositivo
  has_many :invoice_items, dependent: :nullify

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  # Código único y descriptivo (ej. "IVA21", "RET15")
  validates :code,
            presence:   true,
            uniqueness: { case_sensitive: false },
            length:     { maximum: 20 }

  # Nombre descriptivo (ej. "IVA 21%")
  validates :name,
            presence: true,
            length:   { maximum: 100 }

  # Porcentaje del impuesto: 0.00 a 100.00
  validates :percentage,
            presence:     true,
            numericality: { greater_than_or_equal_to: 0, less_than_or_equal_to: 100 }

  # Fecha desde la que está vigente
  validates :effective_date,
            presence: true,
            timeliness: { on_or_before: -> { Date.current }, type: :date }

  # Fecha de caducidad, si se especifica, debe ser posterior a la efectiva
  validates :expiration_date,
            timeliness: { after: :effective_date, type: :date },
            allow_blank: true

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    # Código en mayúsculas y sin espacios
    self.code       = code.to_s.strip.upcase
    # Nombre con mayúsculas iniciales
    self.name       = name.to_s.strip.titleize
    # Descripción sin espacios extra
    self.description = description.to_s.strip if respond_to?(:description)
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  # Vigentes a fecha actual
  scope :current,       -> { where("effective_date <= ? AND (expiration_date IS NULL OR expiration_date >= ?)", Date.current, Date.current) }
  # Por código
  scope :by_code,       ->(c) { where(code: c.to_s.upcase) }
  # Por categoría (vat, withholding, other)
  scope :by_category,   ->(cat) { where(category: categories[cat]) }
  # Por país
  scope :by_country,    ->(ctry) { joins(:country).where(countries: { iso: ctry.to_s.upcase }) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Devuelve si el impuesto está vencido
  def expired?
    expiration_date.present? && expiration_date < Date.current
  end

  # Rango de vigencia legible
  def validity_period
    end_date = expiration_date || "actualidad"
    "#{effective_date} – #{end_date}"
  end
end
