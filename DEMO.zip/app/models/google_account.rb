class GoogleAccount < ApplicationRecord
  # ------------------------------------------------------------
  # Devise: OmniAuth (Google)
  # ------------------------------------------------------------
  devise :omniauthable, omniauth_providers: [:google_oauth2]

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :user

  # ------------------------------------------------------------
  # CAMPOS
  # ------------------------------------------------------------
  # google_uid      :string,  no nulo, único
  # email           :string,  no nulo
  # name            :string
  # avatar_url      :string
  # raw_info        :json,    no nulo, default {}
  # last_login_at   :datetime

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :google_uid, presence: true, uniqueness: true
  validates :email,      presence: true, format: { with: URI::MailTo::EMAIL_REGEXP }

  # ------------------------------------------------------------
  # CALLBACKS
  # ------------------------------------------------------------
  before_validation :sanitize_fields

  def sanitize_fields
    self.google_uid = google_uid.to_s.strip
    self.email      = email.to_s.strip.downcase
    self.name       = name.to_s.strip.titleize if name.present?
  end

  # ------------------------------------------------------------
  # LÓGICA OMNIAUTH
  # ------------------------------------------------------------
  def self.from_omniauth(auth)
    account = find_or_initialize_by(google_uid: auth.uid)
    account.assign_attributes(
      email:         auth.info.email,
      name:          auth.info.name,
      avatar_url:    auth.info.image,
      raw_info:      auth.to_h,
      last_login_at: Time.current
    )
    transaction do
      user = account.user || User.find_or_create_by!(email: account.email) do |u|
        u.password = Devise.friendly_token[0, 20]
      end
      account.user = user
      account.save!
    end
    account
  end

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  def touch_login!
    update_column(:last_login_at, Time.current)
  end
end