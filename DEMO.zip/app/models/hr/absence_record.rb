# app/models/absence_record.rb
class AbsenceRecord < ApplicationRecord
  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  # Persona que toma la ausencia
  belongs_to :person
  # Tipo de ausencia (vacaciones, baja médica, etc.)
  belongs_to :absence_type
  # Origen polimórfico de la ausencia (LeaveRequest, TimeOffRequest...)
  belongs_to :source, polymorphic: true, optional: true
  # Usuario que aprueba la ausencia
  belongs_to :approver, class_name: 'User', optional: true

  # ------------------------------------------------------------
  # ENUMERACIONES / ESTADOS DE WORKFLOW
  # ------------------------------------------------------------
  enum :status, { pending: 'pending', approved: 'approved', rejected: 'rejected' }

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :person, :absence_type, :start_date, :end_date, :status, presence: true
  validates :end_date,
            timeliness: { on_or_after: :start_date, type: :date }
  validates :days_count,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 }
  validate  :no_overlap_with_other_absences
  validate  :available_leave_balance, if: -> { absence_type&.annual_limit_days.present? }
  validates :approver, :approved_at, presence: true, if: :approved?

  # ------------------------------------------------------------
  # CALLBACKS
  # ------------------------------------------------------------
  # Antes de validar, calculamos el número de días
  before_validation :compute_days_count
  # Normalizar notas
  before_validation :normalize_notes

  # ------------------------------------------------------------
  # MÉTODOS DE NORMALIZACIÓN Y CÁLCULO
  # ------------------------------------------------------------
  # Calcula days_count contando días naturales
  def compute_days_count
    return unless start_date && end_date
    self.days_count = (end_date - start_date + 1).to_i
  end

  # Limpia espacios en las notas
  def normalize_notes
    self.notes = notes.to_s.strip if notes
  end

  # ------------------------------------------------------------
  # VALIDACIONES PERSONALIZADAS
  # ------------------------------------------------------------
  # Evita solapamiento de ausencias para la misma persona
  def no_overlap_with_other_absences
    return unless person && start_date && end_date
    overlapping = AbsenceRecord.where(person: person)
                               .where.not(id: id)
                               .where('start_date <= ? AND end_date >= ?', end_date, start_date)
    errors.add(:base, 'Ya existe otra ausencia en este período') if overlapping.exists?
  end

  # Verifica saldo disponible en leave_balances
  def available_leave_balance
    balance = person.leave_balances.find_by(absence_type: absence_type)
    if balance && days_count > balance.available_days
      errors.add(:base, 'No hay suficientes días disponibles para este tipo de ausencia')
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS
  # ------------------------------------------------------------
  scope :for_person, ->(p) { where(person: p) }
  scope :of_type,    ->(t) { where(absence_type: t) }
  scope :between,    ->(from, to) { where('start_date <= ? AND end_date >= ?', to, from) }
  scope :on_date,    ->(d) { where('start_date <= ? AND end_date >= ?', d, d) }
  scope :recent,     ->(days = 30) { where('end_date >= ?', days.days.ago) }
  scope :pending,    -> { where(status: statuses[:pending]) }
  scope :approved,   -> { where(status: statuses[:approved]) }
  scope :rejected,   -> { where(status: statuses[:rejected]) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Comprueba si la ausencia cubre completamente un período dado
  def covers_period?(from, to)
    start_date <= from && end_date >= to
  end

  # Resumen legible de la ausencia
  def summary
    "#{absence_type.name}: #{start_date} – #{end_date} (#{days_count} días)"
  end

  # Exporta un evento iCal con la ausencia
  def to_ical_event
    Icalendar::Event.new.tap do |e|
      e.dtstart     = start_date
      e.dtend       = end_date + 1
      e.summary     = summary
      e.description = notes
    end
  end
end