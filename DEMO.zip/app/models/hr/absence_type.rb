# app/models/absence_type.rb

# Modelo: AbsenceType
# Representa un tipo de ausencia (vacaciones, baja médica, permiso personal, etc.)
# ------------------------------------------------------------
# Propósito:
#   - Definir categorías de ausencia con propiedades (retribuido, aprobación, límites)
#   - Asociar solicitudes y registros de ausencia
#   - Controlar reglas de negocio: límites anuales, traspaso de días
#   - Facilitar informes y workflows de aprobación
#
# Mejoras implementadas:
#   1. Enumerado de categorías con 'enum category'.
#   2. Propiedades: paid, requires_approval, annual_limit_days, carryover_allowed, max_carryover_days.
#   3. Validaciones avanzadas de consistencia de límites y carryover.
#   4. Normalización automática de campos antes de validar.
#   5. Scopes para filtros frecuentes.
#   6. Métodos auxiliares para resumen y flags específicos.
#
class AbsenceType < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES / CATEGORÍAS DE AUSENCIA
  # ------------------------------------------------------------
  enum :category, {
    vacation:        0,  # Vacaciones
    sick_leave:      1,  # Baja médica
    personal_leave:  2,  # Permiso personal
    maternity:       3,  # Maternidad/Paternidad
    unpaid_leave:    4,  # Permiso no retribuido
    other:           5   # Otro
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  # Varias solicitudes pueden usar este tipo de ausencia
  has_many :leave_requests, dependent: :restrict_with_error
  # Registros generados a partir de las solicitudes
  has_many :absence_records, dependent: :restrict_with_error
  # Saldo de días asociado (LeaveBalance) para controlar límites
  has_many :leave_balances, dependent: :restrict_with_error

  # ------------------------------------------------------------
  # MIGRACIÓN SUGERIDA
  # ------------------------------------------------------------
  # create_table :absence_types do |t|
  #   t.string  :code,               null: false, unique: true       # Código interno (ej. VAC, SICK)
  #   t.string  :name,               null: false                    # Nombre legible
  #   t.text    :description                                   # Descripción detallada
  #   t.integer :category,           null: false, default: 0        # Categoría de enum
  #   t.boolean :paid,               null: false, default: true     # Retribuido?
  #   t.boolean :requires_approval,  null: false, default: true     # Requiere aprobación previa?
  #   t.integer :annual_limit_days,  null: false, default: 0        # Límite anual de días
  #   t.boolean :carryover_allowed,  null: false, default: false    # Permite traspaso de días no usados
  #   t.integer :max_carryover_days, null: false, default: 0        # Máximo días a traspasar
  #   t.timestamps
  #
  #   # Índices y constraints
  #   add_index :absence_types, :code, unique: true
  #   add_check_constraint :absence_types, 'annual_limit_days >= 0', name: 'ck_absence_types_annual_limit_non_negative'
  #   add_check_constraint :absence_types, 'max_carryover_days >= 0', name: 'ck_absence_types_max_carryover_non_negative'
  # end

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :code,
            presence: true,
            uniqueness: { case_sensitive: false },
            length: { maximum: 10 }

  validates :name,
            presence: true,
            length: { maximum: 100 }

  validates :category,
            presence: true,
            inclusion: { in: categories.keys }

  validates :paid, :requires_approval,
            inclusion: { in: [true, false] }

  validates :annual_limit_days,
            presence: true,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 }

  validates :carryover_allowed,
            inclusion: { in: [true, false] }

  validates :max_carryover_days,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 },
            if: :carryover_allowed?

  validate :carryover_limit_consistency

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    # Código en mayúsculas sin espacios
    self.code        = code.to_s.strip.upcase
    # Nombre capitalizado
    self.name        = name.to_s.strip.titleize
    # Descripción sin espacios sobrantes
    self.description = description.to_s.strip if description
  end

  # ------------------------------------------------------------
  # VALIDACIÓN PERSONALIZADA
  # ------------------------------------------------------------
  def carryover_limit_consistency
    if carryover_allowed? && max_carryover_days.zero?
      errors.add(:max_carryover_days, 'debe ser mayor que 0 si se permite traspaso')
    end
    if !carryover_allowed? && max_carryover_days.positive?
      errors.add(:max_carryover_days, 'debe ser 0 si no se permite traspaso')
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :paid,               -> { where(paid: true) }
  scope :unpaid,             -> { where(paid: false) }
  scope :requiring_approval, -> { where(requires_approval: true) }
  scope :by_category,        ->(cat) { where(category: categories[cat]) }
  scope :with_limit,         -> { where('annual_limit_days > 0') }
  scope :carryover,          -> { where(carryover_allowed: true) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Indica si es un permiso por enfermedad
  def sick?
    sick_leave?
  end

  # Resumen legible del tipo de ausencia
  def summary
    "#{name} (#{paid? ? 'Retribuido' : 'No retribuido'})"
  end
end
