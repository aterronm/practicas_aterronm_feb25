# app/models/attendance_incident.rb
class AttendanceIncident < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES / TIPOS DE INCIDENCIA
  # ------------------------------------------------------------
  enum incident_type: {
    missed_clock_in:       0,  # Falta de fichaje de entrada
    missed_clock_out:      1,  # Falta de fichaje de salida
    duplicate_clock_in:    2,  # Doble fichaje de entrada
    duplicate_clock_out:   3,  # Doble fichaje de salida
    out_of_schedule:       4,  # Fichaje fuera de horario
    unauthorized_overtime: 5,  # Horas extra no autorizadas
    other:                 6   # Otra incidencia
  }

  # ------------------------------------------------------------
  # ENUMERACIONES / ESTADOS DE LA INCIDENCIA
  # ------------------------------------------------------------
  enum status: {
    open:        0,  # Incidencia abierta / pendiente
    in_progress: 1,  # En proceso de resolución
    resolved:    2,  # Resuelta
    dismissed:   3   # Desestimada / archivada
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :person
  belongs_to :position, optional: true
  belongs_to :resolved_by, class_name: 'User', optional: true

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :person, :incident_type, :occurred_at, :status, :description, presence: true
  validates :description, length: { maximum: 1000 }
  validates :resolution,  length: { maximum: 1000 }, allow_blank: true
  validates :ip_address,
            format: { with: Resolv::IPv4::Regex, message: "no es una IPv4 válida" },
            allow_blank: true
  validates :resolved_at,
            timeliness: { on_or_after: :occurred_at, type: :datetime },
            allow_blank: true

  # ------------------------------------------------------------
  # CALLBACKS / NORMALIZACIÓN
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.description = description.to_s.strip.capitalize if description
    self.resolution  = resolution.to_s.strip.capitalize  if resolution
    self.notes       = notes.to_s.strip                 if notes
    self.ip_address  = ip_address.to_s.strip            if ip_address
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS
  # ------------------------------------------------------------
  scope :open,             -> { where(status: statuses[:open]) }
  scope :in_progress,      -> { where(status: statuses[:in_progress]) }
  scope :resolved,         -> { where(status: statuses[:resolved]) }
  scope :dismissed,        -> { where(status: statuses[:dismissed]) }
  scope :by_person,        ->(p) { where(person: p) }
  scope :by_position,      ->(pos) { where(position: pos) }
  scope :by_type,          ->(t) { where(incident_type: incident_types[t]) }
  scope :occurred_between, ->(from, to) { where(occurred_at: from..to) }
  scope :recent,           ->(limit = 50) { order(occurred_at: :desc).limit(limit) }

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------
  def start_progress!
    update!(status: :in_progress)
  end

  def resolve!(user, resolution_text = nil)
    transaction do
      update!(
        status:      :resolved,
        resolved_at: Time.current,
        resolved_by: user,
        resolution:  resolution_text.presence || resolution
      )
    end
  end

  def dismiss!(user)
    update!(
      status:      :dismissed,
      resolved_at: Time.current,
      resolved_by: user
    )
  end
end