# app/models/break_record.rb
class BreakRecord < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES / TIPOS DE PAUSA
  # ------------------------------------------------------------
  enum break_type: {
    lunch:    0,  # Pausa de almuerzo
    personal: 1,  # Pausa personal (café, descanso corto)
    medical:  2,  # Pausa médica
    other:    3   # Otra
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :person
  belongs_to :position,     optional: true
  belongs_to :punch_record, optional: true

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :person, :start_time, :end_time, :break_type, presence: true
  validates :notes, length: { maximum: 500 }, allow_blank: true
  validate  :end_after_start

  # ------------------------------------------------------------
  # CALLBACKS / NORMALIZACIÓN
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.notes = notes.to_s.strip if notes
  end

  # ------------------------------------------------------------
  # VALIDACIÓN PERSONALIZADA
  # ------------------------------------------------------------
  def end_after_start
    return unless start_time && end_time
    if end_time <= start_time
      errors.add(:end_time, 'debe ser posterior a start_time')
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS
  # ------------------------------------------------------------
  scope :for_person,   ->(person)   { where(person: person) }
  scope :for_position, ->(position) { where(position: position) }
  scope :on_date,      ->(date)     { where(start_time: date.beginning_of_day..date.end_of_day) }
  scope :by_type,      ->(type)     { where(break_type: break_types[type]) }
  scope :recent,       ->(limit = 50) { order(start_time: :desc).limit(limit) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Duración de la pausa en horas (dos decimales)
  def duration_hours
    return 0 unless start_time && end_time
    ((end_time - start_time) / 3600.0).round(2)
  end

  # Duración de la pausa en minutos
  def duration_minutes
    (duration_hours * 60).to_i
  end
end