# app/models/contract.rb
module Hr
class Contract < ApplicationRecord
  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :person, class_name: 'Hr::Person'
  belongs_to :position, optional: true, class_name: 'Hr::Position'
  belongs_to :company,  optional: true, class_name: 'Core::Company'

  # ------------------------------------------------------------
  # ENUMERACIONES
  # ------------------------------------------------------------
  enum :status, {
    draft:      0,  # Borrador sin firmar
    pending:    1,  # Pendiente de firma
    active:     2,  # Vigente
    suspended:  3,  # Suspendido temporalmente
    terminated: 4,  # Terminado antes de lo previsto
    expired:    5   # Caducado al finalizar término
  }

  enum :contract_nature, {
    permanent: 0,  # Indefinido / Fijo
    temporary: 1,  # Temporal
    training:  2,  # Formación / Prácticas
    part_time: 3,  # Parcial
    freelance: 4   # Autónomo / Freelance
  }

  # ------------------------------------------------------------
  # VALIDACIONES DE CAMPOS
  # ------------------------------------------------------------
  validates :contract_number,
            presence:   true,
            uniqueness: true,
            length:     { maximum: 100 }

  validates :start_date,
            presence: true,
            timeliness: { on_or_before: -> { Date.current }, type: :date }
  validates :end_date,
            timeliness: { on_or_after: :start_date, type: :date },
            allow_blank: true

  validates :duration_months,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 },
            allow_blank: true

  validates :hours_per_week,
            presence: true,
            numericality: { only_integer: true, greater_than: 0, less_than_or_equal_to: 168 }

  validates :salary_base,
            numericality: { greater_than_or_equal_to: 0 }
  validates :salary_currency,
            presence: true,
            length:   { is: 3 },
            format:   { with: /\A[A-Z]{3}\z/, message: "debe ser código ISO4217" }
  validates :bonus_percentage,
            numericality: { greater_than_or_equal_to: 0, less_than_or_equal_to: 100 },
            allow_blank: true

  validates :benefits,
            length: { maximum: 200 },
            allow_blank: true

  validates :work_location,
            presence: true,
            length:   { maximum: 255 }
  validates :remote_option,
            inclusion: { in: [true, false] }

  # ------------------------------------------------------------
  # DOCUMENTOS ADJUNTOS
  # ------------------------------------------------------------
  has_one_attached :signed_contract
  has_many_attached :annexes

  # ------------------------------------------------------------
  # CALLBACKS Y NORMALIZACIÓN
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.contract_number = contract_number.to_s.strip.upcase
    self.work_location   = work_location.to_s.strip.titleize
    self.salary_currency = salary_currency.to_s.strip.upcase if salary_currency
    self.benefits        = benefits.map(&:strip) if benefits
  end

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------
  # Duración real del contrato en días
  def duration_days
    return unless start_date && end_date
    (end_date - start_date).to_i
  end

  # Comprueba si vence en los próximos X días
  def expiring_within?(days)
    return false unless end_date
    end_date <= Date.current + days
  end

  # Comprueba si está en periodo de prueba (primeros X días)
  def in_probation_period?(days)
    return false unless probation_days && start_date
    Date.current <= start_date + probation_days
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS
  # ------------------------------------------------------------
  scope :active,             -> { where(status: statuses[:active]) }
  scope :drafts,             -> { where(status: statuses[:draft]) }
  scope :expiring_soon,      ->(days = 30) { where(end_date: Date.current..Date.current + days) }
  scope :by_person,          ->(pid) { where(person_id: pid) }
  scope :by_company,         ->(cid) { where(company_id: cid) }
  scope :by_contract_nature, ->(nature) { where(contract_nature: contract_natures[nature]) }
  scope :expired,            -> { where(status: statuses[:expired]) }

  # ------------------------------------------------------------
  # VALIDACIONES PERSONALIZADAS
  # ------------------------------------------------------------
  validate :end_date_after_start_date

  def end_date_after_start_date
    return if start_date.blank? || end_date.blank?
    if end_date < start_date
      errors.add(:end_date, "debe ser posterior a la fecha de inicio")
    end
  end
end
end