# app/models/daily_attendance.rb
class DailyAttendance < ApplicationRecord
  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :person
  has_many   :punch_records,
             -> { order(:occurred_at) },
             primary_key: :date,
             foreign_key: :occurred_at,
             dependent: :nullify

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :person, :date, :scheduled_hours, :worked_hours, presence: true
  validates :scheduled_hours,
            :worked_hours,
            :overtime_hours,
            numericality: { greater_than_or_equal_to: 0 }
  validates :tardiness_minutes,
            :early_leave_minutes,
            :incidents_count,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 }
  validates :notes,
            length: { maximum: 500 },
            allow_blank: true
  validate  :worked_vs_scheduled_consistency

  # ------------------------------------------------------------
  # CALLBACKS / NORMALIZACIÓN
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.notes = notes.to_s.strip if notes
  end

  # ------------------------------------------------------------
  # VALIDACIONES PERSONALIZADAS
  # ------------------------------------------------------------
  def worked_vs_scheduled_consistency
    return unless worked_hours && scheduled_hours && overtime_hours
    if worked_hours > scheduled_hours + overtime_hours + 0.01
      errors.add(:worked_hours, 'no puede exceder scheduled_hours + overtime_hours')
    end
  end

  # ------------------------------------------------------------
  # MÉTODOS DE CÁLCULO
  # ------------------------------------------------------------
  # Recalcula worked_hours basándose en punch_records
  def recalculate_from_punches!
    ins  = punch_records.select(&:clock_in?).map(&:occurred_at)
    outs = punch_records.select(&:clock_out?).map(&:occurred_at)
    return unless ins.any? && outs.any?
    pairs = ins.zip(outs)
    total = pairs.sum { |in_t, out_t| ((out_t - in_t) / 3600.0).round(2) }
    self.worked_hours = total
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_person,     ->(p) { where(person: p) }
  scope :on_date,        ->(d) { where(date: d) }
  scope :between,        ->(from, to) { where(date: from..to) }
  scope :with_overtime,  -> { where('overtime_hours > 0') }
  scope :with_tardiness, -> { where('tardiness_minutes > 0') }
  scope :recent,         ->(days = 7) { where('date >= ?', days.days.ago) }
end