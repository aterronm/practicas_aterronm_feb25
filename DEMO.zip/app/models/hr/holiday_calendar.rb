# app/models/holiday_calendar.rb
class HolidayCalendar < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES / TIPOS DE FESTIVO
  # ------------------------------------------------------------
  enum holiday_type: {
    national: 0,  # Festivo nacional
    regional: 1,  # Festivo autonómico/estatal
    local:    2   # Festivo municipal/local
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :country

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :country, :date, :holiday_type, :name, presence: true
  validates :name, length: { maximum: 100 }
  validates :description, length: { maximum: 500 }, allow_blank: true
  validates :date, uniqueness: { scope: :country_id, message: "ya existe un festivo para este país en esa fecha" }

  # ------------------------------------------------------------
  # CALLBACKS / NORMALIZACIÓN
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.name        = name.to_s.strip.titleize
    self.description = description.to_s.strip if description
  end

  # ------------------------------------------------------------
  # SCOPES
  # ------------------------------------------------------------
  scope :for_country, ->(country) { where(country: country) }
  scope :by_type,     ->(type)    { where(holiday_type: holiday_types[type]) }
  scope :between,     ->(from, to){ where(date: from..to) }
  scope :upcoming,    ->(limit = 10){ where('date >= ?', Date.current).order(:date).limit(limit) }
  scope :for_year,    ->(year)    { where("EXTRACT(YEAR FROM date) = ?", year) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Devuelve true si el día es festivo para el país
  def self.holiday?(country, date)
    exists?(country: country, date: date)
  end

  # Mostrar fecha, nombre y tipo
  def to_s
    "#{date}: #{name} (#{holiday_type.humanize})"
  end
end