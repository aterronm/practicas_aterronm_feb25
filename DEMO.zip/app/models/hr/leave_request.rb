# app/models/leave_request.rb
class LeaveRequest < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA EL ESTADO DE LA SOLICITUD
  # ------------------------------------------------------------
  enum status: {
    draft:     0,  # Borrador, no enviado
    pending:   1,  # Enviado y a la espera de aprobación
    approved:  2,  # Aprobada
    rejected:  3,  # Denegada
    cancelled: 4   # Cancelada por el solicitante
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :person
  belongs_to :absence_type
  belongs_to :approver, class_name: 'User', optional: true

  has_one :absence_record, dependent: :nullify

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :person, :absence_type, :start_date, :end_date, presence: true
  validates :end_date,
            timeliness: { on_or_after: :start_date, type: :date }
  validates :reason,
            presence: true,
            length:   { maximum: 500 }, if: :pending_or_higher?

  validate :within_annual_limit
  validate :no_overlap_with_existing_absences

  # ------------------------------------------------------------
  # CALLBACKS / NORMALIZACIÓN
  # ------------------------------------------------------------
  before_validation :normalize_fields
  after_update :create_absence_record, if: -> { saved_change_to_status? && approved? }

  def normalize_fields
    self.reason           = reason.to_s.strip if reason
    self.manager_comments = manager_comments.to_s.strip if manager_comments
  end

  # ------------------------------------------------------------
  # MÉTODOS DE VALIDACIÓN PERSONALIZADA
  # ------------------------------------------------------------
  def within_annual_limit
    return unless absence_type.annual_limit_days.positive?
    used = person.absence_records
                 .where(absence_type: absence_type)
                 .where('start_date BETWEEN ? AND ?', start_date.beginning_of_year, end_date.end_of_year)
                 .sum('end_date - start_date + 1')
    requested = (end_date - start_date + 1).to_i
    if used + requested > absence_type.annual_limit_days
      errors.add(:base, "Excede el límite anual de #{absence_type.annual_limit_days} días para #{absence_type.name}")
    end
  end

  def no_overlap_with_existing_absences
    overlapping = person.absence_records
                        .where('start_date <= ? AND end_date >= ?', end_date, start_date)
    errors.add(:base, "Ya existe otra ausencia en ese periodo") if overlapping.exists?
  end

  # Crea el registro de ausencia tras la aprobación
  def create_absence_record
    AbsenceRecord.create!(
      person:       person,
      absence_type: absence_type,
      start_date:   start_date,
      end_date:     end_date,
      source:       self
    )
  end

  # ------------------------------------------------------------
  # SCOPES
  # ------------------------------------------------------------
  scope :for_person,       ->(p) { where(person: p) }
  scope :by_status,        ->(s) { where(status: statuses[s]) }
  scope :pending_requests, ->    { where(status: statuses[:pending]) }
  scope :approved_requests,->    { where(status: statuses[:approved]) }
  scope :within_period,    ->(from, to) { where('start_date <= ? AND end_date >= ?', to, from) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  def pending_or_higher?
    status.in?(%w[pending approved rejected cancelled])
  end

  def duration_days
    (end_date - start_date + 1).to_i
  end
end