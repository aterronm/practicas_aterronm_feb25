# app/models/overtime_record.rb
class OvertimeRecord < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES / ESTADO DE LA SOLICITUD DE HORAS EXTRA
  # ------------------------------------------------------------
  enum status: {
    pending:  0,  # Pendiente de aprobación
    approved: 1,  # Aprobada
    rejected: 2   # Rechazada
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :person
  belongs_to :position,   optional: true
  belongs_to :approved_by, class_name: 'User', optional: true

  # ------------------------------------------------------------
  # VALIDACIONES DE CAMPOS
  # ------------------------------------------------------------
  validates :person, :date, :start_time, :end_time, :rate_multiplier, presence: true
  validates :hours,
            numericality: { greater_than: 0 },
            presence: true

  validates :date,
            timeliness: { on_or_before: -> { Date.current }, type: :date }
  validates :end_time,
            timeliness: { after: :start_time, type: :time }
  validates :rate_multiplier,
            numericality: { greater_than_or_equal_to: 1.0 }
  validates :reason,
            length: { maximum: 500 }, allow_blank: true

  # ------------------------------------------------------------
  # CALLBACKS / NORMALIZACIÓN
  # ------------------------------------------------------------
  before_validation :normalize_fields
  after_validation  :compute_hours, if: -> { start_time && end_time }

  def normalize_fields
    self.reason = reason.to_s.strip if reason
  end

  # ------------------------------------------------------------
  # CÁLCULO AUTOMÁTICO DE HORAS
  # ------------------------------------------------------------
  def compute_hours
    calculated = ((end_time - start_time) / 3600.0).round(2)
    self.hours ||= calculated
  end

  # ------------------------------------------------------------
  # MÉTODOS DE APROBACIÓN
  # ------------------------------------------------------------
  def approve!(user)
    transaction do
      update!(status: :approved, approved_by: user, reviewed_at: Time.current)
      # Opcional: registrar ledger o pago extra
    end
  end

  def reject!(user)
    update!(status: :rejected, approved_by: user, reviewed_at: Time.current)
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS
  # ------------------------------------------------------------
  scope :pending,       -> { where(status: statuses[:pending]) }
  scope :approved,      -> { where(status: statuses[:approved]) }
  scope :rejected,      -> { where(status: statuses[:rejected]) }
  scope :for_person,    ->(p) { where(person: p) }
  scope :for_position,  ->(pos) { where(position: pos) }
  scope :on_date,       ->(d) { where(date: d) }
  scope :between,       ->(from, to) { where(date: from..to) }
  scope :recent,        ->(days = 7) { where('requested_at >= ?', days.days.ago) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  def amount(base_rate_per_hour)
    (base_rate_per_hour * hours * rate_multiplier).round(2)
  end

  def minutes
    (hours * 60).to_i
  end
end