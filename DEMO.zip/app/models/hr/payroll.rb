class Payroll < ApplicationRecord
end
