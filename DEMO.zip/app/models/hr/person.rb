# app/models/hr/person.rb
module Hr
  class Person < ApplicationRecord

    # ------------------------------------------------------------
    # ASOCIACIONES
    # ------------------------------------------------------------
    belongs_to :country,               class_name: 'Core::Country'
    belongs_to :tax_residency_country, class_name: 'Core::Country'
    belongs_to :nationality_country,   class_name: 'Core::Country'

    # ------------------------------------------------------------
    # ENUMERACIONES
    # ------------------------------------------------------------
    enum :gender, { male: 0, female: 1, non_binary: 2, undisclosed: 3 }
    enum :preferred_contact_method, {
      by_email: 0, by_phone: 1, by_sms: 2, by_post: 3
    }

    include Normalizable

    # Asociación inversa para ProjectMembership
    has_many :project_memberships,
             class_name: 'Pm::ProjectMembership',
             foreign_key: 'person_id',
             inverse_of:  :person,
             dependent:   :destroy

    has_many :assigned_tasks,
             class_name: 'Pm::Task',
             foreign_key: 'assignee_id',
             inverse_of: :assignee

    # Opcional: acceso directo a proyectos
    has_many :projects,
             through: :project_memberships,
             source:  :project

    # Verifica que los valores que lleguen a gender y preferred_contact_method sean válidos
    validates :gender, inclusion: { in: genders.keys }
    validates :preferred_contact_method,
              inclusion: { in: preferred_contact_methods.keys }

    # ------------------------------------------------------------
    # VALIDACIONES BÁSICAS
    # ------------------------------------------------------------
    validates :first_name, :last_name,
              presence: true, length: { maximum: 100 }

    validates :identification_type, presence: true
    validates :identification_number,
              presence: true, uniqueness: true,
              length: { in: 6..20 },
              format: { with: /\A[A-Z0-9\-]+\z/, message: "formato inválido" }

    validates :social_security_number,
              presence: true, uniqueness: true,
              length: { in: 9..15 },
              format: { with: /\A[0-9A-Z]+\z/, message: "sólo caracteres alfanuméricos" }

    validates :tax_identification_number,
              presence: true, uniqueness: true,
              length: { maximum: 20 },
              format: { with: /\A[A-Z0-9]+\z/, message: "formato TIN inválido" }

    validates :country, :tax_residency_country, :nationality_country,
              presence: true

    # Fecha de nacimiento
    validates :date_of_birth,
              presence: true,
              timeliness: { on_or_before: -> { Date.current }, type: :date }

    # ------------------------------------------------------------
    # CONTACTO
    # ------------------------------------------------------------
    validates :email,
              presence: true, uniqueness: { case_sensitive: false },
              length: { maximum: 255 },
              format: { with: URI::MailTo::EMAIL_REGEXP }

    validates :phone,
              presence: true,
              format: { with: /\A\+?[0-9]{7,15}\z/, message: "entre 7 y 15 dígitos" }

    validates :mobile_phone, :secondary_phone,
              format: { with: /\A\+?[0-9]{7,15}\z/ }, allow_blank: true

    # ------------------------------------------------------------
    # DIRECCIÓN PRINCIPAL
    # ------------------------------------------------------------
    validates :street, :city, :state, :postal_code, presence: true
    validates :street, :city, length: { maximum: 255 }
    validates :state, length: { maximum: 100 }
    validates :postal_code, length: { maximum: 20 }

    # ------------------------------------------------------------
    # DATOS BANCARIOS
    # ------------------------------------------------------------
    validates :bank_iban,
              presence: true, uniqueness: true,
              format: { with: /\A[A-Z]{2}[0-9]{22}\z/, message: "formato IBAN inválido" }

    validates :bank_bic,
              length: { in: 8..11 }, allow_blank: true,
              format: { with: /\A[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?\z/, message: "formato BIC inválido" }

    validates :bank_name,
              presence: true, length: { maximum: 100 }

    # ------------------------------------------------------------
    # CONSENTIMIENTOS Y PREFERENCIAS
    # ------------------------------------------------------------
    validates :terms_accepted_at, :privacy_policy_accepted_at, :gdpr_consent_at,
              presence: true

    validates :data_sharing_consent,
              inclusion: { in: [true, false] }

    has_one_attached :avatar

    # ------------------------------------------------------------
    # MÉTODOS AUXILIARES
    # ------------------------------------------------------------
    delegate :name, to: :nationality_country, prefix: true, allow_nil: true

    # Nombre completo
    def full_name
      [first_name, last_name].compact.join(" ")
    end

    # Cálculo de edad preciso
    def age
      return unless date_of_birth
      today = Time.zone.today
      age = today.year - date_of_birth.year
      age -= 1 if today < date_of_birth + age.years
      age
    end

    # ------------------------------------------------------------
    # SCOPES
    # ------------------------------------------------------------
    scope :adults,             -> { where('date_of_birth <= ?', 18.years.ago) }
    scope :minors,             -> { where('date_of_birth > ?', 18.years.ago) }
    scope :by_gender,          ->(g) { where(gender: genders[g]) }
    scope :by_nationality,     ->(c) { joins(:nationality_country).where(core_countries: { iso: c.to_s.upcase }) }
    scope :by_country,         ->(c) { joins(:country).where(core_countries: { iso: c.to_s.upcase }) }
    scope :birthdays_in_month, ->(m) { where('EXTRACT(MONTH FROM date_of_birth) = ?', m) }
  end
end
