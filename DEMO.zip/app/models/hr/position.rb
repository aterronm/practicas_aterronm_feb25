# app/models/hr/position.rb
module Hr
  class Position < ApplicationRecord
    include Normalizable

    # ------------------------------------------------------------
    # ASOCIACIONES
    # ------------------------------------------------------------
    # Cada posición pertenece a una persona (Hr::Person)
    belongs_to :person, class_name: 'Hr::Person'

    # Cada posición pertenece a un departamento
    belongs_to :department, class_name: 'Core::Department'

    # Relación jerárquica de puestos: supervisor y subalternos
    belongs_to :supervisor,
               class_name: 'Hr::Position',
               optional: true

    has_many   :subordinates,
               class_name: 'Hr::Position',
               foreign_key: 'supervisor_id',
               dependent: :nullify,
               inverse_of: :supervisor

    # ------------------------------------------------------------
    # ENUMERACIONES
    # ------------------------------------------------------------
    enum :contract_type, {
      full_time:  0,
      part_time:  1,
      temporary:  2,
      permanent:  3,
      internship: 4,
      freelance:  5
    }

    enum :status, {
      active:    0,
      vacant:    1,
      suspended: 2,
      completed: 3,
      cancelled: 4
    }

    enum :shift_type, {
      morning:   0,
      afternoon: 1,
      night:     2,
      flexible:  3
    }

    enum :job_level, {
      intern:    0,
      junior:    1,
      mid:       2,
      senior:    3,
      lead:      4,
      manager:   5,
      director:  6,
      executive: 7
    }

    # ------------------------------------------------------------
    # VALIDACIONES DE CAMPOS
    # ------------------------------------------------------------
    validates :person, presence: true
    validates :department, presence: true

    validates :job_code,
              presence:   true,
              uniqueness: true,
              length:     { maximum: 50 }

    validates :title,
              presence: true,
              length:   { maximum: 200 }

    validates :description,
              length: { maximum: 5000 },
              allow_blank: true

    validates :job_level,
              presence: true,
              inclusion: { in: job_levels.keys, message: "nivel no válido" }

    validates :salary_min,
              numericality: { greater_than_or_equal_to: 0 },
              allow_blank: true

    validates :salary_max,
              numericality: { greater_than_or_equal_to: 0 },
              allow_blank: true
    validate  :salary_range_consistency

    validates :probation_period_days,
              numericality: { only_integer: true, greater_than_or_equal_to: 0 },
              allow_blank: true

    serialize :benefits, coder: ::YAML
    validates :benefits,
              length: { maximum: 100 },
              allow_blank: true

    validates :hours_per_week,
              presence: true,
              numericality: { only_integer: true, greater_than: 0, less_than_or_equal_to: 168 }

    validates :shift_type, presence: true

    validates :start_date,
              presence: true,
              timeliness: { on_or_before: -> { Date.current }, type: :date }

    validates :end_date,
              timeliness: { on_or_after: -> { start_date }, type: :date },
              allow_blank: true

    validates :notice_period_days,
              numericality: { only_integer: true, greater_than_or_equal_to: 0 },
              allow_blank: true

    validates :termination_reason,
              length: { maximum: 1000 },
              allow_blank: true

    validates :termination_date,
              timeliness: { on_or_before: -> { Date.current }, type: :date },
              allow_blank: true

    validates :cost_center_code,
              length: { maximum: 50 },
              allow_blank: true

    validates :project_code,
              length: { maximum: 50 },
              allow_blank: true

    # ------------------------------------------------------------
    # ADJUNTOS
    # ------------------------------------------------------------
    has_one_attached :contract_document

    # ------------------------------------------------------------
    # CALLBACKS DE NORMALIZACIÓN
    # ------------------------------------------------------------
    before_validation :normalize_fields

    def normalize_fields
      self.job_code         = job_code.to_s.strip.upcase       if job_code_changed?
      self.title            = title.to_s.strip.titleize        if title_changed?
      # department es asociación; no normalizamos aquí.
      # job_level es enum; no normalizamos aquí.
      self.benefits         = benefits.map(&:strip) if benefits_changed? && benefits
      self.cost_center_code = cost_center_code.to_s.strip.upcase if cost_center_code_changed? && cost_center_code
      self.project_code     = project_code.to_s.strip.upcase     if project_code_changed? && project_code
    end

    # ------------------------------------------------------------
    # VALIDACIONES PERSONALIZADAS
    # ------------------------------------------------------------
    private

    def salary_range_consistency
      return if salary_min.blank? || salary_max.blank?
      if salary_max < salary_min
        errors.add(:salary_max, "debe ser mayor o igual que salario mínimo")
      end
    end

    def only_one_manager_per_department
      return unless manager?

      existing = Position.where(department_id: department_id, manager: true)
      if new_record?
        errors.add(:manager, 'ya existe un manager para este departamento') if existing.exists?
      else
        if existing.where.not(id: id).exists?
          errors.add(:manager, 'ya existe otro manager para este departamento')
        end
      end
    end

    # ------------------------------------------------------------
    # MÉTODOS AUXILIARES DE ESTADO
    # ------------------------------------------------------------
    public

    # Duración del puesto en días
    def duration_days
      return unless end_date
      (end_date - start_date).to_i
    end

    # ¿Está activo hoy?
    def active_now?
      active? && start_date <= Date.current && (end_date.nil? || end_date >= Date.current)
    end

    # ¿En periodo de prueba?
    def in_probation?
      probation_period_days.present? &&
        (Date.current - start_date).to_i <= probation_period_days
    end

    # ¿Terminada?
    def terminated?
      termination_date.present? && termination_date <= Date.current
    end

    # ------------------------------------------------------------
    # SCOPES PARA CONSULTAS
    # ------------------------------------------------------------
    scope :active,         -> { where(status: statuses[:active]) }
    scope :vacant,         -> { where(status: statuses[:vacant]) }
    scope :for_person,     ->(pid) { where(person_id: pid) }
    scope :by_contract,    ->(ct)  { where(contract_type: contract_types[ct]) }
    scope :by_department,  ->(dept_id) { where(department_id: dept_id) }
    scope :by_job_level,   ->(lvl) { where(job_level: job_levels[lvl]) }
    scope :recent,         ->      { order(start_date: :desc) }
    scope :search, ->(q) {
      return all unless q.present?
      kw = "%#{q}%"
      left_joins(:person)
        .where("people.first_name ILIKE :kw OR people.last_name ILIKE :kw OR people.email ILIKE :kw", kw: kw)
    }


    # ------------------------------------------------------------
    # VALIDACIONES DE SUPERVISIÓN
    # ------------------------------------------------------------
    validate :only_one_manager_per_department, if: :manager?

  end
end
