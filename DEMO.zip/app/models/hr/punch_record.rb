 # app/models/punch_record.rb
class PunchRecord < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES / TIPOS DE EVENTO DE FICHAJE
  # ------------------------------------------------------------
  enum event_type: {
    clock_in:      0,  # Entrada jornada
    clock_out:     1,  # Salida jornada
    break_start:   2,  # Inicio de pausa
    break_end:     3,  # Fin de pausa
    adjustment:    4,  # Ajuste manual
    missed:        5   # Fichaje omitido
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :person
  belongs_to :position, optional: true

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :person, :occurred_at, :event_type, presence: true
  validates :notes, length: { maximum: 500 }, allow_blank: true
  validates :ip_address,
            format: { with: Resolv::IPv4::Regex, message: 'no es una IPv4 válida' },
            allow_blank: true
  validates :latitude,
            numericality: { greater_than_or_equal_to: -90, less_than_or_equal_to: 90 },
            allow_blank: true
  validates :longitude,
            numericality: { greater_than_or_equal_to: -180, less_than_or_equal_to: 180 },
            allow_blank: true
  validates :occurred_at,
            timeliness: { on_or_before: -> { Time.current }, type: :datetime }

  # ------------------------------------------------------------
  # CALLBACKS / NORMALIZACIÓN
  # ------------------------------------------------------------
  before_validation :normalize_fields

  private

  def normalize_fields
    self.notes      = notes.to_s.strip if notes
    self.ip_address = ip_address.to_s.strip if ip_address
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS
  # ------------------------------------------------------------
  scope :for_person,    ->(person)   { where(person: person) }
  scope :for_position,  ->(position) { where(position: position) }
  scope :on_date,       ->(date)     { where(occurred_at: date.beginning_of_day..date.end_of_day) }
  scope :between,       ->(from, to) { where(occurred_at: from..to) }
  scope :by_event_type, ->(type)     { where(event_type: event_types[type]) }
  scope :recent,        ->(limit = 50) { order(occurred_at: :desc).limit(limit) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Determina si es una entrada válida
  def entry?
    clock_in? || break_end?
  end

  # Determina si es una salida válida
  def exit?
    clock_out? || break_start?
  end

  # Determina si el evento corresponde a una pausa
  def pause?
    break_start? || break_end?
  end
end