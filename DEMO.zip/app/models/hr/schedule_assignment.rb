# app/models/schedule_assignment.rb
module Hr
class ScheduleAssignment < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES / ESTADO DE ASIGNACIÓN
  # ------------------------------------------------------------
  # Cambiamos el nombre de la columna a `status` para mayor claridad;
  # en la migración debería ser:
  #   t.integer :status, null: false, default: 1
  # en lugar de `active`.
  enum :status, { inactive: 0, active: 1 }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :work_schedule
  # Permite asignar el horario a distintos modelos (Hr::Person, Hr::Position, etc.)
  belongs_to :assignable, polymorphic: true

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_notes

  def normalize_notes
    return unless respond_to?(:notes) && notes_changed?
    self.notes = notes.to_s.strip
  end

  # ------------------------------------------------------------
  # VALIDACIONES BÁSICAS
  # ------------------------------------------------------------
  validates :work_schedule, :assignable, :start_date, presence: true

  validates :end_date,
            timeliness: { on_or_after: :start_date, type: :date },
            allow_blank: true

  validate :no_overlapping_assignments

  # ------------------------------------------------------------
  # VALIDACIÓN PERSONALIZADA: NO SOLAPAMIENTOS
  # ------------------------------------------------------------
  def no_overlapping_assignments
    return unless assignable && start_date

    # Construir rango de fechas usando Infinity si end_date es nulo
    overlap_end = end_date || Date::Infinity.new
    overlapping = ScheduleAssignment
      .where(assignable: assignable)
      .where.not(id: id)
      .where("start_date <= :overlap_end AND (end_date IS NULL OR end_date >= :start_date)",
             overlap_end: overlap_end, start_date: start_date)

    if overlapping.exists?
      errors.add(:base, "Existe otra asignación de horario que se solapa en ese periodo")
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :active,         -> { where(status: statuses[:active]) }
  scope :inactive,       -> { where(status: statuses[:inactive]) }

  scope :for_assignable, ->(obj) { where(assignable: obj) }

  # Asignaciones vigentes en una fecha dada
  scope :current_on,     ->(date) {
    where("start_date <= :date AND (end_date IS NULL OR end_date >= :date)", date: date)
  }

  # Asignaciones cuyo periodo (start..end) se cruza con [from_date..to_date]
  scope :between_dates,  ->(from_date, to_date) {
    where("start_date <= :to AND (end_date IS NULL OR end_date >= :from)",
          from: from_date, to: to_date)
  }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  public

  # ¿Está activa esta asignación en la fecha `date`?
  def active_on?(date)
    active? && start_date <= date && (end_date.nil? || date <= end_date)
  end

  # Verifica si se solapa con otra asignación en memoria
  def overlaps?(other)
    return false unless other.start_date

    self.start_date <= (other.end_date || Date::Infinity.new) &&
      (self.end_date.nil? || other.start_date <= self.end_date)
  end
end
end