# app/models/time_entry.rb
class TimeEntry < ApplicationRecord
  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :task
  belongs_to :person

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :task, :person, :date, :hours, presence: true
  validates :hours,
            numericality: { greater_than: 0 }
  validates :date,
            timeliness: { on_or_before: -> { Date.current }, type: :date }
  validates :description,
            length: { maximum: 1000 },
            allow_blank: true

  # ------------------------------------------------------------
  # CALLBACKS / NORMALIZACIÓN
  # ------------------------------------------------------------
  before_validation :normalize_fields

  private

  def normalize_fields
    self.description = description.to_s.strip if description
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_task,   ->(task)   { where(task: task) }
  scope :for_person, ->(person) { where(person: person) }
  scope :on_date,    ->(date)   { where(date: date) }
  scope :between,    ->(from, to){ where(date: from..to) }
  scope :recent,     ->(days = 7) { where('date >= ?', days.days.ago) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  def to_s
    "#{date}: #{hours}h - #{description.to_s.truncate(50)}"
  end
end