# app/models/work_schedule.rb
module Hr
class WorkSchedule < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES / TIPOS DE HORARIO
  # ------------------------------------------------------------
  enum :schedule_type, {
    fixed:    0,  # Mismo horario cada día
    rotating: 1,  # Ciclo rotativo (por semanas)
    custom:   2   # Definido libremente por cada día
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  # Cada WorkSchedule puede asignarse a multiple schedule_assignments
  # Ejemplo: asignar este horario a empleados, posiciones o equipos
  has_many :schedule_assignments, dependent: :destroy, inverse_of: :work_schedule

  # ------------------------------------------------------------
  # VALIDACIONES DE CAMPOS
  # ------------------------------------------------------------
  validates :name,
            presence:   true,
            uniqueness: { case_sensitive: false },
            length:     { maximum: 100 }

  validates :schedule_type, presence: true

  validates :start_time,
            presence: true,
            if: -> { fixed? || rotating? }

  validates :end_time,
            presence: true,
            if: -> { fixed? || rotating? }

  validate :time_consistency, on: [:create, :update]

  # days_of_week almacena un arreglo de strings (e.g. ["monday", "wednesday"])
  # Solo para fixed y rotating
  validates :days_of_week,
            presence: true,
            if: -> { fixed? || rotating? }

  validate :days_of_week_values, if: -> { days_of_week.present? }

  # Para custom: allow una estructura JSON con horarios por día
  # Ejemplo de custom_schedule:
  # {
  #   "monday":   { "start_time": "08:00", "end_time": "16:00", "break": ["12:00","13:00"] },
  #   "tuesday":  { "start_time": "10:00", "end_time": "18:00" },
  #    ...
  # }
  validates :custom_schedule,
            presence: true,
            if: -> { custom? }

  validate :custom_schedule_structure, if: -> { custom? && custom_schedule.present? }

  # ------------------------------------------------------------
  # NORMALIZACIÓN / CALLBACKS
  # ------------------------------------------------------------
  before_validation :normalize_fields

  private

  def normalize_fields
    # 1) Limpiar y formatear name/description
    self.name = name.to_s.strip.titleize if name_changed?
    self.description = description.to_s.strip if description_changed?

    # 2) Normalizar días de la semana a minúsculas sin duplicados
    if days_of_week_changed? && days_of_week.is_a?(Array)
      cleaned = days_of_week.map(&:to_s)
                            .map(&:strip)
                            .map(&:downcase)
                            .map { |d| d.slice(0,3) } # usar abreviatura de 3 letras
      self.days_of_week = cleaned.uniq
    end
  end

  # ------------------------------------------------------------
  # MÉTODOS DE VALIDACIÓN PERSONALIZADA
  # ------------------------------------------------------------
  def time_consistency
    return unless start_time && end_time

    if end_time <= start_time
      errors.add(:end_time, 'debe ser posterior a la hora de inicio')
    end
  end

  def days_of_week_values
    # Solo permitir abreviaturas válidas: mon, tue, wed, thu, fri, sat, sun
    valid_abbr = %w[mon tue wed thu fri sat sun]
    invalid = days_of_week.reject { |d| valid_abbr.include?(d) }
    return if invalid.empty?

    errors.add(:days_of_week, "contiene valores inválidos: #{invalid.join(', ')}")
  end

  def custom_schedule_structure
    unless custom_schedule.is_a?(Hash)
      errors.add(:custom_schedule, 'debe ser un objeto JSON')
      return
    end

    custom_schedule.each do |day, info|
      unless day.is_a?(String) && %w[monday tuesday wednesday thursday friday saturday sunday].include?(day.downcase)
        errors.add(:custom_schedule, "#{day} no es un día válido")
      end

      unless info.is_a?(Hash) &&
             info['start_time'].present? && info['end_time'].present?
        errors.add(:custom_schedule, "día #{day} debe incluir start_time y end_time")
        next
      end

      begin
        st = info['start_time'].to_time
        et = info['end_time'].to_time
      rescue
        errors.add(:custom_schedule, "horarios de #{day} no tienen formato hh:mm")
        next
      end

      if et <= st
        errors.add(:custom_schedule, "en #{day}, end_time debe ser posterior a start_time")
      end

      if info['break'].present?
        unless info['break'].is_a?(Array) && info['break'].size == 2
          errors.add(:custom_schedule, "break en #{day} debe ser arreglo de 2 horas")
          next
        end

        bs, be = info['break']
        begin
          bst = bs.to_time; bet = be.to_time
        rescue
          errors.add(:custom_schedule, "pausa en #{day} debe ser hh:mm")
          next
        end

        if bst < st || bet > et
          errors.add(:custom_schedule, "pausa en #{day} debe estar dentro del rango de jornada")
        end
        if bet <= bst
          errors.add(:custom_schedule, "en #{day}, break end_time debe ser posterior a break start_time")
        end
      end
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :active,   -> { where(active: true) }
  scope :inactive, -> { where(active: false) }
  scope :by_type,  ->(type) { where(schedule_type: schedule_types[type.to_s]) }

  # Busca todos los horarios que incluyan el día abreviado (mon, tue, etc.)
  scope :for_day,  ->(day_abbr) {
    where("? = ANY(days_of_week)", day_abbr.to_s.strip.downcase)
  }

  # Para custom schedules, devuelve schedules que definan el día específico
  scope :for_custom_day, ->(day_name) {
    where("custom_schedule ? :day", day: day_name.downcase)
  }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  public

  # Calcula horas totales de un día fijo/rotativo (excluye pausa)
  def work_hours_per_day
    return unless start_time && end_time
    total = ((end_time - start_time) / 3600.0)
    if break_start_time && break_end_time
      total -= ((break_end_time - break_start_time) / 3600.0)
    end
    total.round(2)
  end

  # Retorna la duración de pausa en horas
  def break_hours
    return 0 unless break_start_time && break_end_time
    ((break_end_time - break_start_time) / 3600.0).round(2)
  end

  # Para schedules rotativos: imprime next cycle dates (ejemplo simplificado)
  def next_rotating_cycle(start_date = Date.current)
    return [] unless rotating?
    # Supongamos un ciclo semanal fijo: retorna próximos 7 días que coincidan con days_of_week
    days_abbr_to_num = { 'mon'=>1, 'tue'=>2, 'wed'=>3, 'thu'=>4, 'fri'=>5, 'sat'=>6, 'sun'=>0 }
    numbers = days_of_week.map { |d| days_abbr_to_num[d] }
    (0..13).each_with_object([]) do |offset, arr|
      date = start_date + offset
      arr << date if numbers.include?(date.wday)
      break arr if arr.size >= 7
    end
  end
end
end