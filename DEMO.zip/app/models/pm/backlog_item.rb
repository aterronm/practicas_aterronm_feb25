# app/models/backlog_item.rb
module Pm

  class BacklogItem < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES / TIPOS, ESTADO Y PRIORIDAD
  # ------------------------------------------------------------
  enum :item_type, { epic: 0, story: 1, bug: 2, spike: 3 }
  enum :status, { draft: 0, ready: 1, in_progress: 2, done: 3, closed: 4 }
  enum :priority, { low: 0, medium: 1, high: 2, critical: 3 }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :project, inverse_of: :backlog_items

  belongs_to :parent,
             class_name: 'Pm::BacklogItem',
             optional: true,
             inverse_of: :children
  has_many   :children,
             class_name: 'Pm::BacklogItem',
             foreign_key: 'parent_id',
             dependent: :nullify,
             inverse_of: :parent

  has_many   :sprint_backlog_items,
             dependent: :destroy,
             inverse_of: :backlog_item
  has_many   :sprints,
             through: :sprint_backlog_items

  has_many   :tasks,
             dependent: :destroy,
             inverse_of: :backlog_item
  has_many_attached :documents

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.title                = title.to_s.strip.squish
    self.description          = description.to_s.strip      if description
    self.acceptance_criteria  = acceptance_criteria.to_s.strip if acceptance_criteria
    self.notes                = notes.to_s.strip            if notes
  end

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :project, :item_type, :title, :status, presence: true
  validates :title, length: { maximum: 255 }
  validates :description, :acceptance_criteria, :notes,
            length: { maximum: 2000 }, allow_blank: true
  validates :story_points,
            numericality: { only_integer: true, greater_than_or_equal_to: 0 }
  validate  :epic_parent_must_be_epic

  def epic_parent_must_be_epic
    return unless parent_id
    unless parent&.epic?
      errors.add(:parent, 'debe ser de tipo epic para ser padre')
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_project,    ->(proj)   { where(project: proj) }
  scope :epics,          ->         { where(item_type: item_types[:epic]) }
  scope :stories,        ->         { where(item_type: item_types[:story]) }
  scope :bugs,           ->         { where(item_type: item_types[:bug]) }
  scope :by_status,      ->(st)     { where(status: statuses[st]) }
  scope :by_priority,    ->(p)      { where(priority: priorities[p]) }
  scope :search_title,   ->(term)   { where('title ILIKE ?', "%\#{term.to_s.strip}%") }

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------

  # Indica si un bug está bloqueado (sin tareas completadas)
  def blocked?
    bug? && tasks.where.not(status: Task.statuses[:done]).exists?
  end

  # Resumen en una sola línea
  def summary
    "[\#{item_type.humanize}] \#{title} (\#{status.humanize})"
  end

  # Calcula total de story points, incluye sub-ítems
  def total_story_points
    children.sum(:story_points) + story_points.to_i
  end
end

  end