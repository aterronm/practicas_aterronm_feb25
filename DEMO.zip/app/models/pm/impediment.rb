# app/models/impediment.rb

module Pm
class Impediment < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA ESTADO E IMPACTO
  # ------------------------------------------------------------
  enum :status, {
    open:        0,  # Abierta, sin atender
    in_progress: 1,  # En proceso de resolución
    resolved:    2,  # Resuelta, pendiente cierre
    closed:      3   # Cerrada definitivamente
  }

  enum :severity, {
    low:       0,  # Baja
    medium:    1,  # Media
    high:      2,  # Alta
    critical:  3   # Crítica
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :project,
             inverse_of: :impediments

  belongs_to :sprint,
             inverse_of: :impediments,
             optional: true

  belongs_to :reported_by,
             class_name: 'Hr::Person',
             inverse_of: :reported_impediments

  belongs_to :resolved_by,
             class_name: 'Hr::Person',
             inverse_of: :resolved_impediments,
             optional: true

  has_many_attached :documents

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation do
    self.title            = title.to_s.strip.squish
    self.description      = description.to_s.strip    if description
    self.resolution_notes = resolution_notes.to_s.strip if resolution_notes
  end

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :project, :status, :severity, :title, :description, :reported_by, :reported_at, presence: true

  validates :title,
            length: { maximum: 255 }

  validates :description,
            length: { maximum: 2000 }

  validates :resolution_notes,
            length: { maximum: 2000 },
            allow_blank: true

  validates :reported_at,
            presence: true

  validates :resolved_at,
            comparison: { greater_than_or_equal_to: :reported_at,
                          message: 'no puede ser anterior a la fecha de reporte' },
            allow_blank: true

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_project,      ->(proj)     { where(project: proj) }
  scope :with_status,      ->(st)       { where(status: statuses[st]) }
  scope :open,             ->            { with_status(:open) }
  scope :in_progress,      ->            { with_status(:in_progress) }
  scope :resolved,         ->            { with_status(:resolved) }
  scope :closed,           ->            { with_status(:closed) }
  scope :by_severity,      ->(sev)      { where(severity: severities[sev]) }
  scope :high_severity,    ->            { where(severity: [severities[:high], severities[:critical]]) }
  scope :reported_between, ->(from, to) { where(reported_at: from..to) }
  scope :recent,           ->(n = 20)   { order(reported_at: :desc).limit(n) }

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------

  # Pasa a "in_progress"
  def start!
    update!(status: :in_progress) if open?
  end

  # Marca como "resolved" y registra quién y cuándo
  def resolve!(person, notes = nil)
    transaction do
      update!(
        status:           :resolved,
        resolved_by:      person,
        resolved_at:      Time.current,
        resolution_notes: notes.presence || resolution_notes
      )
    end
  end

  # Cierra definitivamente si está resuelta
  def close!
    update!(status: :closed) if resolved?
  end

  # True si no está cerrada
  def active?
    !closed?
  end
end
end