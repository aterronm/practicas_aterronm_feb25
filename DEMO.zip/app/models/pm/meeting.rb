# app/models/meeting.rb
module Pm
class Meeting < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA TIPOS Y ESTADOS DE CEREMONIA
  # ------------------------------------------------------------
  enum :meeting_type, {
    daily:              0,  # Daily Standup
    sprint_planning:    1,  # Sprint Planning
    sprint_review:      2,  # Sprint Review / Demo
    sprint_retrospective:3,  # Sprint Retrospective
    backlog_refinement: 4,  # Backlog Refinement / Grooming
    ad_hoc:             5   # Reunión ad-hoc
  }
  enum :status, {
    scheduled:   0,  # Programada
    in_progress: 1,  # En curso
    completed:   2,  # Finalizada
    cancelled:   3   # Cancelada
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :project                             # Proyecto al que pertenece
  belongs_to :sprint,    optional: true           # (opcional) Sprint asociado
  has_many_attached :documents                    # Actas, presentaciones, etc.

  # Participantes mediante tabla intermedia
  has_many :meeting_participants, dependent: :destroy
  has_many :participants,
           through: :meeting_participants,
           source: :person

  # ------------------------------------------------------------
  # CAMPOS (migración sugerida)
  # ------------------------------------------------------------
  # t.references :project,      null: false, foreign_key: true
  # t.references :sprint,                      foreign_key: true
  # t.integer    :meeting_type, null: false, default: 0
  # t.integer    :status,       null: false, default: 0
  # t.datetime   :start_at,     null: false
  # t.datetime   :end_at,       null: false
  # t.string     :location,     limit: 255        # Ubicación física
  # t.string     :remote_url,   limit: 500        # Enlace videoconferencia
  # t.text       :agenda                          # Puntos a tratar
  # t.text       :minutes                         # Acta / acuerdos

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :project, :meeting_type, :status, :start_at, :end_at, presence: true
  validates :location, length: { maximum: 255 }, allow_blank: true
  validates :remote_url,
            length: { maximum: 500 },
            format: {
              with: /\Ahttps?:\/\/[\S]+\z/,
              message: "debe ser una URL válida"
            },
            allow_blank: true
  validates :agenda, :minutes, length: { maximum: 2000 }, allow_blank: true
  validate  :end_after_start

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields
  def normalize_fields
    self.location   = location.to_s.strip.titleize if location
    self.remote_url = remote_url.to_s.strip if remote_url
    self.agenda     = agenda.to_s.strip if agenda
    self.minutes    = minutes.to_s.strip if minutes
  end

  # ------------------------------------------------------------
  # MÉTODO DE VALIDACIÓN PERSONALIZADA
  # ------------------------------------------------------------
  def end_after_start
    return unless start_at && end_at
    if end_at <= start_at
      errors.add(:end_at, "debe ser posterior a start_at")
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_project,   ->(proj) { where(project: proj) }
  scope :for_sprint,    ->(sp)   { where(sprint: sp) }
  scope :by_type,       ->(t)    { where(meeting_type: meeting_types[t]) }
  scope :upcoming,      ->       { where("start_at >= ?", Time.current).order(:start_at) }
  scope :recent,        ->(limit=10) { where("start_at <= ?", Time.current).order(start_at: :desc).limit(limit) }
  scope :between,       ->(from, to) { where(start_at: from..to) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Duración de la reunión en minutos
  def duration_minutes
    return 0 unless start_at && end_at
    ((end_at - start_at) / 60).to_i
  end

  # Duración en horas (con decimales)
  def duration_hours
    return 0.0 unless start_at && end_at
    ((end_at - start_at) / 3600.0).round(2)
  end
end
end