# app/models/meeting_participant.rb
module Pm

  class MeetingParticipant < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA ROLES Y ESTADO DE ASISTENCIA
  # ------------------------------------------------------------
  enum :role, {
    attendee:      0,  # Asistente
    presenter:     1,  # Presentador
    note_taker:    2,  # Secretario / actas
    facilitator:   3,  # Facilitador
    stakeholder:   4   # Stakeholder invitado
  }
  enum :attendance_status, {
    invited:   0,      # Invitado, sin confirmar
    accepted:  1,      # Ha aceptado asistir
    declined:  2,      # Ha rechazado
    attended:  3       # Asistió efectivamente
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :meeting                       # Reunión en la que participa
  belongs_to :person                        # Persona que participa

  # ------------------------------------------------------------
  # CAMPOS (migración sugerida)
  # ------------------------------------------------------------
  # t.references :meeting,          null: false, foreign_key: true
  # t.references :person,           null: false, foreign_key: true
  # t.integer    :role,             null: false, default: 0
  # t.integer    :attendance_status, null: false, default: 0
  # t.boolean    :present,          default: false  # Si efectivamente asistió
  # t.text       :notes                          # Observaciones

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :meeting, :person, :role, :attendance_status, presence: true
  validates :notes, length: { maximum: 500 }, allow_blank: true
  validates :present, inclusion: { in: [true, false] }

  # No duplicar la misma persona en una misma reunión
  validates :person_id, uniqueness: { scope: :meeting_id, message: "ya está asignado a esta reunión" }

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields
  def normalize_fields
    self.notes = notes.to_s.strip if notes
  end

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Marca asistencia y actualiza el estado
  def mark_attended!
    update!(attendance_status: :attended, present: true)
  end

  # Marca como ausente tras asistir invitado
  def mark_absent!
    update!(attendance_status: :declined, present: false)
  end
end

  end