# app/models/project.rb

module Pm

class Project < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA TIPOS Y ESTADOS DE PROYECTO
  # ------------------------------------------------------------
  # Estado del ciclo de vida del proyecto
  enum :status, {
    planning:   0,  # En planificación
    active:     1,  # En curso
    on_hold:    2,  # En pausa
    completed:  3,  # Completado
    cancelled:  4   # Cancelado
  }

  # Tipo de proyecto
  enum :project_type, {
    internal: 0,    # Proyecto interno
    external: 1     # Proyecto para cliente
  }

  # Prioridad de proyecto
  enum :priority, {
    low:      0,
    medium:   1,
    high:     2,
    critical: 3
  }

  # Imagen principal del proyecto
  has_one_attached :photo

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :client, class_name: "Core::Client"                             # Cliente que encarga el proyecto
  has_many   :project_memberships, class_name: "Pm::ProjectMembership",               # Relación con usuarios y roles
             dependent: :destroy,
             inverse_of: :project

  has_many   :team_members,                      # Todas las personas en el proyecto
             through: :project_memberships,
             source: :person

  # Accesos directos por rol
  has_many :product_owners,
           -> { where(project_memberships: { role: :product_owner }) },
           through: :project_memberships,
           source: :person

  has_many :scrum_masters,
           -> { where(project_memberships: { role: :scrum_master }) },
           through: :project_memberships,
           source: :person
  has_many :developers,
           -> { where(project_memberships: { role: :developer }) },
           through: :project_memberships,
           source: :person
  has_many :testers,
           -> { where(project_memberships: { role: :tester }) },
           through: :project_memberships,
           source: :person
  has_many :stakeholders,
           -> { where(project_memberships: { role: :stakeholder }) },
           through: :project_memberships,
           source: :person

  has_many :sprints,               dependent: :destroy  # Sprints del proyecto
  has_many :backlog_items,         dependent: :destroy  # Product Backlog
  has_many :impediments,           dependent: :destroy
  has_many :risks,                 dependent: :destroy
  has_many :tasks, class_name: "Pm::Task", dependent: :destroy, inverse_of: :project

  # Documentación general del proyecto
  has_many_attached :documents

  # ------------------------------------------------------------
  # CAMPOS (migración sugerida)
  # ------------------------------------------------------------
  # t.references :client,          null: false, foreign_key: true
  # t.string     :code,            null: false, limit: 50
  # t.string     :name,            null: false, limit: 255
  # t.text       :description
  # t.date       :start_date
  # t.date       :end_date_estimated
  # t.date       :end_date_actual
  # t.integer    :status,          null: false, default: 0
  # t.integer    :project_type,    null: false, default: 1
  # t.integer    :priority,        null: false, default: 1
  # t.decimal    :budget,          precision: 15, scale: 2
  # t.string     :currency,        limit: 3

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :client, :code, :name, :status, :project_type, :priority, presence: true
  validates :code,
            uniqueness: { scope: :client_id, case_sensitive: false },
            length:     { maximum: 50 }
  validates :name,
            length: { maximum: 255 }
  validates :description,
            length: { maximum: 2000 },
            allow_blank: true
  validates :budget,
            numericality: { greater_than_or_equal_to: 0 },
            allow_blank: true
  validates :currency,
            length: { is: 3 },
            format: { with: /\A[A-Z]{3}\z/, message: "debe ser código ISO4217" },
            allow_blank: true
  validate  :end_date_not_before_start

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields
  def normalize_fields
    self.code               = code.to_s.strip.upcase
    self.name               = name.to_s.strip.titleize
    self.description = description.to_s.strip if description
    self.currency    = currency.to_s.strip.upcase if currency
  end

  # ------------------------------------------------------------
  # VALIDACIONES PERSONALIZADAS
  # ------------------------------------------------------------
  def end_date_not_before_start
    return unless start_date && end_date_estimated
    if end_date_estimated < start_date
      errors.add(:end_date_estimated, "no puede ser anterior a la fecha de inicio")
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_client,        ->(c) { where(client: c) }
  scope :by_status,         ->(s) { where(status: statuses[s]) }
  scope :active,            ->    { where(status: statuses[:active]) }
  scope :overdue,           ->    { where("end_date_estimated < ? AND status = ?", Date.current, statuses[:active]) }
  scope :upcoming_deadline, ->(days) { where("end_date_estimated BETWEEN ? AND ?", Date.current, days.days.from_now) }

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------
  # Duración estimada en días
  def estimated_duration_days
    return unless start_date && end_date_estimated
    (end_date_estimated - start_date).to_i
  end

  # Duración real en días
  def actual_duration_days
    return unless start_date && end_date_actual
    (end_date_actual - start_date).to_i
  end

  # Porcentaje de ejecución (basado en sprints completados)
  def percent_complete
    total = sprints.count
    return 0 if total.zero?
    done  = sprints.where(status: :completed).count
    (done * 100.0 / total).round(2)
  end

  end
end