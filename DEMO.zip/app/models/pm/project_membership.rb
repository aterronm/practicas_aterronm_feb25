# app/models/project_membership.rb
module Pm

  class ProjectMembership < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA ROLES EN EL PROYECTO
  # ------------------------------------------------------------
  enum :role, {
    product_owner:  0,
    scrum_master:   1,
    developer:      2,
    tester:         3,
    architect:      4,
    analyst:        5,
    stakeholder:    6,
    other:          7
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :project, class_name: "Pm::Project", inverse_of: :project_memberships
  belongs_to :person,  class_name: "Hr::Person", inverse_of: :project_memberships

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :project, :person, :role, :start_date, presence: true
  validates :role, inclusion: { in: roles.keys }

  validates :end_date,
            comparison: { greater_than_or_equal_to: :start_date, message: "no puede ser anterior a la fecha de inicio" },
            allow_blank: true

  validates :allocated_hours,
            numericality: { greater_than_or_equal_to: 0 }

  validates :actual_hours,
            numericality: { greater_than_or_equal_to: 0 }

  validates :hourly_rate,
            numericality: { greater_than_or_equal_to: 0 },
            allow_blank: true

  validates :responsibilities, :notes,
            length: { maximum: 1000 },
            allow_blank: true

  validate :no_overlapping_roles

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation do
    self.responsibilities = responsibilities.to_s.strip if responsibilities
    self.notes            = notes.to_s.strip            if notes
  end

  # ------------------------------------------------------------
  # VALIDACIÓN PERSONALIZADA: evita solapamientos
  # ------------------------------------------------------------
  def no_overlapping_roles
    return unless start_date

    window_end = end_date || start_date
    overlapping =
      self.class
          .where(project_id: project_id, person_id: person_id, role: role)
          .where.not(id: id)
          .where("start_date <= :window_end AND (end_date IS NULL OR end_date >= :start_date)",
                 window_end: window_end, start_date: start_date)

    if overlapping.exists?
      errors.add(:base, "Ya existe otra asignación de #{role.humanize} para esta persona en ese periodo")
    end
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS
  # ------------------------------------------------------------
  scope :for_project,   ->(proj)    { where(project: proj) }
  scope :for_person,    ->(pers)    { where(person: pers) }
  scope :by_role,       ->(r)       { where(role: roles[r]) }
  scope :covering,      ->(date)    {
    where("start_date <= :d AND (end_date IS NULL OR end_date >= :d)", d: date)
  }
  scope :active,        ->          { covering(Date.current) }
  scope :between_dates, ->(from,to) {
    where("start_date <= :to AND (end_date IS NULL OR end_date >= :from)", from: from, to: to)
  }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------

  # Días de asignación (incluye el día de inicio y fin)
  def duration_days
    finish = end_date || Date.current
    (finish - start_date).to_i + 1
  end

  # Coste estimado: allocated_hours * hourly_rate
  def estimated_cost
    (hourly_rate.to_f * allocated_hours.to_f).round(2)
  end

  # Coste real: actual_hours * hourly_rate
  def actual_cost
    (hourly_rate.to_f * actual_hours.to_f).round(2)
  end
end

  end