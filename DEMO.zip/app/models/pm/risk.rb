# app/models/risk.rb
module Pm
  class Risk < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA CATEGORÍAS, PROBABILIDAD, IMPACTO Y ESTADO
  # ------------------------------------------------------------
  enum :category, {
    operational: 0,  # Riesgos operativos
    strategic:   1,  # Riesgos estratégicos
    compliance:  2,  # Riesgos de cumplimiento
    financial:   3,  # Riesgos financieros
    reputational:4,  # Riesgos reputacionales
    other:       5   # Otro
  }

  enum :probability, {
    low:       0,   # Baja probabilidad
    medium:    1,   # Probabilidad media
    high:      2,   # Alta probabilidad
    critical:  3    # Probabilidad crítica
  }

  enum :impact, {
    low:       0,   # Impacto bajo
    medium:    1,   # Impacto medio
    high:      2,   # Impacto alto
    critical:  3    # Impacto crítico
  }

  enum :status, {
    open:        0, # Abierto / identificado
    mitigated:   1, # Mitigado parcialmente
    closed:      2  # Cerrado / resuelto
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :project                 # Proyecto al que pertenece
  belongs_to :owner,
             class_name: 'Hr::Person',
             optional: true           # Persona responsable de gestionar el riesgo

  # Evidencias y planes de mitigación adjuntos
  has_many_attached :documents

  # ------------------------------------------------------------
  # CAMPOS (migración sugerida)
  # ------------------------------------------------------------
  # t.references :project,       null: false, foreign_key: true
  # t.string     :title,         null: false, limit: 255
  # t.integer    :category,      null: false, default: 0
  # t.text       :description,   null: false
  # t.integer    :probability,   null: false, default: 1
  # t.integer    :impact,        null: false, default: 1
  # t.integer    :status,        null: false, default: 0
  # t.text       :mitigation_plan                   # Plan de mitigación
  # t.datetime   :identified_at, null: false, default: -> { 'CURRENT_TIMESTAMP' }
  # t.datetime   :mitigated_at                       # Fecha de mitigación

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :project, :title, :description, :probability, :impact, presence: true
  validates :title, length: { maximum: 255 }
  validates :description, :mitigation_plan,
            length: { maximum: 2000 },
            allow_blank: true
  validates :mitigated_at,
            timeliness: { on_or_after: :identified_at, type: :datetime },
            allow_blank: true

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields
  def normalize_fields
    self.title            = title.to_s.strip.capitalize
    self.description      = description.to_s.strip if description
    self.mitigation_plan  = mitigation_plan.to_s.strip if mitigation_plan
  end

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_project,    ->(p) { where(project: p) }
  scope :open,           ->    { where(status: statuses[:open]) }
  scope :mitigated,      ->    { where(status: statuses[:mitigated]) }
  scope :closed,         ->    { where(status: statuses[:closed]) }
  scope :by_category,    ->(c) { where(category: categories[c]) }
  scope :high_risk,      ->    { where(probability: [probabilities[:high], probabilities[:critical]])
    .where(impact: [impacts[:high], impacts[:critical]]) }
  scope :recent,         ->(limit = 20) { order(identified_at: :desc).limit(limit) }

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------
  # Retorna una puntuación compuesta de severidad (probabilidad * impacto)
  def severity_score
    probability_before_type_cast * impact_before_type_cast
  end

  # Etiqueta legible con categoría, probabilidad e impacto
  def label
    "[#{category.humanize}] Prob: #{probability.humanize}, Imp: #{impact.humanize}"
  end
end
  end