# app/models/sprint.rb
module Pm

  class Sprint < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA EL ESTADO DEL SPRINT
  # ------------------------------------------------------------
  enum :status, {
    planned:   0,  # Planificado, no iniciado
    active:    1,  # En curso
    completed: 2,  # Finalizado
    cancelled: 3   # Cancelado
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :project, inverse_of: :sprints

  has_many   :sprint_backlog_items,
             inverse_of: :sprint,
             dependent:  :destroy
  has_many   :backlog_items,
             through:    :sprint_backlog_items

  has_many   :meetings,
             inverse_of: :sprint,
             dependent:  :nullify

  has_many   :impediments,
             inverse_of: :sprint,
             dependent:  :nullify

  has_many_attached :documents

  # ------------------------------------------------------------
  # NORMALIZACIÓN ANTES DE VALIDAR
  # ------------------------------------------------------------
  before_validation :normalize_fields

  def normalize_fields
    self.name = name.to_s.strip.squish
    self.goal = goal.to_s.strip       if goal.present?
  end

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :project, :name, :start_date, :end_date, :status, :number, presence: true
  validates :name, length: { maximum: 255 }

  validates :number,
            numericality: { only_integer: true, greater_than: 0 },
            uniqueness: { scope: :project_id }

  validates :goal, length: { maximum: 2000 }, allow_blank: true

  validates :end_date,
            comparison: { greater_than_or_equal_to: :start_date,
                          message: "debe ser posterior a la fecha de inicio" }

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_project, ->(proj) { where(project: proj) }
  scope :by_status,   ->(s)    { where(status: statuses[s]) }
  scope :upcoming,    ->       { where("start_date > ?", Date.current) }
  scope :current,     ->       { where("start_date <= ? AND end_date >= ?", Date.current, Date.current) }
  scope :finished,    ->       { by_status(:completed) }

  # ------------------------------------------------------------
  # MÉTODOS DE NEGOCIO
  # ------------------------------------------------------------
  # Días de duración del sprint
  def duration_days
    (end_date - start_date).to_i + 1
  end

  # Puntos de historia totales planificados
  def total_story_points
    backlog_items.sum(:story_points)
  end

  # Puntos de historia completados
  def completed_story_points
    backlog_items.where(status: BacklogItem.statuses[:done]).sum(:story_points)
  end

  # Velocidad (equivalente a puntos completados)
  def velocity
    completed_story_points
  end
end

  end