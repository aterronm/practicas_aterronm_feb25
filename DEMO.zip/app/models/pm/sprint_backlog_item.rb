# app/models/sprint_backlog_item.rb
module Pm

  class SprintBacklogItem < ApplicationRecord
  # ------------------------------------------------------------
  # ENUMERACIONES PARA ESTADO DENTRO DEL SPRINT
  # ------------------------------------------------------------
  enum :status, {
    planned:     0,  # Planificado para el sprint
    in_progress: 1,  # En progreso
    completed:   2,  # Completado
    removed:     3   # Eliminado/retrasado
  }

  # ------------------------------------------------------------
  # ASOCIACIONES
  # ------------------------------------------------------------
  belongs_to :sprint,
             inverse_of: :sprint_backlog_items
  belongs_to :backlog_item,
             inverse_of: :sprint_backlog_items
  belongs_to :assignee,
             class_name: 'Hr::Person',
             foreign_key: 'assignee_id',
             inverse_of: :assigned_sprint_items,
             optional: true

  # ------------------------------------------------------------
  # NORMALIZACIÓN Y VALORES POR DEFECTO
  # ------------------------------------------------------------
  before_validation :normalize_fields
  before_validation :set_default_planned_points, on: :create

  # ------------------------------------------------------------
  # VALIDACIONES
  # ------------------------------------------------------------
  validates :sprint, :backlog_item, :status, :planned_points, presence: true

  validates :planned_points, :completed_points,
            comparison: { greater_than_or_equal_to: 0 }

  validates :sort_order,
            comparison: { greater_than_or_equal_to: 0 }

  validates :notes,
            length: { maximum: 1000 },
            allow_blank: true

  validates :completed_points,
            comparison: { less_than_or_equal_to: :planned_points,
                          message: "no puede superar los puntos planificados" }

  # ------------------------------------------------------------
  # SCOPES PARA CONSULTAS FRECUENTES
  # ------------------------------------------------------------
  scope :for_sprint,    ->(sp)    { where(sprint: sp) }
  scope :for_backlog,   ->(bi)    { where(backlog_item: bi) }
  scope :with_status,   ->(st)    { where(status: statuses[st]) }
  scope :completed,     ->        { with_status(:completed) }
  scope :in_progress,   ->        { with_status(:in_progress) }
  scope :assigned_to,   ->(p)     { where(assignee: p) }
  scope :ordered,       ->        { order(:sort_order) }

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES
  # ------------------------------------------------------------
  # Porcentaje de progreso basado en puntos
  def progress_percentage
    return 0 if planned_points.to_i.zero?
    (completed_points.to_f * 100 / planned_points).round(2)
  end

  # Marca como completado y ajusta completed_points
  def mark_completed!
    update!(status: :completed, completed_points: planned_points)
  end

  private

  def normalize_fields
    self.notes = notes.to_s.strip if notes
  end

  def set_default_planned_points
    if backlog_item && planned_points.nil?
      self.planned_points = backlog_item.story_points
    end
  end
end

  end