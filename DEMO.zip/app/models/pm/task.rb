module Pm
  class Task < ApplicationRecord
    # ------------------------------------------------------------
    # ENUMERACIONES PARA ESTADO Y TIPO DE TRABAJO
    # ------------------------------------------------------------
    enum :status, {
      todo:    0,
      doing:   1,
      done:    2,
      blocked: 3
    }

    enum :work_type, {
      development:  0,
      testing:      1,
      documentation:2,
      research:     3,
      other:        4
    }

    # ------------------------------------------------------------
    # ASOCIACIONES
    # ------------------------------------------------------------
    belongs_to :project, class_name: "Pm::Project", inverse_of: :tasks
    belongs_to :assignee,
               class_name: 'Hr::Person',
               foreign_key: 'assignee_id',
               inverse_of: :assigned_tasks,
               optional: true

    has_many   :time_entries, inverse_of: :task, dependent: :destroy
    has_many   :comments,     as: :commentable, dependent: :destroy

    # ------------------------------------------------------------
    # NORMALIZACIÓN ANTES DE VALIDAR
    # ------------------------------------------------------------
    before_validation do
      self.title       = title.to_s.strip.squish
      self.description = description.to_s.strip if description
      self.notes       = notes.to_s.strip       if notes
    end

    # ------------------------------------------------------------
    # VALIDACIONES
    # ------------------------------------------------------------
    validates :project, :title, :status, :work_type, presence: true
    validates :title, length: { maximum: 255 }
    validates :description, :notes, length: { maximum: 2000 }, allow_blank: true

    validates :estimated_hours,
              numericality: { greater_than_or_equal_to: 0 }

    validates :started_at,
              comparison: {
                less_than_or_equal_to: -> { Time.current },
                message: 'no puede ser en el futuro'
              },
              allow_blank: true

    validates :completed_at,
              comparison: {
                greater_than_or_equal_to: :started_at,
                message: 'no puede ser antes de start_at'
              },
              allow_blank: true

    validate :completed_at_sets_done

    # ------------------------------------------------------------
    # CALLBACK PARA SINCRONIZAR HORAS
    # ------------------------------------------------------------

    def completed_at_sets_done
      if completed_at.present? && !done?
        errors.add(:status, 'debe marcarse como done si completed_at está presente')
      end
    end

    # ------------------------------------------------------------
    # SCOPES
    # ------------------------------------------------------------
    scope :assigned_to,  ->(p) { where(assignee: p) }
    scope :by_status,    ->(st){ where(status: statuses[st]) }
    scope :by_work_type, ->(wt){ where(work_type: work_types[wt]) }
    scope :recent,       ->(n=50){ order(created_at: :desc).limit(n) }
  end
end
