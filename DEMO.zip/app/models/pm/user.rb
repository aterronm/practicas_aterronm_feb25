module Pm

class User < ApplicationRecord
  # ------------------------------------------------------------
  # Devise (autenticación / recuperación / OAuth2)
  # ------------------------------------------------------------
  devise :database_authenticatable,
         :recoverable, :rememberable, :validatable,
         :omniauthable, omniauth_providers: %i[google_oauth2]

  # ------------------------------------------------------------
  # ASOCIACIÓN A Role
  # ------------------------------------------------------------
  # Ahora cada usuario puede pertenecer a un rol (opcional)
  belongs_to :role, optional: true

  # ------------------------------------------------------------
  # MÉTODO PARA LOGEAR VIA OAUTH (Google)
  # ------------------------------------------------------------
  def self.from_omniauth(auth)
    user = find_by(email: auth.info.email)
    return nil unless user

    user.update(provider: auth.provider, uid: auth.uid)
    user
  end

  # ------------------------------------------------------------
  # MÉTODOS AUXILIARES DE ROL
  # ------------------------------------------------------------
  # Ejemplo: comprueba si el usuario tiene un rol especificado
  def has_role?(role_code)
    role.present? && role.code == role_code.to_s.strip.downcase
  end

  # Obtener nombre legible del rol, si existe
  def role_name
    role&.name
  end
end

end
