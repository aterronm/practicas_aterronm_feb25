# frozen_string_literal: true

class AgeValidator < ActiveModel::Validator
  def validate(record)
    if record.birthdate.present? && record.birthdate > 18.years.ago.to_date
      record.errors.add(:birthdate, "must be at least 18 years old")
    end
  end
end
