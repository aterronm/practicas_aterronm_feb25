# config/initializers/kaminari_config.rb

Kaminari.configure do |config|
  # Cuántos elementos mostrar por página (valor por defecto)
  config.default_per_page = 25

  # Límite máximo de elementos por página (puedes cambiarlo o establecer nil para ilimitado)
  # config.max_per_page = nil

  # Nombre del parámetro que recoge la página (por defecto: :page)
  # config.param_name = :page

  # Nombre del scope (si quieres usarlo desde el modelo como `Model.page()`)
  # config.scope = :page

  # Cuántos links adyacentes mostrar a cada lado del current page
  # e.g. si total_pages es 10 y current_page es 5, con window = 4 → mostraría [1] ... [3] [4] [5] [6] [7] ... [10]
  # config.window = 4

  # Cuántos links mostrar al inicio y al final (outside window)
  # config.outer_window = 0

  # Clase CSS que se le asignará al <div> que envuelve los enlaces de paginación
  # config.container_class = 'pagination'

  # Si quieres que los enlaces usen "aria-label" para accesibilidad
  # config.aria = true

  # Si quieres que las URL generadas usen record_count = total_count para algún fin
  # config.page_method_name = :page

  # Si deseas configurar otro i18n scope
  # config.i18n_scope = 'kaminari'
end

