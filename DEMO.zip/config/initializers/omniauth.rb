# frozen_string_literal: true

# Google's OAuth2 docs. Make sure you are familiar with all the options
# before attempting to configure this gem.
# https://developers.google.com/accounts/docs/OAuth2Login

Rails.application.config.middleware.use OmniAuth::Builder do
  # Default usage, this will give you offline access and a refresh token
  # using default scopes 'email' and 'profile'
  #
  provider :google_oauth2, '119011303183-j35gl4bb0jh8s454ik5glof5j37etkks.apps.googleusercontent.com', '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', scope: 'email, profile'

  OmniAuth.config.allowed_request_methods = %i[get]

  OmniAuth.config.on_failure = proc do |env|
    "Users::OmniauthCallbacksController".constantize.action(:failure).call(env)
  end

  def failure
    flash[:error] = 'There was an error while trying to authenticate you...'
    redirect_to new_user_session_path
  end

end