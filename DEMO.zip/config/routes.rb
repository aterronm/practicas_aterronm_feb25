Rails.application.routes.draw do
  devise_for :users,
             class_name: 'Pm::User',
             skip: [:registrations],
             controllers: { omniauth_callbacks: 'users/omniauth_callbacks' }

  get "up" => "rails/health#show", as: :rails_health_check

  #root "pages#login"
  root    to: 'home#index'
  get     '/about', to: 'home#about', as: 'about'
  resources :users, class_name: 'Pm::User', only: [:index]
  resources :positions, class_name: 'Pm::Position', only: [:index, :show, :new, :create, :edit, :update, :destroy]

  resources :projects, class_name: 'Pm::Project', only: [:index, :show, :new, :create, :edit, :update, :destroy] do
    resources :tasks, only: [:create]
  end

  resources :clients, class_name: 'Pm::Client', only: [:index, :show, :new, :create, :edit, :update, :destroy]

end
