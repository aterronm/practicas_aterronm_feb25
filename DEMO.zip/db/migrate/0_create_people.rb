# db/migrate/20250601_create_people.rb
class CreatePeople < ActiveRecord::Migration[6.1]
  def change
    create_table :people do |t|
      # Datos personales
      t.string  :first_name,  null: false, limit: 100
      t.string  :last_name,   null: false, limit: 100
      t.integer :gender,      null: false, default: 3   # 3 = undisclosed

      # Identificaciones
      t.string :identification_type,   null: false
      t.string :identification_number, null: false, limit: 20
      t.string :social_security_number, null: false, limit: 15
      t.string :tax_identification_number, null: false, limit: 20

      # Relaciones con países
      t.references :country,                 null: false, foreign_key: true
      t.references :tax_residency_country,   null: false, foreign_key: { to_table: :countries }
      t.references :nationality_country,     null: false, foreign_key: { to_table: :countries }

      # Fecha de nacimiento
      t.date :date_of_birth, null: false

      # Contacto
      t.string  :email,        null: false, limit: 255
      t.string  :phone,        null: false, limit: 15
      t.string  :mobile_phone,               limit: 15
      t.string  :secondary_phone,            limit: 15
      t.integer :preferred_contact_method, null: false, default: 0

      # Dirección principal
      t.string :street,      null: false, limit: 255
      t.string :city,        null: false, limit: 255
      t.string :state,       null: false, limit: 100
      t.string :postal_code, null: false, limit: 20

      # Datos bancarios
      t.string :bank_iban, null: false, limit: 34
      t.string :bank_bic,  limit: 11
      t.string :bank_name, null: false, limit: 100

      # Consentimientos y preferencias
      t.datetime :terms_accepted_at,         null: false
      t.datetime :privacy_policy_accepted_at, null: false
      t.datetime :gdpr_consent_at,            null: false
      t.boolean  :data_sharing_consent,       null: false, default: false

      t.timestamps
    end

    # Índices únicos
    add_index :people, :identification_number,    unique: true
    add_index :people, :social_security_number,   unique: true
    add_index :people, :tax_identification_number, unique: true
    add_index :people, :email,                   unique: true
    add_index :people, :bank_iban,               unique: true
  end
end
