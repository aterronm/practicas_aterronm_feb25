# db/migrate/20250607_create_positions.rb
class CreatePositions < ActiveRecord::Migration[8.0]
  def change

    create_table :positions do |t|

      # ------------------------------------------------------------
      # 1) Referencias y asociaciones
      # ------------------------------------------------------------
      t.references :person,     null: false, foreign_key: { to_table: :hr_people }, index: true
      t.references :department, null: false, foreign_key: true,                  index: true
      t.references :supervisor, foreign_key: { to_table: :positions },          index: true

      # ------------------------------------------------------------
      # 2) Enumeraciones (guardadas como integer con default)
      # ------------------------------------------------------------
      t.integer :contract_type, null: false, default: 0
      t.integer :status,        null: false, default: 0
      t.integer :shift_type,    null: false, default: 0
      t.integer :job_level,     null: false, default: 0

      # ------------------------------------------------------------
      # 3) Campos principales
      # ------------------------------------------------------------
      t.string  :job_code,      null: false, limit: 50
      t.string  :title,         null: false, limit: 200
      t.text    :description,                limit: 5000

      t.decimal :salary_min,     precision: 12, scale: 2
      t.decimal :salary_max,     precision: 12, scale: 2

      t.integer :probation_period_days

      t.text    :benefits

      t.integer :hours_per_week, null: false

      t.date    :start_date,     null: false
      t.date    :end_date

      t.integer :notice_period_days

      t.text    :termination_reason, limit: 1000
      t.date    :termination_date

      t.string  :cost_center_code, limit: 50
      t.string  :project_code,     limit: 50

      # ------------------------------------------------------------
      # 4) Flag de manager (jefe de departamento)
      # ------------------------------------------------------------
      t.boolean :manager,        null: false, default: false

      t.timestamps
    end

    # ------------------------------------------------------------
    # 5) Índices de unicidad y auxiliares
    # ------------------------------------------------------------
    # job_code debe ser único en toda la tabla
    add_index :positions, :job_code, unique: true

    # Para acelerar búsquedas por enums
    add_index :positions, :contract_type
    add_index :positions, :status
    add_index :positions, :shift_type
    add_index :positions, :job_level

    # Garantizar que solo haya un manager por departamento (Índice parcial en PostgreSQL)
    reversible do |dir|
      dir.up do
        execute <<-SQL
          CREATE UNIQUE INDEX index_positions_on_department_manager
          ON positions(department_id)
          WHERE manager = TRUE;
        SQL
      end
      dir.down do
        execute "DROP INDEX IF EXISTS index_positions_on_department_manager;"
      end
    end
  end
end
