class CreatePunchRecords < ActiveRecord::Migration[6.1]
  def change
    create_table :punch_records do |t|
      t.references :person,      null: false, foreign_key: true
      t.references :position,                  foreign_key: true
      t.datetime   :occurred_at, null: false
      t.integer    :event_type,   null: false, default: 0
      t.string     :ip_address
      t.decimal    :latitude,     precision: 10, scale: 6
      t.decimal    :longitude,    precision: 10, scale: 6
      t.text       :notes

      t.timestamps
    end

    add_index :punch_records, :event_type,     if_not_exists: true
    add_index :punch_records, :occurred_at,    if_not_exists: true
    add_index :punch_records, :person_id,      if_not_exists: true
  end
end
