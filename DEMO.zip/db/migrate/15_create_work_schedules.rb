class CreateWorkSchedules < ActiveRecord::Migration[6.1]
  def change
    create_table :work_schedules do |t|
      t.string   :name,             null: false, limit: 100
      t.text     :description

      t.integer  :schedule_type,    null: false, default: 0

      # Para schedule_type fixed y rotating
      t.time     :start_time
      t.time     :end_time

      t.time     :break_start_time
      t.time     :break_end_time

      # Días de la semana (array de abreviaturas: mon, tue, wed…)
      t.string   :days_of_week,     array: true, default: []

      # Para schedule_type custom: JSON con definiciones día a día
      t.jsonb    :custom_schedule,  null: false, default: {}

      t.boolean  :active,           null: false, default: true

      t.timestamps
    end

    add_index :work_schedules, :name, unique: true
    add_index :work_schedules, :schedule_type
    add_index :work_schedules, :active
    add_index :work_schedules, :days_of_week,    using: :gin
    add_index :work_schedules, :custom_schedule, using: :gin
  end
end