class CreateAbsenceTypes < ActiveRecord::Migration[6.1]
  def change
    create_table :absence_types do |t|
      t.string  :code,                null: false, limit: 10
      t.string  :name,                null: false, limit: 100
      t.text    :description
      t.integer :category,            null: false, default: 0
      t.boolean :paid,                null: false, default: true
      t.boolean :requires_approval,   null: false, default: true
      t.integer :annual_limit_days,   null: false, default: 0
      t.boolean :carryover_allowed,   null: false, default: false
      t.integer :max_carryover_days,  null: false, default: 0

      t.timestamps
    end

    # Índices y constraints
    add_index :absence_types, :code, unique: true
    add_check_constraint :absence_types, 'annual_limit_days >= 0', name: 'ck_absence_types_annual_limit_non_negative'
    add_check_constraint :absence_types, 'max_carryover_days >= 0', name: 'ck_absence_types_max_carryover_non_negative'
  end
end