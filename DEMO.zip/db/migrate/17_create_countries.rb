class CreateCountries < ActiveRecord::Migration[6.1]
  def change
    create_table :countries do |t|
      t.string  :iso,        null: false, limit: 2, index: { unique: true }
      t.string  :iso3,                    limit: 3
      t.integer :numcode
      t.integer :phonecode,  null: false
      t.string  :name,       null: false, limit: 80
      t.string  :nicename,   null: false, limit: 80
      t.string  :currency_code, limit: 3
      t.string  :timezone,      limit: 50
      t.string  :languages,     array: true, default: []

      t.timestamps
    end

    add_index :countries, :phonecode
    add_index :countries, :currency_code
    add_index :countries, :languages, using: 'gin'
  end
end