class CreateAttendanceIncidents < ActiveRecord::Migration[6.1]
  def change
    create_table :attendance_incidents do |t|
      t.references :person,       null: false, foreign_key: true
      t.references :position,                      foreign_key: true
      t.integer    :incident_type, null: false, default: 0
      t.datetime   :occurred_at,    null: false
      t.integer    :status,         null: false, default: 0
      t.text       :description,    null: false
      t.text       :resolution
      t.datetime   :resolved_at
      t.references :resolved_by,    foreign_key: { to_table: :users }
      t.string     :ip_address
      t.text       :notes

      t.timestamps
    end

    add_index :attendance_incidents, :status
    add_index :attendance_incidents, :incident_type
    add_index :attendance_incidents, :occurred_at
  end
end