class CreateCompanies < ActiveRecord::Migration[6.1]
  def change
    create_table :companies do |t|
      # Identidad
      t.string  :company_name,       null: false, limit: 255
      t.integer :status,             null: false, default: 0
      t.integer :legal_form,         null: false, default: 0

      # Identificadores fiscales
      t.string  :tax_id,             null: false, limit: 20
      t.string  :registration_number,null: false, limit: 100
      t.string  :vat_number,                      limit: 20

      # Contacto
      t.string  :email,                         null: false, limit: 255
      t.string  :phone,                         limit: 20
      t.string  :website,                       limit: 255

      # Dirección fiscal
      t.string  :street,           null: false, limit: 255
      t.string  :city,             null: false, limit: 100
      t.string  :state,            null: false, limit: 100
      t.string  :postal_code,      null: false, limit: 20
      t.string  :country,          null: false, limit: 2

      # Datos económicos
      t.string  :cnae_code,        null: false, limit: 4
      t.date    :founded_on,       null: false
      t.decimal :share_capital,    precision: 15, scale: 2, null: false
      t.integer :employees_count,  null: false, default: 0
      t.date    :fiscal_year_start,null: false
      t.date    :fiscal_year_end,  null: false

      # Bancarios
      t.string  :bank_iban,        null: false, limit: 34
      t.string  :bank_bic,                         limit: 11
      t.string  :bank_name,        null: false, limit: 100

      t.timestamps
    end


    # Asegúrate de que las columnas existan; si no, las defines con add_reference(...)
    add_foreign_key :clients, :people,   column: :person_id
    add_foreign_key :clients, :companies, column: :company_id

    # Índices para unicidad y búsquedas
    add_index :companies, :company_name,       unique: true
    add_index :companies, :tax_id,             unique: true
    add_index :companies, :registration_number,unique: true
    add_index :companies, :email,               unique: true
    add_index :companies, :cnae_code
    add_index :companies, :country
    add_index :companies, :status
    add_index :companies, :legal_form


    # (Opcional) Index para mejorar búsquedas
    add_index :clients, :person_id
    add_index :clients, :company_id
  end
end# frozen_string_literal: true

