class CreateAbsenceRecords < ActiveRecord::Migration[6.1]
  def change
    create_table :absence_records do |t|
      t.references :person,       null: false, foreign_key: true, index: true
      t.references :absence_type, null: false, foreign_key: true
      t.references :approver,     foreign_key: { to_table: :users }
      t.references :source,       polymorphic: true, index: true
      t.date       :start_date,   null: false
      t.date       :end_date,     null: false
      t.integer    :days_count,   null: false, default: 0
      t.text       :notes
      t.string     :status,       null: false, default: 'pending'
      t.datetime   :approved_at

      t.timestamps
    end

    add_index :absence_records, [:person_id, :start_date, :end_date], name: 'index_absences_on_person_and_dates'
    add_check_constraint :absence_records, 'end_date >= start_date', name: 'ck_absences_end_after_start'
  end
end