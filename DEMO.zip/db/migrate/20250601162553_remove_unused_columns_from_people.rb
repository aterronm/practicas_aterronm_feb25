class RemoveUnusedColumnsFromPeople < ActiveRecord::Migration[6.1]
  def change
    # Eliminamos las columnas de países opcionales (si existieran)
    remove_column :people, :secondary_nationality_country_id, :integer
    remove_column :people, :birth_country_id,               :integer

    # Campos de nombre extra que ya no usamos
    remove_column :people, :middle_name, :string
    remove_column :people, :maiden_name, :string

    # Ciudad/estado de nacimiento
    remove_column :people, :birth_city,  :string
    remove_column :people, :birth_state, :string

    # Estado civil y familia
    remove_column :people, :marital_status, :integer
    remove_column :people, :spouse_name,    :string
    remove_column :people, :marriage_date,  :date
    remove_column :people, :divorce_date,   :date
    remove_column :people, :children_count, :integer

    # Fecha de fallecimiento
    remove_column :people, :deceased_on, :date

    # Idiomas avanzados
    remove_column :people, :mother_tongue,   :string
    remove_column :people, :other_languages, :string, array: true, default: []

    # Redes sociales
    remove_column :people, :twitter_handle,   :string
    remove_column :people, :instagram_handle, :string
    remove_column :people, :linkedin_url,     :string
  end
end
