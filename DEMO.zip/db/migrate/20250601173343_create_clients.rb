class CreateClients < ActiveRecord::Migration[8.0]
    def change
      create_table :clients do |t|
        # ------------------------------------------------------------
        # 1) Tipos y estado del cliente
        # ------------------------------------------------------------
        t.integer :client_type, null: false, default: 0  # 0 = individual, 1 = company
        t.integer :status,      null: false, default: 0  # 0 = active, 1 = inactive, 2 = suspended

        # ------------------------------------------------------------
        # 2) Datos comunes al cliente (persona o empresa)
        # ------------------------------------------------------------
        t.string :email,       null: false, limit: 255
        t.string :phone,       null: false, limit: 20

        t.string :street,      null: false, limit: 255
        t.string :city,        null: false, limit: 100
        t.string :state,       null: false, limit: 100
        t.string :postal_code, null: false, limit: 20

        # ------------------------------------------------------------
        # 3) Referencias foráneas
        # ------------------------------------------------------------
        # 3.1) Para cliente “individual” (apunta a hr_persons.id)
        t.references :person,  foreign_key: { to_table: :people }, index: true

        # 3.2) Para cliente “empresa” (apunta a companies.id)
        t.references :company, foreign_key: { to_table: :companies },  index: true

        # 3.3) País (core_countries.id)
        t.references :country, null: false, foreign_key: { to_table: :countries }

        t.timestamps
      end

      # ------------------------------------------------------------
      # 4) Índices y unicidad
      # ------------------------------------------------------------
      add_index :clients, :email, unique: true

      # ------------------------------------------------------------
      # 5) (Opcional) Índices adicionales si quieres acelerar búsquedas:
      # ------------------------------------------------------------
      add_index :clients, :client_type
      add_index :clients, :status
      # Ya tienes índices individuales en person_id y company_id por `t.references …, index: true`.
    end
  end
