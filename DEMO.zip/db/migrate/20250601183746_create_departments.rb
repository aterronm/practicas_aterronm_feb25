# db/migrate/20250606_create_departments.rb
class CreateDepartments < ActiveRecord::Migration[8.0]
  def change
    create_table :departments do |t|
      # ------------------------------
      # Campos básicos
      # ------------------------------
      t.string :name,        null: false, limit: 100
      t.string :code,        null: false, limit: 10
      t.text   :description

      # ------------------------------
      # Jerarquía interna
      # ------------------------------
      t.references :parent,
                   foreign_key: { to_table: :departments },
                   index: true

      t.timestamps
    end

    # ------------------------------
    # Índices de unicidad
    # ------------------------------
    add_index :departments,
              :name,
              unique: true,
              name: 'index_departments_on_name'

    add_index :departments,
              :code,
              unique: true,
              name: 'index_departments_on_code'
  end
end
