class CreateRoles < ActiveRecord::Migration[8.0]
  def change
    # ------------------------------------------------------------
    # 1) Crear tabla roles
    # ------------------------------------------------------------
    create_table :roles do |t|
      t.string :code,        null: false, limit: 50    # p.ej. "hr_admin"
      t.string :name,        null: false, limit: 100   # p.ej. "HR Administrator"
      t.text   :description                           # Opcional

      t.timestamps
    end

    add_index :roles, :code, unique: true, name: 'index_roles_on_code'
    add_index :roles, :name, unique: true, name: 'index_roles_on_name'

    # ------------------------------------------------------------
    # 2) Añadir referencia role_id a users
    # ------------------------------------------------------------
    # Se asume que la tabla de usuarios se llama 'users'
    # y que luego definirás en User: belongs_to :role, optional: true
    add_reference :users, :role, foreign_key: true, index: true
  end
end
