# db/migrate/20250614_create_schedule_assignments.rb
class CreateScheduleAssignments < ActiveRecord::Migration[6.1]
  def change
    create_table :schedule_assignments do |t|
      # ------------------------------------------------------------
      # 1) Referencias y campos principales
      # ------------------------------------------------------------
      t.references :work_schedule, null: false, foreign_key: true, index: true

      # Polymorphic assignable: puede ser Hr::Person, Hr::Position, etc.
      t.string  :assignable_type, null: false
      t.bigint  :assignable_id,   null: false

      t.date    :start_date, null: false
      t.date    :end_date

      # Estado de la asignación: inactive: 0, active: 1
      t.integer :status, null: false, default: 1

      # Notas opcionales (texto libre)
      t.text    :notes

      t.timestamps
    end

    # ------------------------------------------------------------
    # 2) Índices básicos
    # ------------------------------------------------------------
    # Índice único combinado para acelerar búsquedas polimórficas:
    add_index :schedule_assignments, %i[assignable_type assignable_id], name: "index_schedule_assign_on_assignable"

    # Índices para acelerar consultas de solapamiento por fecha
    add_index :schedule_assignments, %i[assignable_type assignable_id start_date], name: "index_schedule_assign_on_assignable_and_start"
    add_index :schedule_assignments, %i[assignable_type assignable_id end_date],   name: "index_schedule_assign_on_assignable_and_end"

    # Índice para filtrar por estado
    add_index :schedule_assignments, :status
  end
end
