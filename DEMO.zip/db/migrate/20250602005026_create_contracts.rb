# db/migrate/20250615_create_contracts.rb
class CreateContracts < ActiveRecord::Migration[8.0]
  def change
    create_table :contracts do |t|
      # ------------------------------------------------------------
      # 1) Referencias / Asociaciones
      # ------------------------------------------------------------
      t.references :person,       null: false, foreign_key: true, index: true
      t.references :position,                     foreign_key: true, index: true
      t.references :company,                      foreign_key: true, index: true

      # ------------------------------------------------------------
      # 2) Enumeraciones (status, contract_nature)
      # ------------------------------------------------------------
      t.integer :status,          null: false, default: 0, index: true
      t.integer :contract_nature, null: false, default: 0, index: true

      # ------------------------------------------------------------
      # 3) Datos básicos del contrato
      # ------------------------------------------------------------
      t.string  :contract_number, null: false, limit: 100

      t.date    :start_date,      null: false, index: true
      t.date    :end_date,        index: true
      t.integer :duration_months
      t.integer :probation_days

      t.integer :hours_per_week,  null: false

      # ------------------------------------------------------------
      # 4) Salario y beneficios
      # ------------------------------------------------------------
      t.decimal :salary_base,     precision: 12, scale: 2, null: false, default: 0.0
      t.string  :salary_currency, null: false, limit: 3

      t.decimal :bonus_percentage, precision: 5, scale: 2, default: 0.0

      # Usamos array nativo en PostgreSQL para benefits
      t.string  :benefits,        array: true, default: []

      # ------------------------------------------------------------
      # 5) Ubicación y modalidad
      # ------------------------------------------------------------
      t.string  :work_location, null: false, limit: 255
      t.boolean :remote_option,  null: false, default: false

      t.timestamps
    end

    # ------------------------------------------------------------
    # 6) Índices adicionales
    # ------------------------------------------------------------
    add_index :contracts, :contract_number, unique: true
    add_index :contracts, %i[person_id company_id], name: "index_contracts_on_person_and_company"
    add_index :contracts, %i[start_date end_date], name: "index_contracts_on_dates"

    # ------------------------------------------------------------
    # 7) Check constraints para asegurar coherencia en la BD
    # ------------------------------------------------------------
    reversible do |dir|
      dir.up do
        # hours_per_week entre 1 y 168
        execute <<-SQL
          ALTER TABLE IF EXISTS contracts
          ADD CONSTRAINT check_hours_per_week
          CHECK (hours_per_week >= 1 AND hours_per_week <= 168);
        SQL

        # salary_base >= 0
        execute <<-SQL
          ALTER TABLE IF EXISTS contracts
          ADD CONSTRAINT check_salary_base_non_negative
          CHECK (salary_base >= 0);
        SQL

        # bonus_percentage entre 0 y 100
        execute <<-SQL
          ALTER TABLE IF EXISTS contracts
          ADD CONSTRAINT check_bonus_percentage_range
          CHECK (bonus_percentage >= 0 AND bonus_percentage <= 100);
        SQL

        # salary_currency debe ser 3 letras mayúsculas ISO4217
        execute <<-SQL
          ALTER TABLE IF EXISTS contracts
          ADD CONSTRAINT check_salary_currency_format
          CHECK (salary_currency ~ '^[A-Z]{3}$');
        SQL

        # end_date >= start_date (si end_date no es NULL)
        execute <<-SQL
          ALTER TABLE IF EXISTS contracts
          ADD CONSTRAINT check_end_after_start
          CHECK (end_date IS NULL OR end_date >= start_date);
        SQL
      end

      dir.down do
        execute "ALTER TABLE contracts DROP CONSTRAINT IF EXISTS check_hours_per_week;"
        execute "ALTER TABLE contracts DROP CONSTRAINT IF EXISTS check_salary_base_non_negative;"
        execute "ALTER TABLE contracts DROP CONSTRAINT IF EXISTS check_bonus_percentage_range;"
        execute "ALTER TABLE contracts DROP CONSTRAINT IF EXISTS check_salary_currency_format;"
        execute "ALTER TABLE contracts DROP CONSTRAINT IF EXISTS check_end_after_start;"
      end
    end
  end
end
