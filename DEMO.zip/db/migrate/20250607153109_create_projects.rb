# db/migrate/20250608_create_projects.rb
class CreateProjects < ActiveRecord::Migration[8.0]
  def change
    create_table :projects do |t|
      t.references :client,
                   null: false,
                   foreign_key: { to_table: :clients },
                   index: false

      t.string  :code,             null: false, limit: 50
      t.string  :name,             null: false, limit: 255
      t.text    :description
      t.date    :start_date
      t.date    :end_date_estimated
      t.date    :end_date_actual

      t.integer :status,           null: false, default: 0
      t.integer :project_type,     null: false, default: 1
      t.integer :priority,         null: false, default: 1

      t.decimal :budget,           precision: 15, scale: 2
      t.string  :currency,         limit: 3

      t.timestamps
    end

    add_index :projects, [:client_id, :code],
              unique: true,
              name: 'index_projects_on_client_and_code'

    add_index :projects, :status
    add_index :projects, :end_date_estimated
  end
end
