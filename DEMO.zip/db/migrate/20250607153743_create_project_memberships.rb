class CreateProjectMemberships < ActiveRecord::Migration[8.0]
  def change
    create_table :project_memberships do |t|
      t.references :project,        null: false, foreign_key: true
      t.references :person,         null: false, foreign_key: true

      t.integer    :role,           null: false, default: 2
      t.date       :start_date,     null: false
      t.date       :end_date

      t.decimal    :allocated_hours, precision: 8, scale: 2, null: false, default: 0.0
      t.decimal    :actual_hours,    precision: 8, scale: 2, null: false, default: 0.0
      t.decimal    :hourly_rate,     precision: 10, scale: 2

      t.text       :responsibilities
      t.text       :notes

      t.timestamps
    end

    # índice compuesto para búsquedas rápidas y evitar solapamientos
    add_index :project_memberships,
              [:project_id, :person_id, :role, :start_date, :end_date],
              name: 'index_pm_on_proj_person_role_dates'

    # índice simple si consultas mucho por fecha de fin
    add_index :project_memberships, :end_date
  end
end
