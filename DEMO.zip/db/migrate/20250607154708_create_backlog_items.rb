class CreateBacklogItems < ActiveRecord::Migration[8.0]
  def change
    create_table :backlog_items do |t|
      t.references :project,
                   null: false,
                   foreign_key: true,
                   index: true

      t.references :parent,
                   foreign_key: { to_table: :backlog_items },
                   index: true

      t.integer    :item_type,         null: false, default: 1
      t.string     :title,             null: false, limit: 255
      t.text       :description
      t.text       :acceptance_criteria
      t.integer    :priority,          null: false, default: 1
      t.integer    :story_points,      null: false, default: 0
      t.integer    :status,            null: false, default: 0
      t.text       :notes

      t.timestamps
    end

    add_index :backlog_items, [:project_id, :status],   name: 'index_bi_on_project_and_status'
    add_index :backlog_items, [:project_id, :priority], name: 'index_bi_on_project_and_priority'
  end
end
