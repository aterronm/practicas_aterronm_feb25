class CreateSprints < ActiveRecord::Migration[8.0]
  def change
    create_table :sprints do |t|
      t.references :project,
                   null: false,
                   foreign_key: true,
                   index: false

      t.string   :name,       null: false, limit: 255
      t.text     :goal
      t.date     :start_date, null: false
      t.date     :end_date,   null: false

      t.integer  :status,     null: false, default: 0
      t.integer  :number,     null: false

      t.timestamps
    end

    # Índices para integridad y rendimiento
    add_index :sprints,
              [:project_id, :number],
              unique: true,
              name: 'index_sprints_on_project_and_number'

    add_index :sprints, :status
    add_index :sprints, :start_date
    add_index :sprints, :end_date
  end
end
