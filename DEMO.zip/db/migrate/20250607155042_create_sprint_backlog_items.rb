class CreateSprintBacklogItems < ActiveRecord::Migration[8.0]
  def change
    create_table :sprint_backlog_items do |t|
      # Relaciones
      t.references :sprint,
                   null: false,
                   foreign_key: true,
                   index: true

      t.references :backlog_item,
                   null: false,
                   foreign_key: true,
                   index: true

      t.references :assignee,
                   null: true,
                   foreign_key: { to_table: :people },
                   index: true

      # Atributos propios del sprint
      t.integer :status,           null: false, default: 0
      t.integer :planned_points,   null: false, default: 0
      t.integer :completed_points, null: false, default: 0
      t.integer :sort_order,       null: false, default: 0
      t.text    :notes

      t.timestamps
    end

    # Índices adicionales
    add_index :sprint_backlog_items,
              [:sprint_id, :sort_order],
              name: 'index_sprint_items_on_sprint_and_sort'
    add_index :sprint_backlog_items, :status
  end
end
