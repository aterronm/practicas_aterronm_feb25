class CreateRisks < ActiveRecord::Migration[7.0]
  def change
    create_table :risks do |t|
      # Relaciones
      t.references :project,
                   null: false,
                   foreign_key: true,
                   index: true

      t.references :owner,
                   null: true,
                   foreign_key: { to_table: :people },
                   index: true

      # Atributos principales
      t.string   :title,            null: false, limit: 255
      t.text     :description,      null: false
      t.integer  :category,         null: false, default: 0
      t.integer  :probability,      null: false, default: 1
      t.integer  :impact,           null: false, default: 1
      t.integer  :status,           null: false, default: 0

      # Plan de mitigación y fechas
      t.text     :mitigation_plan
      t.datetime :identified_at,    null: false, default: -> { 'CURRENT_TIMESTAMP' }
      t.datetime :mitigated_at

      t.timestamps
    end

    # Índices para consultas frecuentes y filtrados
    add_index :risks, [:project_id, :status],
              name: 'index_risks_on_project_and_status'
    add_index :risks, :category
    add_index :risks, :probability
    add_index :risks, :impact
    add_index :risks, :identified_at

    # Índice compuesto para búsquedas de alto riesgo
    add_index :risks,
              [:project_id, :probability, :impact],
              name: 'index_risks_on_project_prob_and_impact'
  end
end
