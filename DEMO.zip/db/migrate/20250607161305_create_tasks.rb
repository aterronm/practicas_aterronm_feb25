# db/migrate/20250608_create_tasks.rb
class CreateTasks < ActiveRecord::Migration[8.0]
  def change
    create_table :tasks do |t|
      # Ahora referenciamos también al proyecto
      t.references :project,
                   null: false,
                   foreign_key: { to_table: :projects, on_delete: :cascade },
                   index: true


      # Persona asignada
      t.references :assignee,
                   null: true,
                   foreign_key: { to_table: :people },
                   index: true

      t.string   :title,           null: false, limit: 255
      t.text     :description
      t.integer  :status,          null: false, default: 0
      t.integer  :work_type,       null: false, default: 0

      t.decimal  :estimated_hours, null: false, precision: 5, scale: 2, default: 0.0

      t.datetime :started_at
      t.datetime :completed_at

      t.text     :notes

      t.timestamps
    end

    add_index :tasks,
              [:project_id, :status],
              name: 'index_tasks_on_project_and_status'
    add_index :tasks, :work_type
  end
end
