class CreateImpediments < ActiveRecord::Migration[8.0]
  def change
    create_table :impediments do |t|
      # Relaciones
      t.references :project,
                   null: false,
                   foreign_key: true,
                   index: true

      t.references :sprint,
                   null: true,
                   foreign_key: true,
                   index: true

      t.references :reported_by,
                   null: false,
                   foreign_key: { to_table: :people },
                   index: true

      t.references :resolved_by,
                   null: true,
                   foreign_key: { to_table: :people },
                   index: true

      # Atributos del impedimento
      t.string   :title,            null: false, limit: 255
      t.text     :description,      null: false
      t.integer  :status,           null: false, default: 0
      t.integer  :severity,         null: false, default: 1

      # Plan de resolución y marcas de tiempo
      t.text     :resolution_notes
      t.datetime :reported_at,      null: false, default: -> { "CURRENT_TIMESTAMP" }
      t.datetime :resolved_at

      t.timestamps
    end

    # Índices para rendimiento en consultas frecuentes
    add_index :impediments, [:project_id, :status],
              name: 'index_imp_on_project_and_status'
    add_index :impediments, :severity
    add_index :impediments, :reported_at
    add_index :impediments, :resolved_at

    # Índice compuesto para filtrar altos niveles de severidad
    add_index :impediments,
              [:project_id, :severity, :status],
              name: 'index_imp_on_project_severity_and_status'
  end
end

