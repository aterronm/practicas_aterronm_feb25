class RemoveBacklogAndSprintFromTasks < ActiveRecord::Migration[8.0]
  def change
    # elimina las foreign keys e índices
    remove_reference :tasks, :backlog_item,      foreign_key: true, index: true
    remove_reference :tasks, :sprint_backlog_item, foreign_key: { to_table: :sprint_backlog_items }, index: true
  end
end
