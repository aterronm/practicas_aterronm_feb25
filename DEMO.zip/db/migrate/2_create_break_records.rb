class CreateBreakRecords < ActiveRecord::Migration[6.1]
  def change
    create_table :break_records do |t|
      t.references :person,       null: false, foreign_key: true
      t.references :position,                   foreign_key: true
      t.references :punch_record,               foreign_key: true
      t.datetime   :start_time,    null: false
      t.datetime   :end_time,      null: false
      t.integer    :break_type,    null: false, default: 0
      t.text       :notes

      t.timestamps
    end

    add_index :break_records, :break_type
    add_index :break_records, :start_time
    add_index :break_records, :end_time
  end
end