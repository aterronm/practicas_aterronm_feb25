class CreateDailyAttendances < ActiveRecord::Migration[6.1]
  def change
    create_table :daily_attendances do |t|
      t.references :person,               null: false, foreign_key: true
      t.date       :date,                 null: false
      t.decimal    :scheduled_hours,      precision: 5, scale: 2, default: 0.0, null: false
      t.decimal    :worked_hours,         precision: 5, scale: 2, default: 0.0, null: false
      t.integer    :tardiness_minutes,    default: 0, null: false
      t.integer    :early_leave_minutes,  default: 0, null: false
      t.decimal    :overtime_hours,       precision: 5, scale: 2, default: 0.0, null: false
      t.integer    :incidents_count,      default: 0, null: false
      t.text       :notes

      t.timestamps
    end

    add_index :daily_attendances, [:person_id, :date], unique: true
    add_index :daily_attendances, :date
  end
end