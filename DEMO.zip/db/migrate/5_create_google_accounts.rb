class CreateGoogleAccounts < ActiveRecord::Migration[6.1]
  def change
    create_table :google_accounts do |t|
      t.references :user,      null: false, foreign_key: true
      t.string     :google_uid, null: false, limit: 100
      t.string     :email,      null: false, limit: 255
      t.string     :name,                   limit: 100
      t.string     :avatar_url,             limit: 500
      t.json       :raw_info,   null: false, default: {}
      t.datetime   :last_login_at

      t.timestamps
    end

    add_index :google_accounts, :google_uid, unique: true
    add_index :google_accounts, :email
  end
end