class CreateHolidayCalendars < ActiveRecord::Migration[6.1]
  def change
    create_table :holiday_calendars do |t|
      t.references :country,     null: false, foreign_key: true
      t.date       :date,        null: false
      t.integer    :holiday_type,null: false, default: 0
      t.string     :name,        null: false, limit: 100
      t.text       :description

      t.timestamps
    end

    add_index :holiday_calendars, [:country_id, :date], unique: true
    add_index :holiday_calendars, :holiday_type
    add_index :holiday_calendars, :date
  end
end