class CreateLeaveRequests < ActiveRecord::Migration[6.1]
  def change
    create_table :leave_requests do |t|
      t.references :person,       null: false, foreign_key: true
      t.references :absence_type, null: false, foreign_key: true
      t.date       :start_date,   null: false
      t.date       :end_date,     null: false
      t.integer    :status,       null: false, default: 0
      t.text       :reason
      t.datetime   :requested_at, null: false, default: -> { 'CURRENT_TIMESTAMP' }
      t.datetime   :reviewed_at
      t.references :approver,     foreign_key: { to_table: :users }
      t.text       :manager_comments

      t.timestamps
    end

    add_index :leave_requests, :status
    add_index :leave_requests, [:person_id, :start_date, :end_date], name: 'index_leave_requests_on_person_and_dates'
  end
end