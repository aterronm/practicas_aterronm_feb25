class CreateOvertimeRecords < ActiveRecord::Migration[6.1]
  def change
    create_table :overtime_records do |t|
      t.references :person,        null: false, foreign_key: true
      t.references :position,                   foreign_key: true
      t.date       :date,          null: false
      t.time       :start_time,    null: false
      t.time       :end_time,      null: false
      t.decimal    :hours,         precision: 5, scale: 2, null: false
      t.decimal    :rate_multiplier, precision: 4, scale: 2, default: 1.0, null: false
      t.integer    :status,        null: false, default: 0
      t.text       :reason
      t.datetime   :requested_at,  null: false, default: -> { 'CURRENT_TIMESTAMP' }
      t.datetime   :reviewed_at
      t.references :approved_by,    foreign_key: { to_table: :users }

      t.timestamps
    end

    add_index :overtime_records, :status
    add_index :overtime_records, :date
    add_index :overtime_records, :requested_at
  end
end