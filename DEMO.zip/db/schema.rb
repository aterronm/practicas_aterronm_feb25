# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.0].define(version: 2025_06_08_035442) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "pg_catalog.plpgsql"

  create_table "absence_records", force: :cascade do |t|
    t.bigint "person_id", null: false
    t.bigint "absence_type_id", null: false
    t.bigint "approver_id"
    t.string "source_type"
    t.bigint "source_id"
    t.date "start_date", null: false
    t.date "end_date", null: false
    t.integer "days_count", default: 0, null: false
    t.text "notes"
    t.string "status", default: "pending", null: false
    t.datetime "approved_at", precision: nil
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["absence_type_id"], name: "index_absence_records_on_absence_type_id"
    t.index ["approver_id"], name: "index_absence_records_on_approver_id"
    t.index ["person_id", "start_date", "end_date"], name: "index_absences_on_person_and_dates"
    t.index ["person_id"], name: "index_absence_records_on_person_id"
    t.index ["source_type", "source_id"], name: "index_absence_records_on_source"
    t.check_constraint "end_date >= start_date", name: "ck_absences_end_after_start"
  end

  create_table "absence_types", force: :cascade do |t|
    t.string "code", limit: 10, null: false
    t.string "name", limit: 100, null: false
    t.text "description"
    t.integer "category", default: 0, null: false
    t.boolean "paid", default: true, null: false
    t.boolean "requires_approval", default: true, null: false
    t.integer "annual_limit_days", default: 0, null: false
    t.boolean "carryover_allowed", default: false, null: false
    t.integer "max_carryover_days", default: 0, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["code"], name: "index_absence_types_on_code", unique: true
    t.check_constraint "annual_limit_days >= 0", name: "ck_absence_types_annual_limit_non_negative"
    t.check_constraint "max_carryover_days >= 0", name: "ck_absence_types_max_carryover_non_negative"
  end

  create_table "active_storage_attachments", force: :cascade do |t|
    t.string "name", null: false
    t.string "record_type", null: false
    t.bigint "record_id", null: false
    t.bigint "blob_id", null: false
    t.datetime "created_at", null: false
    t.index ["blob_id"], name: "index_active_storage_attachments_on_blob_id"
    t.index ["record_type", "record_id", "name", "blob_id"], name: "index_active_storage_attachments_uniqueness", unique: true
  end

  create_table "active_storage_blobs", force: :cascade do |t|
    t.string "key", null: false
    t.string "filename", null: false
    t.string "content_type"
    t.text "metadata"
    t.string "service_name", null: false
    t.bigint "byte_size", null: false
    t.string "checksum"
    t.datetime "created_at", null: false
    t.index ["key"], name: "index_active_storage_blobs_on_key", unique: true
  end

  create_table "active_storage_variant_records", force: :cascade do |t|
    t.bigint "blob_id", null: false
    t.string "variation_digest", null: false
    t.index ["blob_id", "variation_digest"], name: "index_active_storage_variant_records_uniqueness", unique: true
  end

  create_table "attendance_incidents", force: :cascade do |t|
    t.bigint "person_id", null: false
    t.bigint "position_id"
    t.integer "incident_type", default: 0, null: false
    t.datetime "occurred_at", precision: nil, null: false
    t.integer "status", default: 0, null: false
    t.text "description", null: false
    t.text "resolution"
    t.datetime "resolved_at", precision: nil
    t.bigint "resolved_by_id"
    t.string "ip_address"
    t.text "notes"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["incident_type"], name: "index_attendance_incidents_on_incident_type"
    t.index ["occurred_at"], name: "index_attendance_incidents_on_occurred_at"
    t.index ["person_id"], name: "index_attendance_incidents_on_person_id"
    t.index ["position_id"], name: "index_attendance_incidents_on_position_id"
    t.index ["resolved_by_id"], name: "index_attendance_incidents_on_resolved_by_id"
    t.index ["status"], name: "index_attendance_incidents_on_status"
  end

  create_table "backlog_items", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.bigint "parent_id"
    t.integer "item_type", default: 1, null: false
    t.string "title", limit: 255, null: false
    t.text "description"
    t.text "acceptance_criteria"
    t.integer "priority", default: 1, null: false
    t.integer "story_points", default: 0, null: false
    t.integer "status", default: 0, null: false
    t.text "notes"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["parent_id"], name: "index_backlog_items_on_parent_id"
    t.index ["project_id", "priority"], name: "index_bi_on_project_and_priority"
    t.index ["project_id", "status"], name: "index_bi_on_project_and_status"
    t.index ["project_id"], name: "index_backlog_items_on_project_id"
  end

  create_table "break_records", force: :cascade do |t|
    t.bigint "person_id", null: false
    t.bigint "position_id"
    t.bigint "punch_record_id"
    t.datetime "start_time", precision: nil, null: false
    t.datetime "end_time", precision: nil, null: false
    t.integer "break_type", default: 0, null: false
    t.text "notes"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["break_type"], name: "index_break_records_on_break_type"
    t.index ["end_time"], name: "index_break_records_on_end_time"
    t.index ["person_id"], name: "index_break_records_on_person_id"
    t.index ["position_id"], name: "index_break_records_on_position_id"
    t.index ["punch_record_id"], name: "index_break_records_on_punch_record_id"
    t.index ["start_time"], name: "index_break_records_on_start_time"
  end

  create_table "clients", force: :cascade do |t|
    t.integer "client_type", default: 0, null: false
    t.integer "status", default: 0, null: false
    t.string "email", limit: 255, null: false
    t.string "phone", limit: 20, null: false
    t.string "street", limit: 255, null: false
    t.string "city", limit: 100, null: false
    t.string "state", limit: 100, null: false
    t.string "postal_code", limit: 20, null: false
    t.bigint "person_id"
    t.bigint "company_id"
    t.bigint "country_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["client_type"], name: "index_clients_on_client_type"
    t.index ["company_id"], name: "index_clients_on_company_id"
    t.index ["country_id"], name: "index_clients_on_country_id"
    t.index ["email"], name: "index_clients_on_email", unique: true
    t.index ["person_id"], name: "index_clients_on_person_id"
    t.index ["status"], name: "index_clients_on_status"
  end

  create_table "companies", force: :cascade do |t|
    t.string "company_name", limit: 255, null: false
    t.integer "status", default: 0, null: false
    t.integer "legal_form", default: 0, null: false
    t.string "tax_id", limit: 20, null: false
    t.string "registration_number", limit: 100, null: false
    t.string "vat_number", limit: 20
    t.string "email", limit: 255, null: false
    t.string "phone", limit: 20
    t.string "website", limit: 255
    t.string "street", limit: 255, null: false
    t.string "city", limit: 100, null: false
    t.string "state", limit: 100, null: false
    t.string "postal_code", limit: 20, null: false
    t.string "country", limit: 2, null: false
    t.string "cnae_code", limit: 4, null: false
    t.date "founded_on", null: false
    t.decimal "share_capital", precision: 15, scale: 2, null: false
    t.integer "employees_count", default: 0, null: false
    t.date "fiscal_year_start", null: false
    t.date "fiscal_year_end", null: false
    t.string "bank_iban", limit: 34, null: false
    t.string "bank_bic", limit: 11
    t.string "bank_name", limit: 100, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["cnae_code"], name: "index_companies_on_cnae_code"
    t.index ["company_name"], name: "index_companies_on_company_name", unique: true
    t.index ["country"], name: "index_companies_on_country"
    t.index ["email"], name: "index_companies_on_email", unique: true
    t.index ["legal_form"], name: "index_companies_on_legal_form"
    t.index ["registration_number"], name: "index_companies_on_registration_number", unique: true
    t.index ["status"], name: "index_companies_on_status"
    t.index ["tax_id"], name: "index_companies_on_tax_id", unique: true
  end

  create_table "contracts", force: :cascade do |t|
    t.bigint "person_id", null: false
    t.bigint "position_id"
    t.bigint "company_id"
    t.integer "status", default: 0, null: false
    t.integer "contract_nature", default: 0, null: false
    t.string "contract_number", limit: 100, null: false
    t.date "start_date", null: false
    t.date "end_date"
    t.integer "duration_months"
    t.integer "probation_days"
    t.integer "hours_per_week", null: false
    t.decimal "salary_base", precision: 12, scale: 2, default: "0.0", null: false
    t.string "salary_currency", limit: 3, null: false
    t.decimal "bonus_percentage", precision: 5, scale: 2, default: "0.0"
    t.string "benefits", default: [], array: true
    t.string "work_location", limit: 255, null: false
    t.boolean "remote_option", default: false, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["company_id"], name: "index_contracts_on_company_id"
    t.index ["contract_nature"], name: "index_contracts_on_contract_nature"
    t.index ["contract_number"], name: "index_contracts_on_contract_number", unique: true
    t.index ["end_date"], name: "index_contracts_on_end_date"
    t.index ["person_id", "company_id"], name: "index_contracts_on_person_and_company"
    t.index ["person_id"], name: "index_contracts_on_person_id"
    t.index ["position_id"], name: "index_contracts_on_position_id"
    t.index ["start_date", "end_date"], name: "index_contracts_on_dates"
    t.index ["start_date"], name: "index_contracts_on_start_date"
    t.index ["status"], name: "index_contracts_on_status"
    t.check_constraint "bonus_percentage >= 0::numeric AND bonus_percentage <= 100::numeric", name: "check_bonus_percentage_range"
    t.check_constraint "end_date IS NULL OR end_date >= start_date", name: "check_end_after_start"
    t.check_constraint "hours_per_week >= 1 AND hours_per_week <= 168", name: "check_hours_per_week"
    t.check_constraint "salary_base >= 0::numeric", name: "check_salary_base_non_negative"
    t.check_constraint "salary_currency::text ~ '^[A-Z]{3}$'::text", name: "check_salary_currency_format"
  end

  create_table "countries", force: :cascade do |t|
    t.string "iso", limit: 2, null: false
    t.string "iso3", limit: 3
    t.integer "numcode"
    t.integer "phonecode", null: false
    t.string "name", limit: 80, null: false
    t.string "nicename", limit: 80, null: false
    t.string "currency_code", limit: 3
    t.string "timezone", limit: 50
    t.string "languages", default: [], array: true
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["currency_code"], name: "index_countries_on_currency_code"
    t.index ["iso"], name: "index_countries_on_iso", unique: true
    t.index ["languages"], name: "index_countries_on_languages", using: :gin
    t.index ["phonecode"], name: "index_countries_on_phonecode"
  end

  create_table "daily_attendances", force: :cascade do |t|
    t.bigint "person_id", null: false
    t.date "date", null: false
    t.decimal "scheduled_hours", precision: 5, scale: 2, default: "0.0", null: false
    t.decimal "worked_hours", precision: 5, scale: 2, default: "0.0", null: false
    t.integer "tardiness_minutes", default: 0, null: false
    t.integer "early_leave_minutes", default: 0, null: false
    t.decimal "overtime_hours", precision: 5, scale: 2, default: "0.0", null: false
    t.integer "incidents_count", default: 0, null: false
    t.text "notes"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["date"], name: "index_daily_attendances_on_date"
    t.index ["person_id", "date"], name: "index_daily_attendances_on_person_id_and_date", unique: true
    t.index ["person_id"], name: "index_daily_attendances_on_person_id"
  end

  create_table "departments", force: :cascade do |t|
    t.string "name", limit: 100, null: false
    t.string "code", limit: 10, null: false
    t.text "description"
    t.bigint "parent_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["code"], name: "index_departments_on_code", unique: true
    t.index ["name"], name: "index_departments_on_name", unique: true
    t.index ["parent_id"], name: "index_departments_on_parent_id"
  end

  create_table "google_accounts", force: :cascade do |t|
    t.bigint "user_id", null: false
    t.string "google_uid", limit: 100, null: false
    t.string "email", limit: 255, null: false
    t.string "name", limit: 100
    t.string "avatar_url", limit: 500
    t.json "raw_info", default: {}, null: false
    t.datetime "last_login_at", precision: nil
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["email"], name: "index_google_accounts_on_email"
    t.index ["google_uid"], name: "index_google_accounts_on_google_uid", unique: true
    t.index ["user_id"], name: "index_google_accounts_on_user_id"
  end

  create_table "holiday_calendars", force: :cascade do |t|
    t.bigint "country_id", null: false
    t.date "date", null: false
    t.integer "holiday_type", default: 0, null: false
    t.string "name", limit: 100, null: false
    t.text "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["country_id", "date"], name: "index_holiday_calendars_on_country_id_and_date", unique: true
    t.index ["country_id"], name: "index_holiday_calendars_on_country_id"
    t.index ["date"], name: "index_holiday_calendars_on_date"
    t.index ["holiday_type"], name: "index_holiday_calendars_on_holiday_type"
  end

  create_table "impediments", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.bigint "sprint_id"
    t.bigint "reported_by_id", null: false
    t.bigint "resolved_by_id"
    t.string "title", limit: 255, null: false
    t.text "description", null: false
    t.integer "status", default: 0, null: false
    t.integer "severity", default: 1, null: false
    t.text "resolution_notes"
    t.datetime "reported_at", default: -> { "CURRENT_TIMESTAMP" }, null: false
    t.datetime "resolved_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["project_id", "severity", "status"], name: "index_imp_on_project_severity_and_status"
    t.index ["project_id", "status"], name: "index_imp_on_project_and_status"
    t.index ["project_id"], name: "index_impediments_on_project_id"
    t.index ["reported_at"], name: "index_impediments_on_reported_at"
    t.index ["reported_by_id"], name: "index_impediments_on_reported_by_id"
    t.index ["resolved_at"], name: "index_impediments_on_resolved_at"
    t.index ["resolved_by_id"], name: "index_impediments_on_resolved_by_id"
    t.index ["severity"], name: "index_impediments_on_severity"
    t.index ["sprint_id"], name: "index_impediments_on_sprint_id"
  end

  create_table "leave_requests", force: :cascade do |t|
    t.bigint "person_id", null: false
    t.bigint "absence_type_id", null: false
    t.date "start_date", null: false
    t.date "end_date", null: false
    t.integer "status", default: 0, null: false
    t.text "reason"
    t.datetime "requested_at", precision: nil, default: -> { "CURRENT_TIMESTAMP" }, null: false
    t.datetime "reviewed_at", precision: nil
    t.bigint "approver_id"
    t.text "manager_comments"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["absence_type_id"], name: "index_leave_requests_on_absence_type_id"
    t.index ["approver_id"], name: "index_leave_requests_on_approver_id"
    t.index ["person_id", "start_date", "end_date"], name: "index_leave_requests_on_person_and_dates"
    t.index ["person_id"], name: "index_leave_requests_on_person_id"
    t.index ["status"], name: "index_leave_requests_on_status"
  end

  create_table "overtime_records", force: :cascade do |t|
    t.bigint "person_id", null: false
    t.bigint "position_id"
    t.date "date", null: false
    t.time "start_time", null: false
    t.time "end_time", null: false
    t.decimal "hours", precision: 5, scale: 2, null: false
    t.decimal "rate_multiplier", precision: 4, scale: 2, default: "1.0", null: false
    t.integer "status", default: 0, null: false
    t.text "reason"
    t.datetime "requested_at", precision: nil, default: -> { "CURRENT_TIMESTAMP" }, null: false
    t.datetime "reviewed_at", precision: nil
    t.bigint "approved_by_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["approved_by_id"], name: "index_overtime_records_on_approved_by_id"
    t.index ["date"], name: "index_overtime_records_on_date"
    t.index ["person_id"], name: "index_overtime_records_on_person_id"
    t.index ["position_id"], name: "index_overtime_records_on_position_id"
    t.index ["requested_at"], name: "index_overtime_records_on_requested_at"
    t.index ["status"], name: "index_overtime_records_on_status"
  end

  create_table "people", force: :cascade do |t|
    t.bigint "country_id", null: false
    t.bigint "tax_residency_country_id", null: false
    t.bigint "nationality_country_id", null: false
    t.string "first_name", limit: 100, null: false
    t.string "last_name", limit: 100, null: false
    t.integer "gender", default: 3, null: false
    t.integer "preferred_contact_method", default: 0, null: false
    t.string "identification_type", null: false
    t.string "identification_number", limit: 20, null: false
    t.string "social_security_number", limit: 15, null: false
    t.string "tax_identification_number", limit: 20, null: false
    t.date "date_of_birth", null: false
    t.string "email", limit: 255, null: false
    t.string "phone", limit: 15, null: false
    t.string "mobile_phone", limit: 15
    t.string "secondary_phone", limit: 15
    t.string "street", limit: 255, null: false
    t.string "city", limit: 255, null: false
    t.string "state", limit: 100, null: false
    t.string "postal_code", limit: 20, null: false
    t.string "bank_iban", limit: 34, null: false
    t.string "bank_bic", limit: 11
    t.string "bank_name", limit: 100, null: false
    t.datetime "terms_accepted_at", precision: nil, null: false
    t.datetime "privacy_policy_accepted_at", precision: nil, null: false
    t.datetime "gdpr_consent_at", precision: nil, null: false
    t.boolean "data_sharing_consent", default: false, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["bank_iban"], name: "index_people_on_bank_iban", unique: true
    t.index ["country_id"], name: "index_people_on_country_id"
    t.index ["email"], name: "index_people_on_email", unique: true
    t.index ["identification_number"], name: "index_people_on_identification_number", unique: true
    t.index ["nationality_country_id"], name: "index_people_on_nationality_country_id"
    t.index ["social_security_number"], name: "index_people_on_social_security_number", unique: true
    t.index ["tax_identification_number"], name: "index_people_on_tax_identification_number", unique: true
    t.index ["tax_residency_country_id"], name: "index_people_on_tax_residency_country_id"
  end

  create_table "positions", force: :cascade do |t|
    t.bigint "person_id", null: false
    t.bigint "company_id"
    t.bigint "supervisor_id"
    t.string "job_code", limit: 50, null: false
    t.string "title", limit: 200, null: false
    t.text "description"
    t.string "department_id", limit: 100, null: false
    t.string "job_level", limit: 50, null: false
    t.integer "contract_type", default: 0, null: false
    t.integer "status", default: 0, null: false
    t.integer "shift_type", default: 0, null: false
    t.decimal "salary_min", precision: 12, scale: 2
    t.decimal "salary_max", precision: 12, scale: 2
    t.integer "probation_period_days"
    t.text "benefits"
    t.integer "hours_per_week", null: false
    t.date "start_date", null: false
    t.date "end_date"
    t.integer "notice_period_days"
    t.string "cost_center_code", limit: 50
    t.string "project_code", limit: 50
    t.text "termination_reason"
    t.date "termination_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "manager"
    t.index ["company_id"], name: "index_positions_on_company_id"
    t.index ["contract_type"], name: "index_positions_on_contract_type"
    t.index ["department_id"], name: "index_positions_on_department"
    t.index ["job_code"], name: "index_positions_on_job_code", unique: true
    t.index ["job_level"], name: "index_positions_on_job_level"
    t.index ["person_id"], name: "index_positions_on_person_id"
    t.index ["status"], name: "index_positions_on_status"
    t.index ["supervisor_id"], name: "index_positions_on_supervisor_id"
  end

  create_table "project_memberships", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.bigint "person_id", null: false
    t.integer "role", default: 2, null: false
    t.date "start_date", null: false
    t.date "end_date"
    t.decimal "allocated_hours", precision: 8, scale: 2, default: "0.0", null: false
    t.decimal "actual_hours", precision: 8, scale: 2, default: "0.0", null: false
    t.decimal "hourly_rate", precision: 10, scale: 2
    t.text "responsibilities"
    t.text "notes"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["end_date"], name: "index_project_memberships_on_end_date"
    t.index ["person_id"], name: "index_project_memberships_on_person_id"
    t.index ["project_id", "person_id", "role", "start_date", "end_date"], name: "index_pm_on_proj_person_role_dates"
    t.index ["project_id"], name: "index_project_memberships_on_project_id"
  end

  create_table "projects", force: :cascade do |t|
    t.bigint "client_id", null: false
    t.string "code", limit: 50, null: false
    t.string "name", limit: 255, null: false
    t.text "description"
    t.date "start_date"
    t.date "end_date_estimated"
    t.date "end_date_actual"
    t.integer "status", default: 0, null: false
    t.integer "project_type", default: 1, null: false
    t.integer "priority", default: 1, null: false
    t.decimal "budget", precision: 15, scale: 2
    t.string "currency", limit: 3
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["client_id", "code"], name: "index_projects_on_client_id_and_code", unique: true
    t.index ["end_date_estimated"], name: "index_projects_on_end_date_estimated"
    t.index ["status"], name: "index_projects_on_status"
  end

  create_table "punch_records", force: :cascade do |t|
    t.bigint "person_id", null: false
    t.bigint "position_id"
    t.datetime "occurred_at", precision: nil, null: false
    t.integer "event_type", default: 0, null: false
    t.string "ip_address"
    t.decimal "latitude", precision: 10, scale: 6
    t.decimal "longitude", precision: 10, scale: 6
    t.text "notes"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["event_type"], name: "index_punch_records_on_event_type"
    t.index ["occurred_at"], name: "index_punch_records_on_occurred_at"
    t.index ["person_id"], name: "index_punch_records_on_person_id"
    t.index ["position_id"], name: "index_punch_records_on_position_id"
  end

  create_table "risks", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.bigint "owner_id"
    t.string "title", limit: 255, null: false
    t.text "description", null: false
    t.integer "category", default: 0, null: false
    t.integer "probability", default: 1, null: false
    t.integer "impact", default: 1, null: false
    t.integer "status", default: 0, null: false
    t.text "mitigation_plan"
    t.datetime "identified_at", default: -> { "CURRENT_TIMESTAMP" }, null: false
    t.datetime "mitigated_at"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["category"], name: "index_risks_on_category"
    t.index ["identified_at"], name: "index_risks_on_identified_at"
    t.index ["impact"], name: "index_risks_on_impact"
    t.index ["owner_id"], name: "index_risks_on_owner_id"
    t.index ["probability"], name: "index_risks_on_probability"
    t.index ["project_id", "probability", "impact"], name: "index_risks_on_project_prob_and_impact"
    t.index ["project_id", "status"], name: "index_risks_on_project_and_status"
    t.index ["project_id"], name: "index_risks_on_project_id"
  end

  create_table "roles", force: :cascade do |t|
    t.string "code", limit: 50, null: false
    t.string "name", limit: 100, null: false
    t.text "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["code"], name: "index_roles_on_code", unique: true
    t.index ["name"], name: "index_roles_on_name", unique: true
  end

  create_table "schedule_assignments", force: :cascade do |t|
    t.bigint "work_schedule_id", null: false
    t.string "assignable_type", null: false
    t.bigint "assignable_id", null: false
    t.date "start_date", null: false
    t.date "end_date"
    t.integer "status", default: 1, null: false
    t.text "notes"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["assignable_type", "assignable_id", "end_date"], name: "index_schedule_assign_on_assignable_and_end"
    t.index ["assignable_type", "assignable_id", "start_date"], name: "index_schedule_assign_on_assignable_and_start"
    t.index ["assignable_type", "assignable_id"], name: "index_schedule_assign_on_assignable"
    t.index ["status"], name: "index_schedule_assignments_on_status"
    t.index ["work_schedule_id"], name: "index_schedule_assignments_on_work_schedule_id"
  end

  create_table "sprint_backlog_items", force: :cascade do |t|
    t.bigint "sprint_id", null: false
    t.bigint "backlog_item_id", null: false
    t.bigint "assignee_id"
    t.integer "status", default: 0, null: false
    t.integer "planned_points", default: 0, null: false
    t.integer "completed_points", default: 0, null: false
    t.integer "sort_order", default: 0, null: false
    t.text "notes"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["assignee_id"], name: "index_sprint_backlog_items_on_assignee_id"
    t.index ["backlog_item_id"], name: "index_sprint_backlog_items_on_backlog_item_id"
    t.index ["sprint_id", "sort_order"], name: "index_sprint_items_on_sprint_and_sort"
    t.index ["sprint_id"], name: "index_sprint_backlog_items_on_sprint_id"
    t.index ["status"], name: "index_sprint_backlog_items_on_status"
  end

  create_table "sprints", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.string "name", limit: 255, null: false
    t.text "goal"
    t.date "start_date", null: false
    t.date "end_date", null: false
    t.integer "status", default: 0, null: false
    t.integer "number", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["end_date"], name: "index_sprints_on_end_date"
    t.index ["project_id", "number"], name: "index_sprints_on_project_and_number", unique: true
    t.index ["start_date"], name: "index_sprints_on_start_date"
    t.index ["status"], name: "index_sprints_on_status"
  end

  create_table "tasks", force: :cascade do |t|
    t.bigint "assignee_id"
    t.string "title", limit: 255, null: false
    t.text "description"
    t.integer "status", default: 0, null: false
    t.integer "work_type", default: 0, null: false
    t.decimal "estimated_hours", precision: 5, scale: 2, default: "0.0", null: false
    t.decimal "logged_hours", precision: 5, scale: 2, default: "0.0", null: false
    t.datetime "started_at"
    t.datetime "completed_at"
    t.text "notes"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "project_id", null: false
    t.index ["assignee_id"], name: "index_tasks_on_assignee_id"
    t.index ["project_id"], name: "index_tasks_on_project_id"
    t.index ["work_type"], name: "index_tasks_on_work_type"
  end

  create_table "users", force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at", precision: nil
    t.datetime "remember_created_at", precision: nil
    t.integer "sign_in_count", default: 0, null: false
    t.datetime "current_sign_in_at", precision: nil
    t.datetime "last_sign_in_at", precision: nil
    t.string "current_sign_in_ip"
    t.string "last_sign_in_ip"
    t.bigint "person_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "provider"
    t.string "uid"
    t.bigint "role_id"
    t.index ["email"], name: "index_users_on_email", unique: true
    t.index ["person_id"], name: "index_users_on_person_id"
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
    t.index ["role_id"], name: "index_users_on_role_id"
  end

  create_table "work_schedules", force: :cascade do |t|
    t.string "name", limit: 100, null: false
    t.text "description"
    t.integer "schedule_type", default: 0, null: false
    t.time "start_time", null: false
    t.time "end_time", null: false
    t.time "break_start_time"
    t.time "break_end_time"
    t.string "days_of_week", default: [], array: true
    t.boolean "active", default: true, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["active"], name: "index_work_schedules_on_active"
    t.index ["days_of_week"], name: "index_work_schedules_on_days_of_week", using: :gin
    t.index ["name"], name: "index_work_schedules_on_name", unique: true
    t.index ["schedule_type"], name: "index_work_schedules_on_schedule_type"
  end

  add_foreign_key "absence_records", "absence_types"
  add_foreign_key "absence_records", "people"
  add_foreign_key "absence_records", "users", column: "approver_id"
  add_foreign_key "active_storage_attachments", "active_storage_blobs", column: "blob_id"
  add_foreign_key "active_storage_variant_records", "active_storage_blobs", column: "blob_id"
  add_foreign_key "attendance_incidents", "people"
  add_foreign_key "attendance_incidents", "positions"
  add_foreign_key "attendance_incidents", "users", column: "resolved_by_id"
  add_foreign_key "backlog_items", "backlog_items", column: "parent_id"
  add_foreign_key "backlog_items", "projects"
  add_foreign_key "break_records", "people"
  add_foreign_key "break_records", "positions"
  add_foreign_key "break_records", "punch_records"
  add_foreign_key "clients", "companies"
  add_foreign_key "clients", "countries"
  add_foreign_key "clients", "people"
  add_foreign_key "contracts", "companies"
  add_foreign_key "contracts", "people"
  add_foreign_key "contracts", "positions"
  add_foreign_key "daily_attendances", "people"
  add_foreign_key "departments", "departments", column: "parent_id"
  add_foreign_key "google_accounts", "users"
  add_foreign_key "holiday_calendars", "countries"
  add_foreign_key "impediments", "people", column: "reported_by_id"
  add_foreign_key "impediments", "people", column: "resolved_by_id"
  add_foreign_key "impediments", "projects"
  add_foreign_key "impediments", "sprints"
  add_foreign_key "leave_requests", "absence_types"
  add_foreign_key "leave_requests", "people"
  add_foreign_key "leave_requests", "users", column: "approver_id"
  add_foreign_key "overtime_records", "people"
  add_foreign_key "overtime_records", "positions"
  add_foreign_key "overtime_records", "users", column: "approved_by_id"
  add_foreign_key "people", "countries"
  add_foreign_key "people", "countries", column: "nationality_country_id"
  add_foreign_key "people", "countries", column: "tax_residency_country_id"
  add_foreign_key "positions", "companies"
  add_foreign_key "positions", "people"
  add_foreign_key "positions", "positions", column: "supervisor_id"
  add_foreign_key "project_memberships", "people"
  add_foreign_key "project_memberships", "projects"
  add_foreign_key "projects", "clients"
  add_foreign_key "punch_records", "people"
  add_foreign_key "punch_records", "positions"
  add_foreign_key "risks", "people", column: "owner_id"
  add_foreign_key "risks", "projects"
  add_foreign_key "schedule_assignments", "work_schedules"
  add_foreign_key "sprint_backlog_items", "backlog_items"
  add_foreign_key "sprint_backlog_items", "people", column: "assignee_id"
  add_foreign_key "sprint_backlog_items", "sprints"
  add_foreign_key "sprints", "projects"
  add_foreign_key "tasks", "people", column: "assignee_id"
  add_foreign_key "tasks", "projects"
  add_foreign_key "users", "people"
  add_foreign_key "users", "roles"
end
