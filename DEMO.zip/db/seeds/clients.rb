# db/seeds/04_clients.rb

require 'faker'

# ------------------------------------------------------------
# 1) Limpiar datos previos
# ------------------------------------------------------------
# Core::Client.delete_all

# ------------------------------------------------------------
# 2) Preparar conjuntos de personas y empresas existentes
# ------------------------------------------------------------
persons   = Hr::Person.all.to_a.shuffle
companies = Core::Company.all.to_a.shuffle

# ------------------------------------------------------------
# 3) Crear clientes “individuales” vinculados a Hr::Person
# ------------------------------------------------------------
# Tomaremos, por ejemplo, 30 personas al azar (o tantas como haya, si menos de 30)
num_individuals = [30, persons.size].min
selected_persons = persons.first(num_individuals)

selected_persons.each do |person|
  Core::Client.create!(
    client_type: :individual,
    status:      Core::Client.statuses.keys.sample,
    person:      person,

    # Datos de cliente (independientes de la persona)
    email:       Faker::Internet.unique.email,
    phone:       "+#{Faker::Number.number(digits: 9)}",
    street:      Faker::Address.street_address,
    city:        Faker::Address.city,
    state:       Faker::Address.state_abbr,
    postal_code: Faker::Address.postcode,
    country:     Core::Country.all.sample
  )
end

puts "✅ Se han creado #{num_individuals} clientes de tipo individual."

# ------------------------------------------------------------
# 4) Crear clientes “empresa” vinculados a Company
# ------------------------------------------------------------
# Tomamos, por ejemplo, 15 empresas al azar (o tantas como haya, si menos de 15)
num_companies = [15, companies.size].min
selected_companies = companies.first(num_companies)

selected_companies.each do |company|
  Core::Client.create!(
    client_type: :company,
    status:      Core::Client.statuses.keys.sample,
    company:     company,

    # Datos de cliente (independientes de la empresa)
    email:       Faker::Internet.unique.email(domain: "#{company.company_name.parameterize}.com"),
    phone:       "+#{Faker::Number.number(digits: 9)}",
    street:      Faker::Address.street_address,
    city:        Faker::Address.city,
    state:       Faker::Address.state_abbr,
    postal_code: Faker::Address.postcode,
    country:     Core::Country.all.sample
  )
end

puts "✅ Se han creado #{num_companies} clientes de tipo company."

# ------------------------------------------------------------
# 5) Regenerar índice de Faker para que no haya colisiones en futuros seeds
# ------------------------------------------------------------
Faker::Internet.unique.clear
