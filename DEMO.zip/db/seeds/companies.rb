# db/seeds/03_companies.rb

require 'faker'

# ------------------------------------------------------------
# 1) Limpiar datos previos
# ------------------------------------------------------------
#Company.delete_all

# ------------------------------------------------------------
# 2) Crear 20 compañías ficticias
# ------------------------------------------------------------
40.times do
  # ------------------------------------------------------------
  # 2.1) Seleccionar país (Core::Country.iso está en ISO3, tomamos los 2 primeros caracteres para ISO2)
  # ------------------------------------------------------------
  country_record = Core::Country.all.sample
  iso2 = country_record.iso[0..1].upcase

  # ------------------------------------------------------------
  # 2.2) Generar tax_id (CIF/NIF): [Letra|Ñ|&] + 7 dígitos + [Letra o dígito]
  # ------------------------------------------------------------
  letters_initial = ('A'..'Z').to_a + ['Ñ', '&']
  first_letter   = letters_initial.sample
  digits7        = Faker::Number.number(digits: 7).to_s
  final_char     = (('A'..'Z').to_a + ('0'..'9').to_a).sample
  tax_id         = "#{first_letter}#{digits7}#{final_char}"

  # ------------------------------------------------------------
  # 2.3) Generar VAT intracomunitario (opcional)
  #    Formato: "E" + 8–12 caracteres alfanuméricos
  # ------------------------------------------------------------
  vat_number = if [true, false].sample
    length = rand(8..12)
    "E" + Array.new(length) { (('A'..'Z').to_a + ('0'..'9').to_a).sample }.join
  else
    ""
  end

  # ------------------------------------------------------------
  # 2.4) Generar otros campos
  # ------------------------------------------------------------
  company_name        = Faker::Company.unique.name
  registration_number = Faker::Alphanumeric.unique.alphanumeric(number: 10).upcase
  cnae_code           = Faker::Number.number(digits: 4).to_s

  # Fechas de ejercicio: el inicio como fecha al azar entre 2000 y hace 1 año,
  # el fin al menos 30 días después y antes de hoy.
  start_date = Faker::Date.between(from: '2000-01-01', to: Date.today - 365)
  end_date   = start_date + rand(30..365).days

  share_capital    = rand(10_000..1_000_000)   # en euros
  employees_count  = rand(1..1_000)

  bank_iban = "#{iso2}#{Array.new(22) { rand(0..9) }.join}"
  bank_bic  = Faker::Bank.swift_bic
  bank_name = Faker::Bank.name

  email   = Faker::Internet.unique.email(domain: "#{company_name.parameterize}.com")
  phone   = "+#{Faker::Number.number(digits: 9)}"
  website = Faker::Internet.url(host: "#{company_name.parameterize}.com")

  street      = Faker::Address.street_address
  city        = Faker::Address.city
  state       = Faker::Address.state_abbr
  postal_code = Faker::Address.postcode

  # ------------------------------------------------------------
  # 2.5) Crear el registro en la tabla companies
  # ------------------------------------------------------------
  Core::Company.create!(
    company_name:        company_name,
    status:              Core::Company.statuses.keys.sample,
    legal_form:          Core::Company.legal_forms.keys.sample,

    tax_id:              tax_id,
    registration_number: registration_number,
    vat_number:          vat_number,

    email:               email,
    phone:               phone,
    website:             website,

    street:      street,
    city:        city,
    state:       state,
    postal_code: postal_code,
    country:     iso2,

    cnae_code:           cnae_code,
    founded_on:          start_date,
    share_capital:       share_capital,
    employees_count:     employees_count,
    fiscal_year_start:   start_date,
    fiscal_year_end:     end_date,

    bank_iban: bank_iban,
    bank_bic:  bank_bic,
    bank_name: bank_name
  )
end

puts "✅ Se han creado 40 compañías en Company."
