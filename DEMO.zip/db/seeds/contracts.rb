# db/seeds/contracts.rb

require 'faker'
require 'securerandom'

puts "Seeding Contracts..."

# Fetch all people, companies, and positions
people    = Hr::Person.all.to_a
companies = Core::Company.all.to_a
positions = Hr::Position.all.to_a

if people.empty?
  puts "⚠️  No Hr::Person records found. Skipping Contract seeding."
  exit
end

# Sample benefits pool
BENEFIT_OPTIONS = [
  "Private health insurance",
  "Meal vouchers",
  "Company car",
  "Gym membership",
  "Training stipend",
  "Flexible hours",
  "Stock options",
  "Childcare support",
  "Mobile phone allowance",
  "Home office reimbursement"
]

# Currencies to choose from
CURRENCIES = %w[EUR USD GBP]

people.each do |person|
  # Pick a random company (or none)
  company = companies.sample

  # Pick one of the person's positions (if any), else leave nil
  person_positions = positions.select { |pos| pos.person_id == person.id }
  position = person_positions.sample

  # Determine contract nature
  nature = Hr::Contract.contract_natures.keys.sample

  # Set start date between 1 and 18 months ago
  start_date = Faker::Date.between(from: 18.months.ago.to_date, to: 1.month.ago.to_date)

  # Duration in months and end date logic
  duration_months = case nature
  when "permanent"
    nil
  when "temporary"
    rand(6..12)
  when "training"
    rand(3..6)
  when "part_time"
    rand(6..18)
  when "freelance"
    rand(3..9)
  else
    nil
  end

  end_date =
    if duration_months
      start_date + duration_months.months
    else
      nil
    end

  # Probation days: 30–90 for permanent/temporary/training, nil otherwise
  probation_days =
    case nature
    when "permanent", "temporary", "training"
      [30, 60, 90].sample
    else
      nil
    end

  # Hours per week: full-time ~40, part-time ~20–30, freelance ~10–25
  hours_per_week = case nature
  when "permanent", "training"
    40
  when "temporary"
    rand(35..40)
  when "part_time"
    rand(20..30)
  when "freelance"
    rand(10..25)
  else
    40
  end

  # Salary base: 20k–60k for permanent/temporary/training; 15k–40k for part_time/freelance
  salary_base = case nature
  when "permanent", "temporary", "training"
    Faker::Number.between(from: 20_000, to: 60_000)
  when "part_time", "freelance"
    Faker::Number.between(from: 15_000, to: 40_000)
  else
    30_000
  end

  # Bonus percentage: only for permanent/temporary; else 0
  bonus_percentage =
    if %w[permanent temporary].include?(nature)
      Faker::Number.between(from: 0, to: 15)
    else
      0.0
    end

  # Benefits: pick 2–4 random items
  benefits = BENEFIT_OPTIONS.sample(rand(2..4))

  # Work location: random city
  work_location = Faker::Address.city

  # Remote option: 30% chance true
  remote_option = Faker::Boolean.boolean(true_ratio: 0.3)

  # Status: most start as draft or pending
  status = ["draft", "pending", "active"].sample

  # Generate a unique contract number
  loop do
    @contract_number = "CT-#{SecureRandom.alphanumeric(8).upcase}"
    break unless Hr::Contract.exists?(contract_number: @contract_number)
  end

  Hr::Contract.create!(
    person:           person,
    position:         position,
    company:          company,
    status:           status,
    contract_nature:  nature,
    contract_number:  @contract_number,
    start_date:       start_date,
    end_date:         end_date,
    duration_months:  duration_months,
    probation_days:   probation_days,
    hours_per_week:   hours_per_week,
    salary_base:      salary_base,
    salary_currency:  CURRENCIES.sample,
    bonus_percentage: bonus_percentage,
    benefits:         benefits,
    work_location:    work_location,
    remote_option:    remote_option
  )
end

puts "✅ Created #{Hr::Contract.count} contracts."
