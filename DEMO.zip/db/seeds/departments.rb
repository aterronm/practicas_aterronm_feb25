# db/seeds/departments.rb

# ------------------------------------------------------------
# 1) Clear existing departments
# ------------------------------------------------------------
Core::Department.delete_all

# ------------------------------------------------------------
# 2) Create top-level departments
# ------------------------------------------------------------
hr      = Core::Department.create!(name: "Human Resources",         code: "HR",    description: "Talent management and internal personnel")
fin     = Core::Department.create!(name: "Finance",                 code: "FIN",   description: "Financial administration and accounting")
tech    = Core::Department.create!(name: "Technology",              code: "TECH",  description: "Systems development and maintenance")
marketing = Core::Department.create!(name: "Marketing",             code: "MKT",   description: "Market strategies and advertising")
sales   = Core::Department.create!(name: "Sales",                   code: "SALES", description: "Customer relations and revenue generation")
ops     = Core::Department.create!(name: "Operations",              code: "OPS",   description: "Logistics and day-to-day operations")
legal   = Core::Department.create!(name: "Legal",                   code: "LEGAL", description: "Legal affairs and compliance")
quality = Core::Department.create!(name: "Quality & Safety",        code: "QAS",   description: "Quality control and safety regulations")
rnd     = Core::Department.create!(name: "R&D",                      code: "RND",   description: "Research and development of new products")
support = Core::Department.create!(name: "Technical Support",       code: "SUP",   description: "Technical issue resolution and user support")

puts "✅ Created #{Core::Department.roots.count} top-level departments."

# ------------------------------------------------------------
# 3) Create sub-departments under Human Resources
# ------------------------------------------------------------
recruit = Core::Department.create!(
  name:        "Recruitment",
  code:        "RECR",
  description: "Recruiting and onboarding new employees",
  parent:      hr
)

org_dev  = Core::Department.create!(
  name:        "Organizational Development",
  code:        "ORGDEV",
  description: "Employee growth and training programs",
  parent:      hr
)

puts "✅ Created sub-departments under Human Resources: #{hr.subdepartments.pluck(:name).join(', ')}."

# ------------------------------------------------------------
# 4) Create sub-departments under Finance
# ------------------------------------------------------------
treasury = Core::Department.create!(
  name:        "Treasury",
  code:        "TRSY",
  description: "Cash flow management and banking",
  parent:      fin
)

accounting = Core::Department.create!(
  name:        "Accounting",
  code:        "ACCT",
  description: "Bookkeeping and financial reporting",
  parent:      fin
)

puts "✅ Created sub-departments under Finance: #{fin.subdepartments.pluck(:name).join(', ')}."

# ------------------------------------------------------------
# 5) Create sub-departments under Technology
# ------------------------------------------------------------
dev      = Core::Department.create!(
  name:        "Software Development",
  code:        "DEV",
  description: "Application design, coding, and testing",
  parent:      tech
)

infrastructure = Core::Department.create!(
  name:        "Infrastructure",
  code:        "INFRA",
  description: "Server, network, and hardware administration",
  parent:      tech
)

puts "✅ Created sub-departments under Technology: #{tech.subdepartments.pluck(:name).join(', ')}."

# ------------------------------------------------------------
# 6) Create sub-departments under Marketing
# ------------------------------------------------------------
digital   = Core::Department.create!(
  name:        "Digital Marketing",
  code:        "DIGI",
  description: "Online strategies, SEO, and social media",
  parent:      marketing
)

content   = Core::Department.create!(
  name:        "Content Marketing",
  code:        "CONT",
  description: "Content creation and inbound marketing",
  parent:      marketing
)

puts "✅ Created sub-departments under Marketing: #{marketing.subdepartments.pluck(:name).join(', ')}."

# ------------------------------------------------------------
# 7) Create sub-departments under Sales
# ------------------------------------------------------------
national_sales = Core::Department.create!(
  name:        "National Sales",
  code:        "NSLS",
  description: "Domestic customer relations and sales",
  parent:      sales
)

international_sales = Core::Department.create!(
  name:        "International Sales",
  code:        "ISLS",
  description: "Exports and sales outside the country",
  parent:      sales
)

puts "✅ Created sub-departments under Sales: #{sales.subdepartments.pluck(:name).join(', ')}."

# ------------------------------------------------------------
# 8) Create sub-departments under Operations
# ------------------------------------------------------------
logistics = Core::Department.create!(
  name:        "Logistics",
  code:        "LOG",
  description: "Coordination of transport and warehousing",
  parent:      ops
)

production = Core::Department.create!(
  name:        "Production",
  code:        "PROD",
  description: "Manufacturing and product assembly",
  parent:      ops
)

puts "✅ Created sub-departments under Operations: #{ops.subdepartments.pluck(:name).join(', ')}."

# ------------------------------------------------------------
# 9) Create sub-departments under Quality & Safety
# ------------------------------------------------------------
quality_control = Core::Department.create!(
  name:        "Quality Control",
  code:        "QC",
  description: "Inspection and testing for quality assurance",
  parent:      quality
)

safety_standards = Core::Department.create!(
  name:        "Safety Standards",
  code:        "SAFETY",
  description: "Occupational health and safety regulations",
  parent:      quality
)

puts "✅ Created sub-departments under Quality & Safety: #{quality.subdepartments.pluck(:name).join(', ')}."

# ------------------------------------------------------------
# 10) Create sub-departments under R&D
# ------------------------------------------------------------
product_dev  = Core::Department.create!(
  name:        "Product Development",
  code:        "PDEV",
  description: "Product design and innovation",
  parent:      rnd
)

research  = Core::Department.create!(
  name:        "Research",
  code:        "RSCH",
  description: "Scientific research projects",
  parent:      rnd
)

puts "✅ Created sub-departments under R&D: #{rnd.subdepartments.pluck(:name).join(', ')}."

# ------------------------------------------------------------
# 11) Create sub-departments under Technical Support
# ------------------------------------------------------------
helpdesk = Core::Department.create!(
  name:        "Helpdesk",
  code:        "HELP",
  description: "First-level support and user assistance",
  parent:      support
)

it_support = Core::Department.create!(
  name:        "IT Support",
  code:        "ITSUP",
  description: "Server and network support for internal users",
  parent:      support
)

puts "✅ Created sub-departments under Technical Support: #{support.subdepartments.pluck(:name).join(', ')}."

# ------------------------------------------------------------
# 12) Final summary
# ------------------------------------------------------------
total = Core::Department.count
puts "🎯 Total departments created (including hierarchy): #{total}"
