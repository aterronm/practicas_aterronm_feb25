# db/seeds.rb

require 'faker'

# Asegúrate de haber cargado previamente la tabla de Country. Si no, lanza un error.
if Core::Country.count.zero?
  raise "La tabla Country está vacía. Primero debes poblar los países antes de crear Personas."
end

# Limpiamos datos anteriores (opcional)
#Hr::Person.delete_all

40.times do |i|
  # Seleccionamos tres países aleatorios (pueden coincidir, según necesidades)
  country               = Core::Country.all.sample
  tax_residency_country = Core::Country.all.sample
  nationality_country   = Core::Country.all.sample

  # Fechas de aceptación de términos, política y GDPR: fechas aleatorias en el pasado
  consent_base = Faker::Time.backward(days: 365 * 2, period: :all)

  # Construir un IBAN válido sintácticamente: 2 letras (ISO-3166 alpha-2) + 22 dígitos
  iso2 = country.iso[0..1].upcase
  random_digits = Array.new(22) { rand(0..9) }.join
  generated_iban = "#{iso2}#{random_digits}"

  Hr::Person.create!(
    # Datos personales
    first_name:  Faker::Name.first_name,
    last_name:   Faker::Name.last_name,
    gender:      Hr::Person.genders.keys.sample,

    # Tipo y número de identificación (únicos)
    identification_type:   %w[DNI NIE Passport].sample,
    identification_number: Faker::Alphanumeric.unique.alphanumeric(number: 10).upcase,

    social_security_number:        Faker::Number.unique.number(digits: 10).to_s,
    tax_identification_number:     Faker::Alphanumeric.unique.alphanumeric(number: 12).upcase,

    # Países
    country:                     country,
    tax_residency_country:       tax_residency_country,
    nationality_country:         nationality_country,

    # Fecha de nacimiento: entre 18 y 65 años atrás
    date_of_birth: Faker::Date.birthday(min_age: 18, max_age: 65),

    # Contacto
    email:        Faker::Internet.unique.email(name: "#{Faker::Name.first_name} #{Faker::Name.last_name}", domain: 'gmail.com'),
    phone:        "+#{Faker::Number.number(digits: 9)}",
    mobile_phone: "+#{Faker::Number.number(digits: 9)}",
    secondary_phone: "",

    preferred_contact_method: Hr::Person.preferred_contact_methods.keys.sample,

    # Dirección principal
    street:      Faker::Address.street_address,
    city:        Faker::Address.city,
    state:       Faker::Address.state,
    postal_code: Faker::Address.postcode,

    # Datos bancarios
    bank_iban: generated_iban,
    bank_bic:  Faker::Bank.swift_bic,
    bank_name: Faker::Bank.name,

    # Consentimientos y preferencias
    terms_accepted_at:         consent_base + rand(1..30).days,
    privacy_policy_accepted_at: consent_base + rand(31..60).days,
    gdpr_consent_at:            consent_base + rand(61..90).days,
    data_sharing_consent:       [true, false].sample
  )
end

puts "✅ Se han creado 40 personas ficticias en Hr::Person."
