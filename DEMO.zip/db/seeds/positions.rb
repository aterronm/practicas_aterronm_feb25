# db/seeds/positions.rb

require 'faker'

# ------------------------------------------------------------
# 1) Clear existing positions
# ------------------------------------------------------------
Hr::Position.delete_all

# ------------------------------------------------------------
# 2) Fetch all persons and departments
# ------------------------------------------------------------
persons     = Hr::Person.all.to_a.shuffle
departments = Core::Department.all.to_a.shuffle

if persons.empty? || departments.empty?
  puts "⚠️  Cannot seed positions because there are no persons or/or no departments."
  exit
end

# ------------------------------------------------------------
# 3) Helper data
# ------------------------------------------------------------
BENEFITS_POOL = [
  "Health Insurance",
  "Retirement Plan",
  "Paid Time Off",
  "Flexible Hours",
  "Stock Options",
  "Professional Development",
  "Gym Membership",
  "Commuter Benefits",
  "Life Insurance",
  "Tuition Reimbursement"
].freeze

DESIRED_TOTAL = 30
#Esto permite representar el numero deseado total de posiciones que se pretenden crear

# ------------------------------------------------------------
# 4) Determine manager count
#    Choose up to 5 departments to have managers (or fewer if fewer departments)
# ------------------------------------------------------------
manager_depts = departments.sample([departments.size, 5].min)
manager_positions = {}

manager_depts.each_with_index do |dept, idx|
  person   = persons[idx % persons.size]
  job_code = "MGR-#{dept.code.upcase}-#{Faker::Alphanumeric.alphanumeric(number: 4).upcase}"
  pos = Hr::Position.create!(
    person:                  person,
    department:              dept,
    supervisor:              nil,
    contract_type:           Hr::Position.contract_types.keys.sample,
    status:                  :active,
    shift_type:              Hr::Position.shift_types.keys.sample,
    job_level:               :manager,
    job_code:                job_code,
    title:                   "#{dept.name} Manager",
    description:             Faker::Lorem.paragraph(sentence_count: 2),
    salary_min:              Faker::Number.between(from: 60_000, to: 80_000),
    salary_max:              Faker::Number.between(from: 80_001, to: 100_000),
    probation_period_days:   [30, 60].sample,
    benefits:                BENEFITS_POOL.sample(3),
    hours_per_week:          Faker::Number.between(from: 35, to: 40),
    start_date:              Faker::Date.backward(days: 365),
    end_date:                nil,
    notice_period_days:      Faker::Number.between(from: 30, to: 60),
    termination_reason:      nil,
    termination_date:        nil,
    cost_center_code:        "CC-#{Faker::Number.number(digits: 4)}",
    project_code:            "PRJ-#{Faker::Alphanumeric.alphanumeric(number: 3).upcase}",
    manager:                 true
  )
  manager_positions[dept.id] = pos
end

puts "✅ Created #{manager_positions.size} manager positions."

# ------------------------------------------------------------
# 5) Create subordinate positions until total reaches DESIRED_TOTAL
# ------------------------------------------------------------
created_count = manager_positions.size
while created_count < DESIRED_TOTAL
  dept = manager_depts.sample
  mgr  = manager_positions[dept.id]
  person = persons.sample

  job_code = "STAFF-#{dept.code.upcase}-#{Faker::Alphanumeric.alphanumeric(number: 4).upcase}"
  status = [:active, :vacant, :suspended].sample
  start_date = Faker::Date.backward(days: 365)
  end_date = if status.in?(%i[completed cancelled])
    start_date + Faker::Number.between(from: 90, to: 180)
  else
    nil
  end

  Hr::Position.create!(
    person:                  person,
    department:              dept,
    supervisor:              mgr,
    contract_type:           Hr::Position.contract_types.keys.sample,
    status:                  status,
    shift_type:              Hr::Position.shift_types.keys.sample,
    job_level:               Hr::Position.job_levels.keys.reject { |lvl| lvl == "manager" }.sample,
    job_code:                job_code,
    title:                   Faker::Job.title,
    description:             Faker::Lorem.paragraph(sentence_count: 1),
    salary_min:              Faker::Number.between(from: 40_000, to: 60_000),
    salary_max:              Faker::Number.between(from: 60_001, to: 80_000),
    probation_period_days:   [0, 30].sample,
    benefits:                BENEFITS_POOL.sample(2),
    hours_per_week:          Faker::Number.between(from: 30, to: 40),
    start_date:              start_date,
    end_date:                end_date,
    notice_period_days:      Faker::Number.between(from: 15, to: 45),
    termination_reason:      end_date.present? ? Faker::Lorem.sentence(word_count: 4) : nil,
    termination_date:        end_date,
    cost_center_code:        "CC-#{Faker::Number.number(digits: 4)}",
    project_code:            "PRJ-#{Faker::Alphanumeric.alphanumeric(number: 3).upcase}",
    manager:                 false
  )
  created_count += 1
end

puts "✅ Created #{created_count - manager_positions.size} subordinate positions."
puts "✅ Total positions created: #{created_count}."
