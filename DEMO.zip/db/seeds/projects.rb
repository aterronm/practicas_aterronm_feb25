# db/seeds.rb
require 'faker'

# ——————————————————————————————————————————————————————————————
# Crear 20 proyectos con datos Faker
# ——————————————————————————————————————————————————————————————
clients = Core::Client.all.to_a
raise "Tienes menos de 20 clientes en la BD" if clients.size < 20

people = Hr::Person.all.to_a
raise "Necesitas al menos 3 personas en la BD" if people.size < 3

clients.sample(20).each_with_index do |client, idx|
  code = "PRJ%03d" % (idx + 1)

  project = Pm::Project.find_or_initialize_by(client: client, code: code)
  project.assign_attributes(
    name:               Faker::App.name,                                       # nombre aleatorio
    description:        Faker::Lorem.paragraph(sentence_count: 3, random_sentences_to_add: 2),
    start_date:         Date.today - rand(0..10).days,
    end_date_estimated: Date.today + rand(15..60).days,
    status:             Pm::Project.statuses.keys.sample,
    project_type:       Pm::Project.project_types.keys.sample,
    priority:           Pm::Project.priorities.keys.sample,
    budget:             rand(5_000..100_000),
    currency:           %w[EUR USD GBP].sample
  )
  project.save!

  # Asignar roles sin repetir personas
  %i[product_owner scrum_master developer].each do |role|
    available = people - project.project_memberships.map(&:person)
    person    = available.sample
    project.project_memberships.create!(
      person:     person,
      role:       role,
      start_date: project.start_date
    )
  end

  # Primer sprint
  project.sprints.find_or_create_by!(number: 1) do |s|
    s.name       = "Sprint #{Faker::Number.between(from: 1, to: 3)}"
    s.goal       = Faker::Lorem.sentence(word_count: 6)
    s.start_date = project.start_date
    s.end_date   = project.start_date + 14
    s.status     = :planned
  end

  puts "✔ Proyecto #{project.code}: #{project.name} creado"
end
