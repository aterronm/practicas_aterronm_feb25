# db/seeds/roles.rb

# ------------------------------------------------------------
# 1) Clear existing roles
# ------------------------------------------------------------
#Role.delete_all

# ------------------------------------------------------------
# 2) Create application roles
# ------------------------------------------------------------
roles = [
  { code: "admin",            name: "Administrator",       description: "Full access to all system features and settings." },
  { code: "hr_admin",         name: "HR Administrator",    description: "Manages all HR-related tasks: person records, leaves, payroll setup." },
  { code: "dept_head",        name: "Department Head",     description: "Oversees a specific department and approves team actions." },
  { code: "finance_manager",  name: "Finance Manager",     description: "Handles budgeting, expenses, and financial reports." },
  { code: "it_admin",         name: "IT Administrator",    description: "Manages system infrastructure, user provisioning, and technical support." },
  { code: "employee",         name: "Employee",            description: "Standard user role with access to personal dashboards and common features." },
  { code: "guest",            name: "Guest",               description: "Limited access; can view public information but cannot modify data." }
]

roles.each do |attrs|
  Core::Role.create!(attrs)
end

puts "✅ Created #{Core::Role.count} roles: #{Core::Role.pluck(:code).join(', ')}."
