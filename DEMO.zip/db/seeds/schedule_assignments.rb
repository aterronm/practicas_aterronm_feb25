# db/seeds/schedule_assignments.rb

require 'faker'

# ------------------------------------------------------------
# 1) Clear existing assignments
# ------------------------------------------------------------
Hr::ScheduleAssignment.delete_all

# ------------------------------------------------------------
# 2) Fetch existing work schedules, persons, and positions
# ------------------------------------------------------------
work_schedules = Hr::WorkSchedule.all.to_a
persons        = Hr::Person.all.to_a
positions      = Hr::Position.all.to_a

if work_schedules.empty?
  puts "⚠️  No WorkSchedule records found. Please seed WorkSchedule first."
  exit
end

if persons.empty? && positions.empty?
  puts "⚠️  No Hr::Person or Hr::Position records found. Cannot create assignments."
  exit
end

# ------------------------------------------------------------
# 3) Helper to pick a non-overlapping period for an assignable
# ------------------------------------------------------------
def find_non_overlapping_interval(existing_intervals, desired_length)
  candidate_start = Date.parse("2025-01-01")
  loop do
    candidate_end = candidate_start + desired_length
    overlaps = existing_intervals.any? do |(s, e)|
      e ||= Date::Infinity.new
      (candidate_start <= e) && (s <= candidate_end)
    end
    return [candidate_start, candidate_end] unless overlaps

    candidate_start += (desired_length + 1)
  end
end

# ------------------------------------------------------------
# 4) Create exactly one active assignment per person
# ------------------------------------------------------------
puts "Seeding one assignment per person..."

assignment_count = 0
intervals_by_assignable = Hash.new { |h, k| h[k] = [] }

persons.each do |person|
  schedule = work_schedules.sample
  length   = rand(60..120)
  start_date, end_date = find_non_overlapping_interval(intervals_by_assignable[person], length)

  Hr::ScheduleAssignment.create!(
    work_schedule: schedule,
    assignable:    person,
    start_date:    start_date,
    end_date:      end_date,
    status:        :active,
    notes:         "Assigned to #{schedule.name} from #{start_date} to #{end_date}."
  )

  intervals_by_assignable[person] << [start_date, end_date]
  assignment_count += 1
end



puts "✅ Created #{assignment_count} schedule assignments (one per person)."
