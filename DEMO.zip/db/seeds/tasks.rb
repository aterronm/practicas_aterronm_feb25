# db/seeds/tasks.rb
require 'faker'

project = Pm::Project.find_by(id: 24)
raise "No existe el proyecto con id=24" unless project

people_ids = Hr::Person.pluck(:id)
statuses    = Pm::Task.statuses.keys
work_types  = Pm::Task.work_types.keys

25.times do |i|
  title       = Faker::Lorem.sentence(word_count: 3).chomp('.')
  description = Faker::Lorem.paragraph(sentence_count: 2)
  status      = statuses.sample
  work_type   = work_types.sample
  est_hours   = rand(1.0..8.0).round(1)
  started_at  = [nil, rand(1..5).days.ago].sample



  project.tasks.create!(
    title:           title,
    description:     description,
    status:          status,
    work_type:       work_type,
    estimated_hours: est_hours,
    started_at:      started_at,
    assignee_id:     people_ids.sample
  )
end

puts "✅ 25 tareas seedeadas para el proyecto #{project.id}."
