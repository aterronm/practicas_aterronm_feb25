# db/seeds/work_schedules.rb

# ------------------------------------------------------------
# 1) Clear existing records
# ------------------------------------------------------------
Hr::WorkSchedule.delete_all

# ------------------------------------------------------------
# 2) Create Fixed Schedule: Weekdays 09:00–17:00 with 1h break
# ------------------------------------------------------------
Hr::WorkSchedule.create!(
  name:            "Weekday 9-to-5",
  description:     "Standard Monday–Friday 9 AM to 5 PM schedule with a 1-hour lunch break at noon.",
  schedule_type:   :fixed,
  start_time:      "09:00",
  end_time:        "17:00",
  break_start_time:"12:00",
  break_end_time:  "13:00",
  days_of_week:    %w[mon tue wed thu fri],
  active:          true
)

# ------------------------------------------------------------
# 3) Create Fixed Schedule: Evening Shift Weekdays
# ------------------------------------------------------------
Hr::WorkSchedule.create!(
  name:            "Evening Shift",
  description:     "Monday–Friday 2 PM to 10 PM with a 30 minute break at 5:00 PM.",
  schedule_type:   :fixed,
  start_time:      "14:00",
  end_time:        "22:00",
  break_start_time:"17:00",
  break_end_time:  "17:30",
  days_of_week:    %w[mon tue wed thu fri],
  active:          true
)

# ------------------------------------------------------------
# 4) Create Fixed Schedule: Weekend Only
# ------------------------------------------------------------
Hr::WorkSchedule.create!(
  name:            "Weekend Coverage",
  description:     "Saturday and Sunday 10 AM to 4 PM, no scheduled break.",
  schedule_type:   :fixed,
  start_time:      "10:00",
  end_time:        "16:00",
  break_start_time:nil,
  break_end_time:  nil,
  days_of_week:    %w[sat sun],
  active:          true
)

# ------------------------------------------------------------
# 5) Create Rotating Schedule: Early/Late Week Rotation
# ------------------------------------------------------------
Hr::WorkSchedule.create!(
  name:            "Early/Late Rotation",
  description:     "Alternates: Mon–Wed 8 AM–4 PM, Thu–Fri 12 PM–8 PM. No shift on weekends.",
  schedule_type:   :rotating,
  start_time:      "08:00",
  end_time:        "16:00",
  break_start_time:"12:00",
  break_end_time:  "12:30",
  days_of_week:    %w[mon tue wed thu fri],
  active:          true
)

# ------------------------------------------------------------
# 6) Create Rotating Schedule: Split Weekends & Weekdays
# ------------------------------------------------------------
Hr::WorkSchedule.create!(
  name:            "Split Weekend Rotation",
  description:     "Mon–Fri 7 AM–3 PM with 30 min break; Sat–Sun 2 PM–8 PM with 15 min break.",
  schedule_type:   :rotating,
  start_time:      "07:00",
  end_time:        "15:00",
  break_start_time:"11:00",
  break_end_time:  "11:30",
  days_of_week:    %w[mon tue wed thu fri sat sun],
  active:          true
)



puts "✅ Seeded #{Hr::WorkSchedule.count} work schedules."
