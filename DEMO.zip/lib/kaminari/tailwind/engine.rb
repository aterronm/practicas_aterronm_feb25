module Kaminari
  module Tailwind
    class Engine < ::Rails::Engine
    end
  end
end