# frozen_string_literal: true

module Kaminari
  module Tailwind
    VERSION = "0.1.0"
  end
end